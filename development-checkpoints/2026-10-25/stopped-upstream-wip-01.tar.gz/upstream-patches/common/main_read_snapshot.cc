/* SPDX-FileCopyrightText: 2026 Codex Blender Bridge contributors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */

#include "BKE_main_read_snapshot.hh"

#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT
#  include <atomic>
#  include <climits>
#  include <cstring>

#  include "DNA_ID.h"
#  include "DNA_ID_enums.h"
#  include "DNA_collection_types.h"
#  include "DNA_layer_types.h"
#  include "DNA_scene_types.h"

#  include "BLI_threads.h"
#  include "BLI_utildefines.h"

#  include "BKE_global.hh"
#  include "BKE_main.hh"

namespace blender::bke {
namespace {
/* Static initialization; no lazy allocator, Python flag or reset function. */
std::atomic<uint64_t> phase_epoch{1};
std::atomic<uint32_t> critical_depth{0};
constexpr uint32_t MAX_IDS = 512;
constexpr uint32_t MAX_SCENES = 8;
constexpr uint32_t MAX_VIEW_LAYERS = 32;
constexpr uint32_t MAX_BASES = 256;
constexpr uint32_t MAX_LAYER_COLLECTIONS = 512;
constexpr uint32_t MAX_PROPERTIES = 4096;
constexpr uint32_t MAX_ELEMENTS = 65536;
constexpr uint32_t MAX_DEPTH = 16;
/* Explicit subset flags: direct-ID/master-ID properties, Scene weak roles,
 * ViewLayer USER/SYSTEM and raw Base/LayerCollection facts; no whole-Main claim. */
constexpr uint32_t SCOPE_V1 = 0x0f;
static_assert(CHAR_BIT == 8 && sizeof(int) == 4 && sizeof(float) == 4 && sizeof(double) == 8);

class Writer {
 public:
  unsigned char *data;
  size_t capacity;
  size_t used = 0;
  MainReadSnapshotStatus status = MainReadSnapshotStatus::Ok;

  bool fail(MainReadSnapshotStatus value)
  {
    if (status == MainReadSnapshotStatus::Ok) {
      status = value;
    }
    return false;
  }
  bool bytes(const void *source, size_t count)
  {
    if (status != MainReadSnapshotStatus::Ok || count > capacity - used) {
      return fail(MainReadSnapshotStatus::Budget);
    }
    if (count != 0) {
      if (source == nullptr) {
        return fail(MainReadSnapshotStatus::InvalidState);
      }
      std::memcpy(data + used, source, count);
    }
    used += count;
    return true;
  }
  bool u8(uint8_t value) { return bytes(&value, 1); }
  bool u16(uint16_t value)
  {
    const unsigned char b[2] = {uint8_t(value), uint8_t(value >> 8)};
    return bytes(b, sizeof(b));
  }
  bool u32(uint32_t value)
  {
    const unsigned char b[4] = {
        uint8_t(value), uint8_t(value >> 8), uint8_t(value >> 16), uint8_t(value >> 24)};
    return bytes(b, sizeof(b));
  }
  bool u64(uint64_t value) { return u32(uint32_t(value)) && u32(uint32_t(value >> 32)); }
  bool name(const char *value, size_t bound)
  {
    if (value == nullptr) {
      return fail(MainReadSnapshotStatus::InvalidState);
    }
    const char *end = static_cast<const char *>(std::memchr(value, 0, bound));
    if (end == nullptr || size_t(end - value) > UINT16_MAX) {
      return fail(MainReadSnapshotStatus::UnsupportedShape);
    }
    return u16(uint16_t(end - value)) && bytes(value, size_t(end - value));
  }
  bool word32(const void *value)
  {
    uint32_t bits;
    std::memcpy(&bits, value, sizeof(bits));
    return u32(bits);
  }
  bool word64(const void *value)
  {
    uint64_t bits;
    std::memcpy(&bits, value, sizeof(bits));
    return u64(bits);
  }
};

class Snapshot {
 public:
  Writer w;
  const ID *ids[MAX_IDS] = {};
  const Scene *scenes[MAX_SCENES] = {};
  const ID *masters[MAX_SCENES] = {};
  const IDProperty *properties[MAX_PROPERTIES] = {};
  const Base *bases[MAX_BASES] = {};
  const LayerCollection *layers[MAX_LAYER_COLLECTIONS] = {};
  int layer_parents[MAX_LAYER_COLLECTIONS] = {};
  uint32_t id_count = 0, scene_count = 0, property_count = 0;
  uint32_t element_count = 0, base_count = 0, layer_count = 0, view_count = 0;

  bool fail(MainReadSnapshotStatus value) { return w.fail(value); }
  bool elements(int count)
  {
    if (count < 0 || uint32_t(count) > MAX_ELEMENTS - element_count) {
      return fail(MainReadSnapshotStatus::Budget);
    }
    element_count += uint32_t(count);
    return true;
  }
  bool reference(const void *raw, short expected_type = 0)
  {
    if (raw == nullptr) {
      return w.u8(0) && w.u32(0);
    }
    /* Compare pointer values first. Never dereference a caller/foreign pointer. */
    for (uint32_t i = 0; i < id_count; i++) {
      if (raw == ids[i]) {
        if (expected_type != 0 && GS(ids[i]->name) != expected_type) {
          return fail(MainReadSnapshotStatus::UnsupportedReference);
        }
        return w.u8(1) && w.u32(ids[i]->session_uid);
      }
    }
    for (uint32_t i = 0; i < scene_count; i++) {
      if (raw == masters[i] && (expected_type == 0 || expected_type == ID_GR)) {
        return w.u8(2) && w.u32(scenes[i]->id.session_uid);
      }
    }
    return fail(MainReadSnapshotStatus::UnsupportedReference);
  }
  bool property(const IDProperty *p, uint32_t depth)
  {
    if (p == nullptr) {
      return w.u8(0);
    }
    if (depth > MAX_DEPTH || property_count == MAX_PROPERTIES) {
      return fail(MainReadSnapshotStatus::Budget);
    }
    for (uint32_t i = 0; i < property_count; i++) {
      if (properties[i] == p) {
        return fail(MainReadSnapshotStatus::UnsupportedShape);
      }
    }
    properties[property_count++] = p;
    /* Initial schema refuses all UI-data shapes rather than silently omitting them. */
    if (p->ui_data != nullptr) {
      return fail(MainReadSnapshotStatus::UnsupportedUIData);
    }
    if (!w.u8(1) || !w.u8(uint8_t(p->type)) || !w.u8(uint8_t(p->subtype)) ||
        !w.u16(uint16_t(p->flag)) || !w.name(p->name, sizeof(p->name)) ||
        !w.u32(uint32_t(p->len)) || !w.u32(uint32_t(p->totallen)))
    {
      return false;
    }
    switch (p->type) {
      case IDP_INT:
      case IDP_FLOAT:
      case IDP_BOOLEAN:
        return w.word32(&p->data.val);
      case IDP_DOUBLE:
        static_assert(offsetof(IDPropertyData, val2) == offsetof(IDPropertyData, val) + 4);
        return w.word64(&p->data.val);
      case IDP_ID:
        return reference(p->data.pointer);
      case IDP_STRING:
        if ((p->subtype != IDP_STRING_SUB_UTF8 && p->subtype != IDP_STRING_SUB_BYTE) ||
            !elements(p->len) || p->totallen < p->len ||
            (p->len != 0 && p->data.pointer == nullptr))
        {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
        if (p->subtype == IDP_STRING_SUB_UTF8 &&
            (p->len == 0 || static_cast<const char *>(p->data.pointer)[p->len - 1] != '\0'))
        {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
        return w.bytes(p->data.pointer, size_t(p->len));
      case IDP_ARRAY: {
        if (!elements(p->len) || p->totallen < p->len ||
            (p->len != 0 && p->data.pointer == nullptr))
        {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
        const auto *data = static_cast<const unsigned char *>(p->data.pointer);
        for (int i = 0; i < p->len; i++) {
          if (p->subtype == IDP_INT || p->subtype == IDP_FLOAT) {
            if (!w.word32(data + size_t(i) * 4)) {
              return false;
            }
          }
          else if (p->subtype == IDP_DOUBLE) {
            if (!w.word64(data + size_t(i) * 8)) {
              return false;
            }
          }
          else if (p->subtype == IDP_BOOLEAN) {
            if (!w.u8(data[i])) {
              return false;
            }
          }
          else {
            return fail(MainReadSnapshotStatus::UnsupportedShape);
          }
        }
        /* Also reject unsupported subtypes for an empty array. */
        return ELEM(p->subtype, IDP_INT, IDP_FLOAT, IDP_DOUBLE, IDP_BOOLEAN) ||
               fail(MainReadSnapshotStatus::UnsupportedShape);
      }
      case IDP_IDPARRAY: {
        if (!elements(p->len) || p->totallen < p->len ||
            (p->len != 0 && p->data.pointer == nullptr))
        {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
        const auto *array = static_cast<const IDProperty *>(p->data.pointer);
        for (int i = 0; i < p->len; i++) {
          if (!property(array + i, depth + 1)) {
            return false;
          }
        }
        return true;
      }
      case IDP_GROUP: {
        if (!elements(p->len)) {
          return false;
        }
        const IDProperty *previous = nullptr;
        int count = 0;
        for (const IDProperty *child = static_cast<const IDProperty *>(p->data.group.first);
             child != nullptr;
             child = child->next)
        {
          if (child->prev != previous || count == p->len ||
              !property(child, depth + 1))
          {
            return fail(MainReadSnapshotStatus::UnsupportedShape);
          }
          previous = child;
          count++;
        }
        return (count == p->len && previous == p->data.group.last) ||
               fail(MainReadSnapshotStatus::UnsupportedShape);
      }
      default:
        return fail(MainReadSnapshotStatus::UnsupportedShape);
    }
  }
  bool owner(const ID &id)
  {
    return w.u32(id.session_uid) && w.name(id.name, sizeof(id.name)) &&
           w.u16(uint16_t(id.flag)) && w.u32(uint32_t(id.tag)) && w.u32(uint32_t(id.us)) &&
           reference(id.lib, ID_LI) && property(id.properties, 0) &&
           property(id.system_properties, 0);
  }
  template<typename List> bool layer_list(const List &list, int parent, uint32_t depth)
  {
    if (depth > MAX_DEPTH && list.first != nullptr) {
      return fail(MainReadSnapshotStatus::Budget);
    }
    const LayerCollection *previous = nullptr;
    for (const LayerCollection *lc = static_cast<const LayerCollection *>(list.first);
         lc != nullptr;
         lc = lc->next)
    {
      if (lc->prev != previous || layer_count == MAX_LAYER_COLLECTIONS) {
        return fail(MainReadSnapshotStatus::Budget);
      }
      for (uint32_t i = 0; i < layer_count; i++) {
        if (layers[i] == lc) {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
      }
      const uint32_t index = layer_count++;
      layers[index] = lc;
      layer_parents[index] = parent;
      if (!layer_list(lc->layer_collections, int(index), depth + 1)) {
        return false;
      }
      previous = lc;
    }
    return previous == list.last || fail(MainReadSnapshotStatus::UnsupportedShape);
  }
  bool view_layer(const ViewLayer &vl)
  {
    if (++view_count > MAX_VIEW_LAYERS || !w.name(vl.name, sizeof(vl.name)) ||
        !w.u16(uint16_t(vl.flag)) || !w.u32(uint32_t(vl.layflag)) ||
        !w.u32(uint32_t(vl.passflag)) || !reference(vl.mat_override, ID_MA) ||
        !reference(vl.world_override, ID_WO) || !property(vl.id_properties, 0) ||
        !property(vl.system_properties, 0))
    {
      return fail(MainReadSnapshotStatus::Budget);
    }
    const uint32_t first_base = base_count;
    const Base *previous = nullptr;
    int active_base = -1;
    for (const Base *b = static_cast<const Base *>(vl.object_bases.first); b != nullptr;
         b = b->next)
    {
      if (b->prev != previous || b->base_orig != nullptr || base_count == MAX_BASES) {
        return fail(MainReadSnapshotStatus::UnsupportedShape);
      }
      for (uint32_t i = 0; i < base_count; i++) {
        if (bases[i] == b) {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
      }
      bases[base_count++] = b;
      if (b == vl.basact) {
        active_base = int(base_count - first_base - 1);
      }
      previous = b;
    }
    if (previous != vl.object_bases.last || (vl.basact != nullptr && active_base == -1) ||
        !w.u32(base_count - first_base) || !w.u32(uint32_t(active_base)))
    {
      return fail(MainReadSnapshotStatus::UnsupportedShape);
    }
    for (uint32_t i = first_base; i < base_count; i++) {
      const Base &b = *bases[i];
      if (!reference(b.object, ID_OB) || !w.u16(uint16_t(b.flag)) ||
          !w.u16(uint16_t(b.flag_from_collection)) || !w.u16(uint16_t(b.flag_legacy)) ||
          !w.u16(b.local_view_bits) || !w.u16(b.local_collections_bits))
      {
        return false;
      }
    }
    const uint32_t first_layer = layer_count;
    if (!layer_list(vl.layer_collections, -1, 0)) {
      return false;
    }
    int active_layer = -1;
    for (uint32_t i = first_layer; i < layer_count; i++) {
      if (layers[i] == vl.active_collection) {
        active_layer = int(i - first_layer);
      }
    }
    if ((vl.active_collection != nullptr && active_layer == -1) ||
        !w.u32(layer_count - first_layer) || !w.u32(uint32_t(active_layer)))
    {
      return fail(MainReadSnapshotStatus::UnsupportedShape);
    }
    for (uint32_t i = first_layer; i < layer_count; i++) {
      const LayerCollection &lc = *layers[i];
      const int parent = layer_parents[i] == -1 ? -1 : layer_parents[i] - int(first_layer);
      if (!w.u32(uint32_t(parent)) || !reference(lc.collection, ID_GR) ||
          !w.u16(uint16_t(lc.flag)) || !w.u16(uint16_t(lc.runtime_flag)) ||
          !w.u16(lc.local_collections_bits))
      {
        return false;
      }
    }
    return true;
  }
  bool copy(Main &main, uint64_t epoch)
  {
    /* BKE_main_lists_get returns stack-array ListBase addresses; no ensure or RNA call. */
    for (const auto *list : BKE_main_lists_get(main)) {
      const ID *previous = nullptr;
      for (const ID *id = static_cast<const ID *>(list->first); id != nullptr;
           id = static_cast<const ID *>(id->next))
      {
        if (id->prev != previous || id_count == MAX_IDS || id->session_uid == 0) {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
        for (uint32_t i = 0; i < id_count; i++) {
          if (ids[i] == id || ids[i]->session_uid == id->session_uid) {
            return fail(MainReadSnapshotStatus::UnsupportedShape);
          }
        }
        ids[id_count++] = id;
        if (GS(id->name) == ID_SCE) {
          if (scene_count == MAX_SCENES) {
            return fail(MainReadSnapshotStatus::Budget);
          }
          const auto *scene = reinterpret_cast<const Scene *>(id);
          if (scene->master_collection == nullptr) {
            return fail(MainReadSnapshotStatus::UnsupportedShape);
          }
          scenes[scene_count] = scene;
          masters[scene_count++] = reinterpret_cast<const ID *>(scene->master_collection);
        }
        previous = id;
      }
      if (previous != list->last) {
        return fail(MainReadSnapshotStatus::UnsupportedShape);
      }
    }
    /* Embedded master IDs are admitted by the owning Scene role, never integer pointers. */
    for (uint32_t i = 0; i < scene_count; i++) {
      for (uint32_t j = 0; j < id_count; j++) {
        if (masters[i] == ids[j]) {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
      }
      for (uint32_t j = 0; j < i; j++) {
        if (masters[i] == masters[j]) {
          return fail(MainReadSnapshotStatus::UnsupportedShape);
        }
      }
      if (GS(masters[i]->name) != ID_GR) {
        return fail(MainReadSnapshotStatus::UnsupportedShape);
      }
    }
    const char magic[8] = {'B', 'C', 'B', 'R', 'D', 'S', '1', '\0'};
    if (!w.bytes(magic, sizeof(magic)) || !w.u32(1) || !w.u32(SCOPE_V1) ||
        !w.u64(epoch) || !w.u32(id_count))
    {
      return false;
    }
    for (uint32_t i = 0; i < id_count; i++) {
      if (!owner(*ids[i])) {
        return false;
      }
    }
    if (!w.u32(scene_count)) {
      return false;
    }
    for (uint32_t i = 0; i < scene_count; i++) {
      const Scene &scene = *scenes[i];
      if (!w.u32(scene.id.session_uid) || !owner(*masters[i]) ||
          !reference(scene.camera, ID_OB) || !reference(scene.world, ID_WO) ||
          !w.u8(scene.toolsettings != nullptr))
      {
        return false;
      }
      if (scene.toolsettings != nullptr) {
        const ParticleEditSettings &p = scene.toolsettings->particle;
        if (!reference(p.scene, ID_SCE) || !reference(p.object, ID_OB) ||
            !reference(p.shape_object, ID_OB))
        {
          return false;
        }
      }
      uint32_t count = 0;
      const ViewLayer *previous = nullptr;
      for (const ViewLayer *vl = static_cast<const ViewLayer *>(scene.view_layers.first);
           vl != nullptr; vl = vl->next)
      {
        if (vl->prev != previous || ++count > MAX_VIEW_LAYERS) {
          return fail(MainReadSnapshotStatus::Budget);
        }
        previous = vl;
      }
      if (previous != scene.view_layers.last || !w.u32(count)) {
        return fail(MainReadSnapshotStatus::UnsupportedShape);
      }
      for (const ViewLayer *vl = static_cast<const ViewLayer *>(scene.view_layers.first);
           vl != nullptr; vl = vl->next)
      {
        if (!view_layer(*vl)) {
          return false;
        }
      }
    }
    return true;
  }
};
}  // namespace

MainReadCriticalScope::MainReadCriticalScope() noexcept
{
  critical_depth.fetch_add(1, std::memory_order_acq_rel);
  phase_epoch.fetch_add(1, std::memory_order_acq_rel);
}
MainReadCriticalScope::~MainReadCriticalScope() noexcept
{
  phase_epoch.fetch_add(1, std::memory_order_acq_rel);
  const uint32_t previous = critical_depth.fetch_sub(1, std::memory_order_acq_rel);
  BLI_assert(previous != 0);
  (void)previous;
}

bool BKE_main_read_snapshot_epoch_matches(uint64_t expected) noexcept
{
  return BLI_thread_is_main() && critical_depth.load(std::memory_order_acquire) == 0 &&
         phase_epoch.load(std::memory_order_acquire) == expected;
}

MainReadSnapshotResult BKE_main_read_snapshot_v1(void *arena, size_t capacity) noexcept
{
  /* No G_MAIN, Main/ID dereference, RNA object or Python API before these gates. */
  if (!BLI_thread_is_main()) {
    return {MainReadSnapshotStatus::WrongThread, 0, 0};
  }
  if (critical_depth.load(std::memory_order_acquire) != 0) {
    return {MainReadSnapshotStatus::CriticalPhase, 0, 0};
  }
  if (arena == nullptr || capacity > MAIN_READ_SNAPSHOT_CAPACITY || capacity < 32) {
    return {MainReadSnapshotStatus::Budget, 0, 0};
  }
  const uint64_t epoch = phase_epoch.load(std::memory_order_acquire);
  MainReadSnapshotResult result{MainReadSnapshotStatus::Ok, 0, epoch};
  {
    Snapshot snapshot;
    snapshot.w.data = static_cast<unsigned char *>(arena);
    snapshot.w.capacity = capacity;
    /* Authoritative native acquisition, after caller allocation/argument handling.
     * Main writes must obey Blender's main-thread invariant. Background temporary-
     * Main critical scopes conservatively invalidate the result through the epoch. */
    Main *main = G_MAIN;
    if (main == nullptr) {
      result.status = MainReadSnapshotStatus::NoMain;
    }
    else if (!snapshot.copy(*main, epoch)) {
      result.status = snapshot.w.status == MainReadSnapshotStatus::Ok ?
                          MainReadSnapshotStatus::InvalidState : snapshot.w.status;
    }
    else {
      result.bytes_written = snapshot.w.used;
    }
    main = nullptr;
  } /* Every Main/ID/property/Base pointer leaves scope before Python allocates. */
  if (!BKE_main_read_snapshot_epoch_matches(epoch)) {
    return {MainReadSnapshotStatus::CriticalPhase, 0, epoch};
  }
  return result;
}
}  // namespace blender::bke
#endif
