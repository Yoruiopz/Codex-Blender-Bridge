/* SPDX-FileCopyrightText: 2026 Codex Blender Bridge contributors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */
#pragma once
#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT
struct _object;
/** Private experimental API; no raw RNA/pointer input. */
_object *BPY_main_read_snapshot_v1(_object *self, _object *unused);
#endif
