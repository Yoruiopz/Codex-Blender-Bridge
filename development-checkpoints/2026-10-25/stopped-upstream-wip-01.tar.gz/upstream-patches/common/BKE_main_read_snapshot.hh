/* SPDX-FileCopyrightText: 2026 Codex Blender Bridge contributors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */
#pragma once

#include <cstddef>
#include <cstdint>

namespace blender::bke {

/** Native-only phase marker. Python receives no setter or scope capability.
 * Nested scopes are supported; scopes never block while holding the Python GIL.
 * This is a phase witness, not a lock that licenses background Main mutation. */
class MainReadCriticalScope {
 public:
#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT
  MainReadCriticalScope() noexcept;
  ~MainReadCriticalScope() noexcept;
#else
  MainReadCriticalScope() noexcept {}
  ~MainReadCriticalScope() noexcept {}
#endif
  MainReadCriticalScope(const MainReadCriticalScope &) = delete;
  MainReadCriticalScope &operator=(const MainReadCriticalScope &) = delete;
};

#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT
constexpr size_t MAIN_READ_SNAPSHOT_CAPACITY = 2 * 1024 * 1024;

enum class MainReadSnapshotStatus : uint8_t {
  Ok,
  WrongThread,
  CriticalPhase,
  NoMain,
  Budget,
  UnsupportedShape,
  UnsupportedUIData,
  UnsupportedReference,
  InvalidState,
};

struct MainReadSnapshotResult {
  MainReadSnapshotStatus status;
  size_t bytes_written;
  uint64_t main_epoch;
};

/** Allocations and Python argument processing must finish before this call.
 * Reads authoritative G_MAIN internally; accepts no caller pointer or RNA wrapper.
 * The initial schema covers direct Main IDs and Scene master-collection properties,
 * Scene weak roles, ViewLayer properties, and raw Base/LayerCollection facts.
 * It is not a complete authored-Main or persistent non-ID identity witness. */
MainReadSnapshotResult BKE_main_read_snapshot_v1(void *arena, size_t capacity) noexcept;

/** Does not dereference Main or allocate. Used after Python result allocation. */
bool BKE_main_read_snapshot_epoch_matches(uint64_t expected) noexcept;
#endif

}  // namespace blender::bke
