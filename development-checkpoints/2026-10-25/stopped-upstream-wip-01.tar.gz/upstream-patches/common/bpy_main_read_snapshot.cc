/* SPDX-FileCopyrightText: 2026 Codex Blender Bridge contributors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */
#include "bpy_main_read_snapshot.hh"
#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT
#  include <Python.h>
#  include <cstdlib>
#  include "BKE_main_read_snapshot.hh"

PyObject *BPY_main_read_snapshot_v1(PyObject * /*self*/, PyObject * /*unused*/)
{
  using namespace blender::bke;
#  ifdef Py_GIL_DISABLED
  PyErr_SetString(PyExc_NotImplementedError,
                  "Experimental raw snapshot requires a GIL-enabled Python build");
  return nullptr;
#  else
  struct GILScope {
    PyGILState_STATE state = PyGILState_Ensure();
    ~GILScope() { PyGILState_Release(state); }
  } gil;
  (void)gil;
  /* Native C-owned memory is allocated before authoritative Main acquisition. */
  void *arena = std::malloc(MAIN_READ_SNAPSHOT_CAPACITY);
  if (arena == nullptr) {
    return PyErr_NoMemory();
  }
  const MainReadSnapshotResult result = BKE_main_read_snapshot_v1(arena,
                                                               MAIN_READ_SNAPSHOT_CAPACITY);
  if (result.status != MainReadSnapshotStatus::Ok) {
    std::free(arena);
    PyErr_Format(PyExc_RuntimeError,
                 "Experimental raw snapshot refused (status %u); no complete snapshot returned",
                 unsigned(result.status));
    return nullptr;
  }
  /* The BKE call has discarded every Blender pointer before allocating a result. */
  PyObject *bytes = PyBytes_FromStringAndSize(static_cast<const char *>(arena),
                                            Py_ssize_t(result.bytes_written));
  std::free(arena);
  if (bytes == nullptr) {
    return nullptr;
  }
  /* Result creation may run Python GC/finalizers. Never publish an old-epoch result. */
  if (!BKE_main_read_snapshot_epoch_matches(result.main_epoch)) {
    Py_DECREF(bytes); /* Exact builtin bytes object; no user destructor or Blender pointer. */
    PyErr_SetString(PyExc_RuntimeError, "Main phase changed while constructing snapshot result");
    return nullptr;
  }
  return bytes;
#  endif
}
#endif
