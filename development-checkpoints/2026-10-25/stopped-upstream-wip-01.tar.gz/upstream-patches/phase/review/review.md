# Independent phase-patch source review

**SOURCE CLEAR for the stated finite patch only, conditional on the separately reviewed scope implementation. Not compiled or native-qualified.** Both patches match the requested frozen SHAs. All 12 modified source files recover their exact pinned base bytes after removal of one new header include and the listed first-statement guard insertions. There are no deletions or other authored-body changes. The 4.5 patch inserts 26 scopes; 5.2 inserts 27.

## Placement reviewed

- `WM_file_read`, `wm_homefile_read_ex`, `wm_file_read_post` and `wm_homefile_read_post`: guard acquisition precedes context reads, LOAD_PRE/POST/version callbacks, Python reset, post-read evaluation and deferred home-file post handling inside these bodies. Static callback-wrapper callsites belong to the guarded load/home functions in this finite file. Nested post/reset scopes require a nesting-capable scope implementation; they must not prematurely clear an outer critical interval.
- `BKE_main_clear`, `BKE_main_free`, plus 5.2 `Main::~Main`: acquisition precedes Main/ID iteration and explicit body cleanup. `BKE_main_free`'s outer guard remains active through its `MEM_delete` call.
- ID deletion/free paths: `BKE_id_free_ex`, central `id_free`, batch `id_delete`, libblock data/datablock/runtime free and Python-release entry acquire before the selected reference remap, type-specific free, property/runtime destruction and Python-release operations. The earlier ID-free prefix is not left outside the central free scope.
- Undo: the three shared editor direction/name/index functions hold a scope across their PRE/decode/POST work; the selected editor push/grouped-push/history/repeat/operator entry functions guard their early stack clearing, callback and undo work. Backend `undosys_step_decode` acquires before ID-ref traversal, possible recursive memfile decode, native step decode and active-memfile bookkeeping.
- `BPY_python_reset`: acquisition is before `BPY_driver_reset`, app-handler reset and user-module load, covering the identified decrement/finalizer interval within this function body.

No obvious early-body bypass was found for those selected bodies/callback chains. Added includes follow the neighboring BKE include order. The proof assumes `MainReadCriticalScope` itself is nonallocating, callback-free, correctly nested, main-thread-aware and fail-closed; its implementation/API, CMake/linking and build compatibility are the parent's separate review.

## Required limits, not universal coverage

1. A local RAII object in 5.2 `Main::~Main` is destroyed at the end of the destructor **body**, before implicit nonstatic-member/base destruction and deallocation. Ordinary `BKE_main_free` supplies an outer scope across `MEM_delete`, and the split-Main cleanup is inside the guarded destructor body. This six-file review does not prove every direct deletion/caller or that every implicit member cleanup is callback-free. Do not claim the body guard alone covers the entire C++ delete lifetime.
2. `undo_system.cc` still exposes backend encode/free/clear routes, including `undosys_step_encode`, `undosys_step_free_and_unlink` and public `BKE_undosys_*` entry functions, without new local guards. Canonical selected editor pushes and WM load paths supply outer scopes, but this finite review does not prove every outside backend caller uses them. This is a coverage limit for a future general native phase assertion; the request's backend target is decode.
3. These insertions do not prove all Main/ID/ViewLayer/IDProperty mutation, allocation/free, import, save, callback, worker-thread or shutdown paths throughout Blender. They also do not establish a raw membership walk, payload bounds, pointer/UID ABA handling, immutable result encoding, ABI/source-build identity, source completeness or supported Python capsule exposure.

The current prebuilt Blender binaries remain unqualified for this proposed API. No compiler, linker, native process, Blender, tests, network or commit was invoked during this independent review. No product source or phase patch was edited. All holds and all fourteen stable gates remain open.
