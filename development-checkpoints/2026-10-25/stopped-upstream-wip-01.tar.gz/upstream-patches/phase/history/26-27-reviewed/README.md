# Exact-source native phase guard hunks

Source-only proposal, 2026-10-25. These hunks are not applied to a Blender build,
compiled, loaded or qualified. No source/API/ABI support is credited to the
currently installed official Blender binaries. Parent owns the implementation of
`blender::bke::MainReadCriticalScope` in `BKE_main_read_snapshot.hh` and its private
native counter/epoch; these hunks supply lifecycle placement only.

Use only the two `FULLCOMMIT.phase.patch` files in this directory. `history/`
contains superseded review stages and must not be applied. `base/` retains twelve
complete upstream files; `modified/` contains the exact expected patched files.
`source-identities.json` matches every base file to the GitHub plugin Contents API
Git blob at its full upstream commit.

| Exact upstream ref | Files | Guard entries | Final patch SHA-256 |
| --- | --- | --- | --- |
| `62c1db4208e862312bc36db5bc15d4a6dbcfa3e3` | 6 | 26 | `47d7a01379727b772bf63135d12a6c0ccbfe4e011f41e84d2b13272233bb6cb9` |
| `d13f752e3b9c4f8c261cda552b1021f8bcc0382c` | 6 | 27 | `f3e8922b06d5c3d83c9e837428b3f04217a88538238187ceaa02261e5d1ba3ba` |

## Placement contract

Every selected function receives the same real C++ RAII declaration as its first
statement, before existing assertions, local initialization, callback dispatch or
reference clearing. One matching header is added to each translation unit. No
existing statement, signature, branching, return, callback, preference or global
catalog policy is removed or changed. Removing only these added lines reproduces
the original twelve source files byte-for-byte.

- **File replacement:** `WM_file_read` precedes its LOAD_PRE wrapper;
  `wm_homefile_read_ex` precedes setup/preferences/script activity;
  `wm_file_read_post` covers reset/post callbacks; `wm_homefile_read_post` covers
  the separately callable deferred home-file post path.
- **Main lifetime:** `BKE_main_free` and `BKE_main_clear` are covered. The 5.2
  `Main::~Main` also has a scope before its split-Main deletion and clear work,
  because direct C++ destruction can bypass the public free wrapper.
- **ID destruction:** `BKE_id_free_ex`, underlying recursive `id_free`, batch
  `id_delete`, `BKE_libblock_free_data`, `BKE_libblock_free_datablock`,
  `BKE_libblock_free_runtime_data` and `BKE_libblock_free_data_py` are covered.
  Batch deletion calls `id_free` directly and therefore cannot be credited to a
  guard in `BKE_id_free_ex` alone. The Py-data free scope precedes its native
  Python-reference release.
- **Undo/redo:** the shared direction/name/index functions cover all three
  concrete `ed_undo_step_pre` and all three `ed_undo_step_post` callsites in each
  pinned editor file. Public exec/history/repeat/push entries also cover earlier
  operator-stack clearing, push/eviction and their remaining refresh work.
  `undosys_step_decode` covers backend ID-reference callbacks and recursive decode
  when callers bypass the editor wrapper.
- **Python reset:** `BPY_python_reset` enters before `BPY_driver_reset` and
  `BPY_app_handlers_reset`, rather than relying on a later Python LOAD_POST hook.

Nested scopes are intentional: outer scopes cover the whole operation while
central lower-level scopes catch bypass/direct paths within these selected files.
The parent implementation must support nesting and background temporary-Main free
contexts without blocking native locks across callbacks that can acquire the GIL.
There is no Python-settable phase boolean in these hunks. Whether the complete
parent implementation is unforgeable and lifetime-safe still requires review and
native qualification.

## What passed

`static-verification.json` and `insertion-manifest.json` retain exact source hashes
and line/body anchors. The standard-library generator checked:

- Exact source recovery after removing only the include/RAII insertions.
- Unique function definition matches and the guard as first statement with the
  enclosing C++ body extending to the recorded closing brace.
- Forward `git apply --check`, actual application in a fresh copy outside any Git
  worktree, exact byte equality to `modified/`, and reverse apply checks.
- Whitespace checks and the six concrete editor PRE/POST callsites per ref lying
  within the three guarded shared editor scopes.
- Both Python reference-clearing calls lying after the reset guard.

No C++ parser/compiler, native application or Blender test was run. The lexical
scope checker is a finite source-structure check, not C++ semantic acceptance.
The first tooling attempt incorrectly expected `git diff --no-index --check` to
return zero for differing directories; it emits no errors but returns one. That
failed tooling status and its unchanged source patch are retained in history.
Later checks explicitly accept only zero/one with empty stdout/stderr, in addition
to independent apply/roundtrip equality.

## Mandatory uncompiled gates and uncovered boundary

These six-file changes do not enumerate every Main replacement, ID data swap,
ViewLayer rebuild, library link/append, reload, teardown or third-party native
writer. They do not establish that every legal source path enters a guarded
scope. In particular, a future full-tree review must identify direct
`G_MAIN` replacement, low-level blendfile setup/memfile readers invoked outside
these wrappers, and other ownership/lifetime-changing APIs. Additional guards or
explicit API refusal may be required. Do not enable a snapshot capability merely
because these selected entry points are covered.

The parent must provide the actual header/counter/API implementation, CMake
membership, build/toolchain/header/config pins, overflow and nested-scope policy,
main-thread/GIL acquisition, and authoritative Main capture only after all input
conversion and allocation. Raw-copy code must invoke no callbacks/getters/
ensure/update, perform no authored writes, and discard native pointers before
Python result/error allocation. Native tests must then prove BUSY/refusal during
reentrant load/free/undo/reset, normal post-phase success, error/early-return
scope release, temporary-Main background behavior, and unchanged raw USER/SYSTEM,
Base and LayerCollection state. Existing official binaries remain unqualified.

This proposal does not implement safe project saving or control asset-catalog
callbacks. It does not restore memory, undo, change pointers, unpause Windows
work, run held reproductions or close any of the fourteen stable gates.

## Licensing and origin

All retained upstream source files keep their original Blender SPDX notices
(`GPL-2.0-or-later`) unchanged. The C++ patch additions are proposed for those
same upstream GPL-2.0-or-later files. The bridge's own repository license remains
unchanged. The parent must retain notices and source/build instructions for any
future distribution; no binary is distributed by this source-only proposal.
