import difflib
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COMMITS = ("62c1db4208e862312bc36db5bc15d4a6dbcfa3e3", "d13f752e3b9c4f8c261cda552b1021f8bcc0382c")
TARGETS = {
    "source/blender/windowmanager/intern/wm_files.cc": (
        "WM_file_read",
        "wm_homefile_read_ex",
        "wm_file_read_post",
        "wm_homefile_read_post",
    ),
    "source/blender/blenkernel/intern/main.cc": ("BKE_main_free", "BKE_main_clear"),
    "source/blender/blenkernel/intern/lib_id_delete.cc": (
        "BKE_id_free_ex",
        "id_free",
        "id_delete",
        "BKE_libblock_free_data",
        "BKE_libblock_free_datablock",
        "BKE_libblock_free_runtime_data",
        "BKE_libblock_free_data_py",
    ),
    "source/blender/blenkernel/intern/undo_system.cc": (
        "undosys_step_decode",
        "undosys_step_encode",
        "undosys_step_free_and_unlink",
        "BKE_undosys_step_push_init_with_type",
    ),
    "source/blender/editors/undo/ed_undo.cc": (
        "ED_undo_push",
        "ED_undo_grouped_push",
        "ed_undo_step_direction",
        "ed_undo_step_by_name",
        "ed_undo_step_by_index",
        "ed_undo_exec",
        "ed_undo_push_exec",
        "ed_redo_exec",
        "ed_undo_redo_exec",
        "ED_undo_operator_repeat",
        "undo_history_exec",
    ),
    "source/blender/python/intern/bpy_interface.cc": ("BPY_python_reset",),
}
GUARD = "  blender::bke::MainReadCriticalScope read_snapshot_critical;\n"
INCLUDE = '#include "BKE_main_read_snapshot.hh"\n'


def function_open(s, name):
    # Definitions in this finite six-file set start at column zero. Parameters may
    # span lines; semicolons and braces exclude declarations and ordinary calls.
    pattern = re.compile(
        (r"(?m)^" + re.escape(name) + r"\s*\([^;{}]*\)\s*\{")
        if "::~" in name
        else (r"(?m)^[^ \t#\n][^;{}\n]*\b" + re.escape(name) + r"\s*\([^;{}]*\)\s*\{")
    )
    matches = list(pattern.finditer(s))
    assert len(matches) == 1, (name, len(matches))
    return matches[0].end() - 1


def body_close(s, opening):
    # Small lexical scanner, not a C++ parser. Used only for balanced body/scope
    # checks; no source rewriting relies on inferred types or compiled layouts.
    depth = 0
    i = opening
    state = "code"
    while i < len(s):
        a = s[i]
        b = s[i : i + 2]
        if state == "line":
            if a == "\n":
                state = "code"
        elif state == "block":
            if b == "*/":
                state = "code"
                i += 1
        elif state in ('"', "'"):
            if a == "\\":
                i += 1
            elif a == state:
                state = "code"
        elif b == "//":
            state = "line"
            i += 1
        elif b == "/*":
            state = "block"
            i += 1
        elif a in ('"', "'"):
            state = a
        elif a == "{":
            depth += 1
        elif a == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise AssertionError("Unbalanced function body")


rows = []
patches = []
for commit in COMMITS:
    patch = ""
    for name, functions in TARGETS.items():
        path = ROOT / "base" / commit / name
        before = path.read_text()
        assert INCLUDE not in before and GUARD not in before
        if name.endswith("/main.cc") and "Main::~Main()" in before:
            functions = (*functions, "Main::~Main")
        after = before
        anchors = []
        # Insert from the end so exact source offsets remain valid.
        points = [(function_open(before, n), n) for n in functions]
        for opening, n in sorted(points, reverse=True):
            assert before[opening : opening + 2] == "{\n", (name, n)
            after = after[: opening + 2] + GUARD + after[opening + 2 :]
        main_includes = re.findall(r'(?m)^#include "BKE_main[^"]*\.hh"\n', after)
        assert main_includes, name
        include_anchor = sorted(main_includes)[-1]
        assert after.count(include_anchor) == 1, name
        after = after.replace(include_anchor, include_anchor + INCLUDE, 1)
        assert after.replace(INCLUDE, "").replace(GUARD, "") == before
        assert after.count(GUARD) == len(functions)
        for n in functions:
            opening = function_open(after, n)
            closing = body_close(after, opening)
            assert after[opening + 2 : opening + 2 + len(GUARD)] == GUARD
            anchors.append(
                {
                    "function": n,
                    "base_line": before.count("\n", 0, function_open(before, n)) + 1,
                    "modified_line": after.count("\n", 0, opening) + 1,
                    "guard_first_statement": True,
                    "guard_scope_ends_at_line": after.count("\n", 0, closing) + 1,
                }
            )
        dest = ROOT / "modified" / commit / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(after)
        diff = "".join(
            difflib.unified_diff(
                before.splitlines(True),
                after.splitlines(True),
                fromfile="a/" + name,
                tofile="b/" + name,
                n=3,
            )
        )
        patch += "diff --git a/" + name + " b/" + name + "\n" + diff
        rows.append(
            {
                "commit": commit,
                "path": name,
                "base_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "modified_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
                "inserted_guards": len(functions),
                "functions": anchors,
                "only_guard_and_header_insertions": True,
            }
        )
    dest = ROOT / (commit + ".phase.patch")
    dest.write_text(patch)
    patches.append(
        {
            "commit": commit,
            "patch": dest.name,
            "bytes": dest.stat().st_size,
            "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
            "guard_count": sum(r["inserted_guards"] for r in rows if r["commit"] == commit),
        }
    )
    # Check against copies outside any Git worktree. No upstream source repository
    # or bridge checkout is modified and no Git commit is created.
    check = Path("/tmp") / (
        "blender-codex-native-phase-patch-check-" + commit[:12] + "-20261025-attempt6"
    )
    assert not check.exists()
    shutil.copytree(ROOT / "base" / commit, check)
    for args in (
        ["git", "apply", "--check", str(dest)],
        ["git", "apply", str(dest)],
        ["git", "apply", "--reverse", "--check", str(dest)],
    ):
        subprocess.run(args, cwd=check, check=True, capture_output=True)
    for name in TARGETS:
        assert (check / name).read_bytes() == (ROOT / "modified" / commit / name).read_bytes()
    diffcheck = subprocess.run(
        [
            "git",
            "diff",
            "--no-index",
            "--check",
            str(ROOT / "base" / commit),
            str(ROOT / "modified" / commit),
        ],
        capture_output=True,
    )
    assert diffcheck.returncode in (0, 1) and not diffcheck.stdout and not diffcheck.stderr, (
        diffcheck.returncode,
        diffcheck.stdout.decode(),
        diffcheck.stderr.decode(),
    )
    # Every concrete pre/post call in ed_undo.cc lies inside one of the three
    # guarded shared edit functions. The check does not claim external callsites.
    ed = (ROOT / "modified" / commit / "source/blender/editors/undo/ed_undo.cc").read_text()
    ranges = [
        (function_open(ed, n), body_close(ed, function_open(ed, n)))
        for n in ("ed_undo_step_direction", "ed_undo_step_by_name", "ed_undo_step_by_index")
    ]
    for callback in ("ed_undo_step_pre", "ed_undo_step_post"):
        matches = [m for m in re.finditer(r"(?m)^  " + callback + r"\(", ed)]
        assert len(matches) == 3
        assert all(any(a < m.start() < b for a, b in ranges) for m in matches)
    for callback, fn in [
        ("BPY_driver_reset", "BPY_python_reset"),
        ("BPY_app_handlers_reset", "BPY_python_reset"),
    ]:
        s = (
            ROOT / "modified" / commit / "source/blender/python/intern/bpy_interface.cc"
        ).read_text()
        a = function_open(s, fn)
        b = body_close(s, a)
        assert a + len(GUARD) < s.index(callback + "(", a, b) < b
(ROOT / "insertion-manifest.json").write_text(json.dumps(rows, indent=2) + "\n")
(ROOT / "static-verification.json").write_text(
    json.dumps(
        {
            "status": "SOURCE_PATCH_STATIC_CHECKS_PASS_UNCOMPILED",
            "patches": patches,
            "source_files": len(rows),
            "total_guard_insertions": sum(x["inserted_guards"] for x in rows),
            "exact_source_recovery_after_removing_only_insertions": True,
            "git_apply_check_and_forward_and_reverse_check": True,
            "patched_bytes_equal_expected_modified_files": True,
            "git_diff_check_passed": True,
            "editor_PRE_POST_callsites_in_three_guarded_shared_scopes_per_ref": True,
            "Python_ref_clearing_calls_after_reset_guard_per_ref": True,
            "CXX_compile_or_Blender_executed": False,
            "native_phase_coverage_qualified": False,
            "check_copies_retained_under_tmp": True,
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "patches": patches,
            "source_files": len(rows),
            "total_guard_insertions": sum(x["inserted_guards"] for x in rows),
        }
    )
)
