from __future__ import annotations
import difflib
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COMMITS = ('62c1db4208e862312bc36db5bc15d4a6dbcfa3e3',
           'd13f752e3b9c4f8c261cda552b1021f8bcc0382c')
NEW = {
    'BKE_main_read_snapshot.hh': 'source/blender/blenkernel/BKE_main_read_snapshot.hh',
    'main_read_snapshot.cc': 'source/blender/blenkernel/intern/main_read_snapshot.cc',
    'bpy_main_read_snapshot.hh': 'source/blender/python/intern/bpy_main_read_snapshot.hh',
    'bpy_main_read_snapshot.cc': 'source/blender/python/intern/bpy_main_read_snapshot.cc',
}


def change(text: str, old: str, new: str) -> str:
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main() -> None:
    reports = []
    for commit in COMMITS:
        base = ROOT / 'base' / commit
        modified = ROOT / 'modified' / commit
        modified.mkdir(parents=True, exist_ok=True)
        for p in base.rglob('*'):
            if p.is_file():
                q = modified / p.relative_to(base)
                q.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, q)
        phase_base = ROOT / 'phase/base' / commit
        phase_modified = ROOT / 'phase/modified' / commit
        for p in phase_base.rglob('*'):
            if p.is_file():
                name = p.relative_to(phase_base)
                original = base / name
                original.parent.mkdir(parents=True, exist_ok=True)
                if original.exists():
                    assert original.read_bytes() == p.read_bytes()
                else:
                    shutil.copyfile(p, original)
                q = modified / name
                q.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(phase_modified / name, q)
        for common, name in NEW.items():
            q = modified / name
            q.parent.mkdir(parents=True, exist_ok=True)
            assert not (base / name).exists()
            shutil.copyfile(ROOT / 'common' / common, q)
        p = modified / 'CMakeLists.txt'
        p.write_text(change(p.read_text(),
            'option(WITH_PYTHON "Enable Embedded Python API (only disable for development)" ON)',
            'option(WITH_PYTHON "Enable Embedded Python API (only disable for development)" ON)\n'
            'option(WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT\n'
            '  "Unqualified developer-only raw Main snapshot API; never enable in release builds" OFF)\n'
            'mark_as_advanced(WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT)\n'
            'if(WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT)\n'
            '  if(NOT WITH_PYTHON)\n'
            '    message(FATAL_ERROR "Experimental Main snapshot requires WITH_PYTHON")\n'
            '  endif()\n'
            '  add_definitions(-DWITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT)\n'
            'endif()'))
        p = modified / 'source/blender/blenkernel/CMakeLists.txt'
        s = change(p.read_text(), '  intern/main.cc\n',
                   '  intern/main.cc\n  intern/main_read_snapshot.cc\n')
        p.write_text(change(s, '  BKE_main.hh\n',
                            '  BKE_main.hh\n  BKE_main_read_snapshot.hh\n'))
        p = modified / 'source/blender/python/intern/CMakeLists.txt'
        s = change(p.read_text(), '  bpy.cc\n',
                   '  bpy.cc\n  bpy_main_read_snapshot.cc\n')
        p.write_text(change(s, '  bpy_rna.hh\n',
                            '  bpy_rna.hh\n  bpy_main_read_snapshot.hh\n'))
        p = modified / 'source/blender/python/intern/bpy.cc'
        s = change(p.read_text(), '#include "bpy.hh"\n',
                   '#include "bpy.hh"\n#include "bpy_main_read_snapshot.hh"\n')
        p.write_text(change(s, 'static PyMethodDef bpy_methods[] = {\n',
            'static PyMethodDef bpy_methods[] = {\n'
            '#ifdef WITH_EXPERIMENTAL_MAIN_READ_SNAPSHOT\n'
            '    {"_readonly_snapshot_v1",\n'
            '     (PyCFunction)BPY_main_read_snapshot_v1,\n'
            '     METH_NOARGS,\n'
            '     "Experimental bounded raw subset snapshot; not whole Main or write authority."},\n'
            '#endif\n'))
        changed = []
        chunks = []
        for p in sorted(modified.rglob('*')):
            if not p.is_file():
                continue
            name = str(p.relative_to(modified))
            old = base / name
            before = old.read_text() if old.exists() else ''
            after = p.read_text()
            if before == after:
                continue
            changed.append({'path': name, 'added': not old.exists(),
                            'before_sha256': hashlib.sha256(before.encode()).hexdigest()
                                             if old.exists() else None,
                            'after_sha256': hashlib.sha256(after.encode()).hexdigest()})
            chunks.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                fromfile='a/' + name if old.exists() else '/dev/null',
                tofile='b/' + name))
        patch = ROOT / (commit + '.patch')
        patch.write_text(''.join(chunks))
        reports.append({'commit': commit, 'patch': patch.name, 'bytes': patch.stat().st_size,
                        'sha256': hashlib.sha256(patch.read_bytes()).hexdigest(),
                        'changed': changed})
    (ROOT / 'generated-patches.json').write_text(json.dumps(reports, indent=2) + '\n')
    print(json.dumps([{'commit': r['commit'], 'patch_bytes': r['bytes'],
                       'changed_paths': len(r['changed']), 'patch_sha256': r['sha256']}
                      for r in reports]))


if __name__ == '__main__':
    main()
