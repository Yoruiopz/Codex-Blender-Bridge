# Development evidence for Blender Codex Bridge 0.9.1 alpha

Exact-commit CI passed all seven jobs. The accepted CI packages passed all four installed static combinations and both build upgrade/rollback components. Four original synthetic previews were reviewed. Standalone installed MCP Python: 3.12.14. The optional MCP server OS PID was not observed; client/Blender/preview/fresh-reader identities and byte pins were independently verified.

This archive contains a curated numerical summary, public candidate-only source bundle, twelve qualification-support source files, and four reviewed synthetic geometry PNGs. It excludes raw logs, projects, preferences, recovery backups, dependency environments and private task ledgers. Full private evidence and failed-attempt records are retained separately.

The source bundle reproduces commit 4c1c66ad4d134ed042a3da55deca931def3c898a. Restore it with:

    git clone --branch resume31-release-0.9.1 source/release-0.9.1-source.bundle restored-source

Qualification helpers are separate from the product commit. Installed static-flow support is revision 149b901cec0c5e1a5dfd9d16a0005f74686d1486; history support is 16b7b96f0ee11988cbee3dd9b7257f5911f59f6e; upgrade support is e38682de59762d0b057818c43f30ea7eaa7143f3. Their exact file bytes and roles are recorded in MANIFEST.json. They do not change the installed add-on or MCP package. Apply only the relevant support files to a separate source checkout for fixture reproduction, preserving candidate package pins; they are not product installers.

The historical local full suite and source-native runs identify their actual commits. All 271 add-on/MCP payload files and applicable native fixture code are unchanged in the release candidate. The complete matrix and installed tests must identify the final accepted commit/package hashes; local prerequisite packages are excluded from acceptance.

The installed static scenario uses real wheel MCP stdio, literal 127.0.0.1 transport, registered main-thread timers and original Blender-side permission providers. Only the owned disposable fixture grants local consent. It creates/transforms/inspects/previews/saves one untextured Cube and verifies the same asset in the product fresh reader. This is a success scenario; component denial/interruption evidence is separate. Upgrade/rollback component checks use internal dispatch and manual ticks and do not certify the whole artist interaction loop or preference migration.

PNG previews certify neutral geometry only. They do not preserve or certify original materials, lighting, viewport appearance or ordinary project admission. All 29 implementation items and 14 stable gates remain open. Windows testing/compatibility is deferred and unverified; macOS is unqualified. This archive is alpha evidence, not stable 1.0 acceptance.
