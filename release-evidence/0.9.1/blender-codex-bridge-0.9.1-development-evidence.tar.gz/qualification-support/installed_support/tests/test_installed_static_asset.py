"""Qualification-driver models; these never claim installed/native acceptance."""
from __future__ import annotations

import ast
import asyncio
import base64
import hashlib
import importlib.util
import json
import re
import struct
import sys
import zlib
from pathlib import Path
from types import SimpleNamespace as NS
from zipfile import ZipFile

import pytest

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location("_static_asset_model_" + name, ROOT / "scripts" / (name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def published_tool_names():
    # The support branch retains five development-only GLB candidates. The
    # selected release surface is exactly the previously published 270 names.
    candidates = {"asset.glb_stage_preview", "asset.glb_stage_create_start", "asset.glb_stage_inspect",
                  "asset.glb_stage_publish_preview", "asset.glb_stage_publish_start"}
    names = sorted(set(re.findall(r"^\| `([a-z][a-z0-9_]*(?:\.[a-z_][a-z0-9_]*)+)` \|",
                                  (ROOT / "README.md").read_text(), re.M)) - candidates)
    assert len(names) == 270
    return names


@pytest.fixture
def config_model(tmp_path):
    module = load("static_asset_probe_config")
    names = published_tool_names()
    tools = tmp_path / "tool names.json"
    tools.write_text(json.dumps(names))
    digest = module.sha(tools)
    candidate = tmp_path / "candidate.zip"
    candidate.write_bytes(b"modeled ZIP bytes; Blender archive verifier is separate")
    wheel = tmp_path / "candidate.whl"
    with ZipFile(wheel, "w") as archive:
        archive.writestr("mcp_server/__init__.py", '__version__ = "0.9.1"\n')
        archive.writestr("blender_codex_bridge-0.9.1.dist-info/METADATA", "Name: blender-codex-bridge\nVersion: 0.9.1\n")
    prefix = tmp_path / "venv with spaces"
    (prefix / "bin").mkdir(parents=True)
    (prefix / "pyvenv.cfg").write_text("home = /modeled\n")
    python = prefix / "bin/python"
    python.write_bytes(b"never executed modeled interpreter")
    python.chmod(0o700)
    value = {"schema": module.SCHEMA, "version": "0.9.1", "sdk_version": "2.2.0", "expected_tools": names,
        "candidate": {"path": str(candidate), "sha256": module.sha(candidate), "version": "0.9.1",
            "expected_tools": 270, "expected_tool_names": names, "expected_tool_names_sha256": digest,
            "expected_tool_names_canonical_sha256": module.tool_names_sha256(names),
            "expected_tool_names_source": str(tools)}, "wheel": module.wheel_record(wheel),
        "python": module.python_record(python)}
    path = tmp_path / "configuration.json"
    return NS(module=module, value=value, path=path, tmp=tmp_path)


def write_model(model):
    model.path.write_text(json.dumps(model.value))
    return model.path


def test_static_asset_helpers_cold_import_without_blender_or_side_effects(monkeypatch):
    class Foreign:
        def __getattribute__(self, name):
            pytest.fail("Cold driver touched Blender: " + name)
    monkeypatch.setitem(sys.modules, "bpy", Foreign())
    for name in ("blender_installed_static_asset_smoke", "installed_static_asset_client", "static_asset_probe_config"):
        assert load(name) is not None


def test_static_asset_config_retains_exact_inputs_and_private_derived_output(config_model):
    e = config_model
    assert e.module.load_config(write_model(e)) == e.value
    e.value["output_dir"] = str(e.tmp)
    assert e.module.load_config(write_model(e), allow_output=True) == e.value
    with pytest.raises(ValueError, match="SCHEMA"):
        e.module.load_config(e.path)


@pytest.mark.parametrize("indent", [None, 2])
def test_static_asset_config_distinguishes_published_names_from_raw_json_bytes(config_model, indent):
    e = config_model
    source = Path(e.value["candidate"]["expected_tool_names_source"])
    source.write_text(json.dumps(e.value["expected_tools"], indent=indent) + "\n")
    raw_digest = e.module.sha(source)
    e.value["candidate"]["expected_tool_names_sha256"] = raw_digest
    accepted = e.module.load_config(write_model(e))
    assert accepted["candidate"]["expected_tool_names_canonical_sha256"] == e.module.EXPECTED_TOOLS_SHA256
    assert accepted["candidate"]["expected_tool_names_sha256"] == raw_digest
    assert raw_digest != e.module.EXPECTED_TOOLS_SHA256
    assert e.module.tool_names_sha256(accepted["expected_tools"]) == "1cb16ea5e7320962bc0be5d886bf76724e59ed548e9bc2808b5bff7e3d3b9c1e"


@pytest.mark.parametrize("fault", ["raw_bytes", "canonical_field", "coherent_name_change"])
def test_static_asset_config_keeps_raw_and_canonical_drift_checks_separate(config_model, fault):
    e = config_model
    source = Path(e.value["candidate"]["expected_tool_names_source"])
    if fault == "raw_bytes":
        source.write_text(source.read_text() + "\n")
    elif fault == "canonical_field":
        e.value["candidate"]["expected_tool_names_canonical_sha256"] = "0" * 64
    else:
        names = sorted([*e.value["expected_tools"][:-1], "fixture.not_a_published_tool"])
        e.value["expected_tools"] = e.value["candidate"]["expected_tool_names"] = names
        source.write_text(json.dumps(names))
        e.value["candidate"]["expected_tool_names_sha256"] = e.module.sha(source)
        e.value["candidate"]["expected_tool_names_canonical_sha256"] = e.module.tool_names_sha256(names)
    with pytest.raises(ValueError):
        e.module.load_config(write_model(e))


@pytest.mark.parametrize("fault", ["version", "sdk", "count", "names", "tool_hash", "candidate", "wheel", "python", "extra"])
def test_static_asset_config_rejects_drift_or_unaccepted_surface(config_model, fault):
    e = config_model
    if fault == "version":
        e.value["version"] = "0.9.0"
    elif fault == "sdk":
        e.value["sdk_version"] = "2.1.0"
    elif fault == "count":
        e.value["candidate"]["expected_tools"] = 275
    elif fault == "names":
        e.value["expected_tools"] = e.value["expected_tools"][:-1]
    elif fault == "tool_hash":
        e.value["candidate"]["expected_tool_names_sha256"] = "0" * 64
    elif fault == "candidate":
        Path(e.value["candidate"]["path"]).write_bytes(b"different ZIP")
    elif fault == "wheel":
        e.value["wheel"]["sha256"] = "0" * 64
    elif fault == "python":
        e.value["python"]["sha256"] = "0" * 64
    else:
        e.value["grant_permissions"] = True
    with pytest.raises(ValueError):
        e.module.load_config(write_model(e))


def png():
    def chunk(kind, value):
        return struct.pack(">I", len(value)) + kind + value + struct.pack(">I", zlib.crc32(kind + value) & 0xffffffff)
    rows = b"".join(b"\0" + bytes((10, 20, 30, 255)) * 128 for _ in range(128))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 128, 128, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def test_static_asset_client_png_verifies_complete_rows_and_crc():
    client = load("installed_static_asset_client")
    data = png()
    raw, proof = client.png_proof(base64.b64encode(data).decode())
    assert raw == data and proof["sha256"] == hashlib.sha256(data).hexdigest()
    assert proof["width"] == proof["height"] == 128 and proof["compressed_rows_verified"]
    damaged = data[:-1] + bytes((data[-1] ^ 1,))
    with pytest.raises(ValueError):
        client.png_proof(base64.b64encode(damaged).decode())


def test_static_asset_client_accepts_only_bounded_json_and_png_mcp_content():
    client = load("installed_static_asset_client")
    assert client.response_value({"content": [{"type": "text", "text": '{"ok":true}'}]}) == ({"ok": True}, None)
    value, image = client.response_value({"structuredContent": {"preview_id": "x"},
        "content": [{"type": "image", "mimeType": "image/png", "data": "AA=="}]})
    assert value == {"preview_id": "x"} and image == "AA=="
    for response in ({"isError": True, "content": []}, {"structuredContent": [], "content": []},
            {"content": [{"type": "text", "text": '{"bad":NaN}'}]},
            {"structuredContent": {}, "content": [{"type": "image", "mimeType": "image/jpeg", "data": "x"}]}):
        with pytest.raises(ValueError):
            client.response_value(response)


def test_static_asset_client_forwards_toolset_name_without_argument_collision():
    client = load("installed_static_asset_client")
    calls = []
    class MCP:
        async def call_tool(self, method, params):
            calls.append((method, params))
            return {"structuredContent": {"enabled": True}, "content": []}
    import time
    proof = {"calls": []}
    flow = client.Flow({}, proof, time.monotonic())
    assert asyncio.run(flow.result(MCP(), "toolsets.enable", name="objects")) == {"enabled": True}
    assert calls == [("toolsets.enable", {"name": "objects"})] and len(proof["calls"]) == 1


def test_static_asset_client_report_never_overwrites_existing_evidence(tmp_path):
    client = load("installed_static_asset_client")
    path = tmp_path / "report.json"
    client.write_report(path, {"completed": False})
    original = path.read_bytes()
    with pytest.raises(FileExistsError):
        client.write_report(path, {"completed": True})
    assert path.read_bytes() == original


def test_static_asset_controller_refuses_checkout_product_imports(tmp_path, monkeypatch):
    fixture = load("blender_installed_static_asset_smoke")
    installed = tmp_path / "installed/blender_codex_bridge"
    installed.mkdir(parents=True)
    checkout = tmp_path / "checkout/runtime.py"
    checkout.parent.mkdir()
    checkout.write_text("# should never be imported\n")
    monkeypatch.setitem(sys.modules, "blender_codex_bridge.runtime", NS(__file__=str(checkout)))
    with pytest.raises(ValueError, match="CHECKOUT_IMPORT"):
        fixture.imported_modules(installed, {})


def test_static_asset_controller_has_no_manual_or_alternative_execution_path():
    path = ROOT / "scripts/blender_installed_static_asset_smoke.py"
    tree = ast.parse(path.read_text())
    forbidden = {"dispatch", "tick", "_drain_timer", "PermissionManager", "execute_request", "keyframe_insert"}
    assert not any(isinstance(node, ast.Call) and
                   ((isinstance(node.func, ast.Attribute) and node.func.attr in forbidden)
                    or (isinstance(node.func, ast.Name) and node.func.id in forbidden)) for node in ast.walk(tree))
    # Local consent is a fixture action, after listener start. The MCP client
    # has no grant or preference API and the support driver creates no new one.
    source = path.read_text()
    assert source.index('runtime.start_server("127.0.0.1"') < source.index("runtime.arm_native_save_effects(300)")
    client_tree = ast.parse((ROOT / "scripts/installed_static_asset_client.py").read_text())
    assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                   and node.func.attr in {"arm_native_save_effects", "dispatch", "tick"} for node in ast.walk(client_tree))
