"""One installed MCP-to-Blender static-asset flow, on an owned private display.

No product imports occur at module import. Only the isolated runner launches this
fixture; the external client uses the accepted wheel and actual stdio transport.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib
import json
import os
import socket
import stat
import subprocess
import sys
import time
import traceback
from pathlib import Path

SCHEMA = "installed_static_asset_flow_v1"
MARKER = "BLENDER_INSTALLED_STATIC_ASSET_FLOW_OK "
REPORT_NAME = "installed-static-asset-flow.json"
OBJECT_NAME = "Installed Static Prop"
MAX_REPORT = 8 * 1024**2
MAX_SECONDS = 300
SOURCES = ("scripts/blender_installed_static_asset_smoke.py", "scripts/installed_static_asset_client.py",
           "scripts/static_asset_probe_config.py", "scripts/run_blender_checks.py",
           "scripts/blender_installed_addon_probe_smoke.py", "scripts/package_probe_config.py",
           "scripts/blender_native_save_smoke.py")
LIMITATIONS = ["ONE_OWNED_UNTEXTURED_STATIC_CUBE_ONLY", "FLAT_GEOMETRY_PNG_NOT_ORIGINAL_APPEARANCE",
              "OWNED_FACTORY_CLEANUP_NOT_ORDINARY_STARTUP_SAVE_SUPPORT",
              "NATIVE_SAVE_EFFECTS_LOCALLY_ARMED_BY_OWNED_FIXTURE",
              "SUCCESS_FLOW_ONLY_COMPONENT_FAILURE_ACCEPTANCE_SEPARATE",
              "NO_MATERIAL_TEXTURE_RIG_ANIMATION_GLB_FBX_OR_WINDOWS_QUALIFICATION",
              "ALL_29_IMPLEMENTATION_ITEMS_AND_14_STABLE_GATES_REMAIN_OPEN"]


def sha(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            checksum.update(block)
    return checksum.hexdigest()


def fingerprints(root):
    return {name: sha(Path(root) / name) for name in SOURCES}


def binding(path):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= 256 * 1024**2:
        raise ValueError("STATIC_FLOW_FILE_BINDING")
    return {"path": str(path), "bytes": info.st_size, "sha256": sha(path)}


def imported_modules(installed, members):
    """Bind every actual product import to the installed archive member."""
    result = {}
    for name, module in tuple(sys.modules.items()):
        if name == "blender_codex_bridge" or name.startswith("blender_codex_bridge."):
            path = Path(module.__file__).resolve(strict=True)
            if not path.is_relative_to(installed.resolve()):
                raise ValueError("STATIC_FLOW_CHECKOUT_IMPORT:" + name)
            member = path.relative_to(installed.parent).as_posix()
            digest = sha(path)
            if digest != members.get(member):
                raise ValueError("STATIC_FLOW_IMPORTED_MEMBER_CHANGED:" + name)
            result[name] = {"path": str(path), "sha256": digest}
    if "blender_codex_bridge.runtime" not in result:
        raise ValueError("STATIC_FLOW_INSTALLED_RUNTIME_NOT_IMPORTED")
    return result


def identity(runtime):
    return {"runtime": id(runtime), "executor": id(runtime.executor),
            "permissions": id(runtime.permissions), "provider": id(runtime.permissions._source)}


def read_bounded_json(path, maximum=MAX_REPORT):
    path = Path(path)
    if path.is_symlink() or not 0 < path.stat().st_size <= maximum:
        raise ValueError("STATIC_FLOW_JSON_FILE_CAP")
    return json.loads(path.read_bytes())


def main():
    # Qualification helpers are loaded before the package search path is
    # removed. Neither of these helper modules imports bridge product code at
    # module scope. In particular the sidebar helper must not be imported.
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))
    import addon_utils
    import bpy

    from scripts import blender_installed_addon_probe_smoke as installed_probe
    from scripts import blender_native_save_smoke as save_probe
    from scripts import run_blender_checks as runner
    from scripts.static_asset_probe_config import load_config

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bridge-report", type=Path, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    report = args.bridge_report
    token = os.environ.get("BRIDGE_TEST_PROCESS_TOKEN", "")
    assert token and report.is_absolute() and report.name == REPORT_NAME
    assert report.parent == Path(os.environ["TEMP"]) and not report.exists()
    profile = report.parent.lstat()
    assert stat.S_ISDIR(profile.st_mode) and profile.st_uid == os.getuid()
    assert stat.S_IMODE(profile.st_mode) == 0o700 and not report.parent.is_symlink()
    assert not bpy.app.background and "--factory-startup" in sys.argv and "--disable-autoexec" in sys.argv
    assert (tuple(bpy.app.version), bpy.app.build_hash.decode()) in {
        ((4, 5, 14), "62c1db4208e8"), ((5, 2, 2), "d13f752e3b9c")}
    assert bpy.app.build_type == b"Release"
    display = runner._domain_display()
    source_hashes = fingerprints(root)
    config_path = Path(os.environ["BRIDGE_TEST_STATIC_ASSET_CONFIG"])
    config = load_config(config_path)
    assert not any(name == "blender_codex_bridge" or name.startswith("blender_codex_bridge.") for name in sys.modules)
    started = time.monotonic()
    proof = {"schema": SCHEMA, "completed": False, "process_instance": token, "process_id": os.getpid(),
        "blender_version": bpy.app.version_string, "source_build": bpy.app.build_hash.decode(),
        "configuration_sha256": sha(config_path), "binary": binding(Path(bpy.app.binary_path).resolve()),
        "source_fingerprints": source_hashes, "private_display": display,
        "installed": None, "client": None, "same_asset": None, "png": None, "save": None,
        "runtime": None, "client_process_id": None, "seconds": 0., "limitations": LIMITATIONS, "error": None}
    runtime = client = None
    logs = None
    prefs = None
    original_preferences = {}

    def persist():
        proof["seconds"] = time.monotonic() - started
        payload = json.dumps(proof, sort_keys=True, indent=2, allow_nan=False).encode() + b"\n"
        assert len(payload) <= MAX_REPORT
        pending = report.with_suffix(".pending")
        with pending.open("wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(pending, 0o600)
        pending.replace(report)

    def finish(status):
        # Teardown applies only to this process/profile; no fixture claims undo
        # can remove a native file or reverse unknown native save callbacks.
        try:
            if client is not None and client.poll() is None:
                client.terminate()
                try:
                    client.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    client.kill()
                    client.wait(timeout=2)
            if runtime is not None:
                runtime.stop_server()
            if prefs is not None:
                for name, value in original_preferences.items():
                    setattr(prefs, name, value)
            if logs is not None:
                logs.close()
            persist()
            if status == 0:
                summary = {key: proof[key] for key in ("schema", "completed", "process_instance", "process_id",
                    "blender_version", "source_build")}
                summary["full_receipt"] = binding(report)
                print(MARKER + json.dumps(summary, sort_keys=True), flush=True)
        finally:
            sys.stdout.flush()
            sys.stderr.flush()
            os._exit(status)

    try:
        bpy.context.preferences.use_preferences_save = False
        filepaths = bpy.context.preferences.filepaths
        filepaths.file_preview_type, filepaths.save_version = "NONE", 1
        filepaths.use_auto_save_temporary_files = False
        scripts = Path(os.environ["BLENDER_USER_SCRIPTS"]).resolve()
        inputs = report.parent / "package inputs with spaces"
        inputs.mkdir(mode=0o700)
        archive, members = installed_probe._archive(config["candidate"], inputs, "static asset candidate")
        # Remove both the qualification and product source checkout before the
        # first add-on import. Native helper references above remain local.
        checkout = root
        sys.path[:] = [entry for entry in sys.path if entry and not Path(entry).resolve().is_relative_to(checkout)]
        assert bpy.ops.preferences.addon_install(filepath=str(archive), overwrite=False) == {"FINISHED"}
        product = addon_utils.enable("blender_codex_bridge", default_set=True, persistent=False)
        assert product is not None
        installed = scripts / "addons" / "blender_codex_bridge"
        installed_probe._installed_bytes(installed, members)
        runtime = importlib.import_module("blender_codex_bridge.runtime").get_runtime()
        prefs = bpy.context.preferences.addons["blender_codex_bridge"].preferences
        fields = ("allow_inspect_scene", "allow_transform_objects", "allow_viewport_capture", "allow_save_project",
                  "allow_external_files", "project_directory")
        original_preferences = {name: getattr(prefs, name) for name in fields}
        assert prefs.auto_start is False and prefs.allow_execute_python is False and prefs.allow_delete_objects is False
        public = installed_probe._public_tool_surface(runtime.registry, config["candidate"])
        proof["installed"] = {"version": config["version"], "candidate_sha256": config["candidate"]["sha256"],
            "wheel_sha256": config["wheel"]["sha256"], "root": str(installed),
            "public_tool_names": public["public_tool_names"], "imported_modules": imported_modules(installed, members),
            "members_verified_count": len(members)}
        # Only the explicitly attested factory data is removed. Never present
        # this setup as support for saving an artist's ordinary startup file.
        removed = save_probe.clean_factory_data(bpy.data, attested=True)
        assert removed and len(bpy.data.scenes) == 1 and len(bpy.data.objects) == 0
        flow = report.parent / "static asset outputs with spaces"
        flow.mkdir(mode=0o700)
        for name in fields[:-1]:
            setattr(prefs, name, True)
        prefs.project_directory = str(flow)
        with socket.socket() as lease:
            lease.bind(("127.0.0.1", 0))
            port = lease.getsockname()[1]
        assert runtime.start_server("127.0.0.1", port, request_timeout=120.) == ("127.0.0.1", port)
        # start_server revokes prior consent. Arm only here, on Blender's main
        # thread, using the installed local UI authority after listener startup.
        runtime.arm_native_save_effects(300)
        assert runtime.permissions.snapshot()["NATIVE_SAVE_EFFECTS"] is True
        assert runtime.permissions is runtime.executor.permissions
        ids = identity(runtime)
        assert bpy.app.timers.is_registered(runtime.executor._timer_callback)
        proof["runtime"] = {"host": "127.0.0.1", "port": port, "manual_ticks": False, "direct_dispatch": False,
            "provider_replaced": False, "registered_timers": True, "locally_armed": True, "MCP_stdio": False,
            "identities_before": ids, "identities_after": None}
        client_config = {**config, "output_dir": str(flow)}
        client_config_path = flow / "client configuration.json"
        client_config_path.write_text(json.dumps(client_config, sort_keys=True, indent=2) + "\n")
        client_report = flow / "client report.json"
        logs = (flow / "MCP client.log").open("wb")
        environment = {name: os.environ[name] for name in ("PATH", "LANG", "LC_ALL") if name in os.environ}
        environment.update(HOME=str(flow), TMPDIR=str(flow), TEMP=str(flow), TMP=str(flow), PYTHONNOUSERSITE="1")
        command = [config["python"]["path"], "-I", "-B", str(root / "scripts/installed_static_asset_client.py"),
                   "--config", str(client_config_path), "--report", str(client_report), "--port", str(port)]
        client = subprocess.Popen(command, cwd=flow, env=environment, stdin=subprocess.DEVNULL,
                                  stdout=logs, stderr=subprocess.STDOUT)
        proof["client_process_id"] = client.pid
        before, save_projection = {}, {}
        observations = save_probe.LargeSaveController(flow, runtime, {})
        original_filepath = bpy.data.filepath
        last_persist = [0.]

        def poll():
            try:
                assert time.monotonic() - started < MAX_SECONDS, "STATIC_FLOW_WHOLE_DEADLINE"
                assert identity(runtime) == ids and runtime.executor.permissions is runtime.permissions
                assert bpy.app.timers.is_registered(runtime.executor._timer_callback)
                observations.observe()  # Python-only retained product diagnostics.
                candidate = bpy.data.objects.get(OBJECT_NAME)
                if not before and candidate is not None and tuple(candidate.location) == (1., 2., 3.):
                    before.update(installed_probe._cube_projection(OBJECT_NAME))
                for record in tuple(runtime.jobs._save_records.values()):
                    if not save_projection:
                        assert before
                        projection = record.origin.projection
                        rows = json.loads(projection.raw)
                        assert len(rows["objects"]) == 1 and rows["objects"][0]["name"] == OBJECT_NAME
                        save_projection["sha256"] = projection.digest
                if client.poll() is None:
                    if time.monotonic() - last_persist[0] >= 1:
                        persist()
                        last_persist[0] = time.monotonic()
                    return .02
                logs.flush()
                result = read_bounded_json(client_report)
                proof["client"] = binding(client_report)
                assert client.returncode == 0 and result["completed"] is True, result.get("error")
                assert result["created_object"] == OBJECT_NAME and result["version"] == config["version"]
                assert result["MCP_stdio"] is True and result["direct_RPC"] is False
                assert result["permissions_granted_by_client"] is False and result["Blender_API_imported"] is False
                assert before and save_projection
                after = installed_probe._cube_projection(OBJECT_NAME)
                assert after == before and len(bpy.data.objects) == 1 and bpy.data.filepath == original_filepath
                geometry = result["geometry"]["image_metadata"]
                expected_dto = installed_probe._cube_dto_sha256(OBJECT_NAME, before)
                assert geometry["source_fingerprint"] == expected_dto
                worker = geometry["worker_evidence"]["worker"]
                assert worker["dto_sha256"] == worker["input_sha256"] == expected_dto
                assert worker["process_id"] not in {os.getpid(), result["client_pid"]}
                png_path = Path(result["png"]["path"])
                assert png_path.parent == flow and png_path.name == "installed static prop preview.png"
                raw, png = installed_probe._png_proof(base64.b64encode(png_path.read_bytes()).decode())
                assert hashlib.sha256(raw).hexdigest() == geometry["image_sha256"] == result["png"]["sha256"]
                assert png["visual_review_performed"] is False
                saved = result["save"]["terminal"]["result"]
                saved_file = Path(saved["filepath"])
                assert saved_file == flow / "installed static prop.blend"
                assert saved["mode"] == "COPY_NEW" and saved["fresh_process_reopen_verified"] is True
                reader = saved["reader_evidence"]
                assert reader["projection_sha256"] == reader["actual_projection_sha256"] == save_projection["sha256"]
                assert reader["saved_sha256"] == sha(saved_file) == result["save"]["sha256"]
                assert reader["process_id"] not in {os.getpid(), worker["process_id"], result["client_pid"]}
                reader_resource = next(value for value in observations.readers.values()
                                       if value.process is not None and value.process.pid == reader["process_id"])
                reader_command = list(reader_resource.process.args)
                assert Path(reader_command[0]).resolve() == Path(bpy.app.binary_path).resolve()
                assert reader_command[reader_command.index("--python") + 1] == str(installed / "native_save_reader.py")
                assert reader_resource.process.returncode == 0 and reader_resource.cleanup_status == "complete"
                for name, digest in reader["program"].items():
                    assert members["blender_codex_bridge/" + name] == digest
                for name, digest in geometry["worker_evidence"]["program_sha256"].items():
                    assert members["blender_codex_bridge/" + name] == digest
                installed_probe._installed_bytes(installed, members)
                proof["installed"]["imported_modules"] = imported_modules(installed, members)
                proof["runtime"]["identities_after"] = identity(runtime)
                proof["runtime"]["MCP_stdio"] = result["MCP_stdio"]
                proof["same_asset"] = {"object_name": OBJECT_NAME, "before": before, "after": after,
                    "preserved": True, "preview_source_fingerprint": expected_dto,
                    "save_projection_sha256": save_projection["sha256"]}
                proof["png"] = binding(png_path)
                proof["save"] = {"file": binding(saved_file), "reader_evidence": reader,
                    "reader_launch": {"process_id": reader_resource.process.pid, "command": reader_command,
                        "binary_sha256": reader_resource.binary_sha256, "program_sha256": dict(reader_resource.program),
                        "worker_reaped": reader_resource.reaped, "worker_exit_code": reader_resource.process.returncode,
                        "staging_cleanup": reader_resource.cleanup_status}}
                assert fingerprints(root) == source_hashes and runner._domain_display() == display
                assert load_config(config_path) == config and sha(config_path) == proof["configuration_sha256"]
                proof["completed"] = True
                finish(0)
            except Exception:
                proof["error"] = {"type": "STATIC_FLOW_FAILED", "traceback": traceback.format_exc()}
                traceback.print_exc()
                finish(1)
            return None

        persist()
        bpy.app.timers.register(poll, first_interval=.02)
    except Exception:
        proof["error"] = {"type": "STATIC_FLOW_SETUP_FAILED", "traceback": traceback.format_exc()}
        traceback.print_exc()
        finish(1)


if __name__ == "__main__":
    main()
