"""Pin installed static-asset qualification inputs; never install or launch them."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from zipfile import ZipFile

SCHEMA = "installed_static_asset_probe_config_v1"
VERSION = "0.9.1"
EXPECTED_TOOLS_SHA256 = "1cb16ea5e7320962bc0be5d886bf76724e59ed548e9bc2808b5bff7e3d3b9c1e"
MAX_CONFIG = 512 * 1024


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tool_names_sha256(names):
    """Canonical ordered-name digest, distinct from the input JSON file hash."""
    return hashlib.sha256(("\n".join(names) + "\n").encode("utf-8")).hexdigest()


def wheel_record(path):
    path = Path(path).resolve(strict=True)
    if path.stat().st_size > 32 * 1024**2:
        raise ValueError("STATIC_FLOW_WHEEL_CAP")
    with ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise ValueError("STATIC_FLOW_WHEEL_MEMBERS")
        members = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in names
                   if name.startswith("mcp_server/") and not name.endswith("/")}
        if not members or len(members) > 256 or any(".." in Path(name).parts for name in members):
            raise ValueError("STATIC_FLOW_WHEEL_SURFACE")
        metadata = [name for name in names if name.endswith(".dist-info/METADATA")]
        if len(metadata) != 1 or ("Version: " + VERSION + "\n") not in archive.read(metadata[0]).decode():
            raise ValueError("STATIC_FLOW_WHEEL_VERSION")
    return {"path": str(path), "sha256": sha(path), "version": VERSION, "members_sha256": members}


def python_record(path):
    path = Path(os.path.abspath(path))
    prefix = path.parent.parent.resolve(strict=True)
    if not path.is_file() or not os.access(path, os.X_OK) or not (prefix / "pyvenv.cfg").is_file():
        raise ValueError("STATIC_FLOW_PRIVATE_VENV_REQUIRED")
    return {"path": str(path), "resolved_path": str(path.resolve(strict=True)),
            "sha256": sha(path), "venv_root": str(prefix)}


def load_config(path, *, allow_output=False):
    path = Path(path)
    raw = path.read_bytes()
    if not 0 < len(raw) <= MAX_CONFIG:
        raise ValueError("STATIC_FLOW_CONFIG_CAP")
    value = json.loads(raw)
    required = {"schema", "version", "candidate", "wheel", "python", "sdk_version", "expected_tools"}
    if allow_output:
        required.add("output_dir")
    if (type(value) is not dict or set(value) != required or value["schema"] != SCHEMA
            or value["version"] != VERSION or value["sdk_version"] not in {"2.0.0", "2.2.0"}):
        raise ValueError("STATIC_FLOW_CONFIG_SCHEMA")
    candidate = value["candidate"]
    if (type(candidate) is not dict or candidate.get("version") != VERSION or candidate.get("expected_tools") != 270
            or type(value["expected_tools"]) is not list or len(value["expected_tools"]) != 270
            or candidate.get("expected_tool_names") != value["expected_tools"]
            or value["expected_tools"] != sorted(set(value["expected_tools"]))
            or any(type(name) is not str or re.fullmatch(r"[a-z][a-z0-9_]*(?:\.[a-z_][a-z0-9_]*)+", name) is None
                   for name in value["expected_tools"])):
        raise ValueError("STATIC_FLOW_PUBLISHED_TOOL_SURFACE")
    if (tool_names_sha256(value["expected_tools"]) != EXPECTED_TOOLS_SHA256
            or candidate.get("expected_tool_names_canonical_sha256") != EXPECTED_TOOLS_SHA256):
        raise ValueError("STATIC_FLOW_PUBLISHED_TOOL_NAMES_CHANGED")
    raw_names_hash = candidate.get("expected_tool_names_sha256")
    if type(raw_names_hash) is not str or re.fullmatch(r"[0-9a-f]{64}", raw_names_hash) is None:
        raise ValueError("STATIC_FLOW_TOOL_INPUT_HASH")
    if (sha(candidate["path"]) != candidate["sha256"]
            or sha(candidate["expected_tool_names_source"]) != raw_names_hash
            or json.loads(Path(candidate["expected_tool_names_source"]).read_bytes()) != value["expected_tools"]):
        raise ValueError("STATIC_FLOW_CANDIDATE_CHANGED")
    # Complete installed ZIP member checking remains mandatory in Blender.
    if value["wheel"] != wheel_record(value["wheel"]["path"]):
        raise ValueError("STATIC_FLOW_WHEEL_CHANGED")
    if value["python"] != python_record(value["python"]["path"]):
        raise ValueError("STATIC_FLOW_PYTHON_CHANGED")
    if allow_output:
        output = Path(value["output_dir"])
        if not output.is_absolute() or output.is_symlink() or not output.is_dir():
            raise ValueError("STATIC_FLOW_OWNED_OUTPUT_REQUIRED")
    return value


def main():
    from scripts.package_probe_config import package_record

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--candidate-tools-file", type=Path, required=True)
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--sdk-version", choices=("2.0.0", "2.2.0"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    candidate = package_record(args.candidate, 270, tools_file=args.candidate_tools_file)
    candidate["expected_tool_names_canonical_sha256"] = tool_names_sha256(candidate["expected_tool_names"])
    value = {"schema": SCHEMA, "version": VERSION, "candidate": candidate,
             "wheel": wheel_record(args.wheel), "python": python_record(args.python),
             "sdk_version": args.sdk_version, "expected_tools": candidate["expected_tool_names"]}
    raw = json.dumps(value, sort_keys=True, indent=2).encode() + b"\n"
    if len(raw) > MAX_CONFIG:
        raise ValueError("STATIC_FLOW_CONFIG_CAP")
    with args.output.open("xb") as stream:
        stream.write(raw)
    load_config(args.output)


if __name__ == "__main__":
    main()
