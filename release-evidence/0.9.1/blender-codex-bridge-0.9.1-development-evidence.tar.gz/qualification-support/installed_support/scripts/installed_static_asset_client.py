"""Qualification client for one installed-wheel to installed-Blender workflow.

The process imports no Blender product module. It never grants permissions or
advances a Blender queue. Run its pinned virtual-environment Python with -I -B.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import re
import struct
import sys
import time
import zlib
from pathlib import Path
from zipfile import ZipFile

SCHEMA = "installed_static_asset_client_v1"
MAX_JSON = 4 * 1024 * 1024
MAX_REPORT = 8 * 1024 * 1024
MAX_CALLS = 4096
FLOW_SECONDS = 300
JOB_SECONDS = 120


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest() if hasattr(hashlib, "file_digest") else _stream_hash(stream)


def _stream_hash(stream):
    result = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        result.update(block)
    return result.hexdigest()


def _field(value, *names):
    for name in names:
        if isinstance(value, dict):
            if name in value:
                return value[name]
        elif hasattr(value, name):
            return getattr(value, name)
    return None


def response_value(response):
    """Normalize the two pinned SDKs, retaining their parsed MCP responses."""
    failed = _field(response, "is_error", "isError")
    require(failed is False or failed is None, "MCP tool returned an error")
    content = _field(response, "content")
    require(type(content) is list and len(content) <= 16, "MCP content shape")
    structured = _field(response, "structured_content", "structuredContent")
    texts, images = [], []
    for item in content:
        kind = _field(item, "type")
        if kind == "text":
            value = _field(item, "text")
            require(type(value) is str and len(value.encode()) <= MAX_JSON, "MCP text bound")
            texts.append(value)
        elif kind == "image":
            require(_field(item, "mime_type", "mimeType") == "image/png", "MCP image type")
            images.append(_field(item, "data"))
        else:
            raise ValueError("Unexpected MCP result content")
    if structured is None:
        require(len(texts) == 1, "MCP JSON text result required")
        structured = json.loads(texts[0])
    require(type(structured) is dict and len(canonical(structured)) <= MAX_JSON, "MCP structured result bound")
    # Parse again to exclude non-JSON SDK/model objects without evaluating them.
    value = json.loads(canonical(structured))
    require(len(images) <= 1 and all(type(item) is str for item in images), "MCP image content shape")
    return value, images[0] if images else None


def png_proof(encoded):
    require(type(encoded) is str and 0 < len(encoded) <= 2796204, "PNG encoded bound")
    raw = base64.b64decode(encoded, validate=True)
    require(8 < len(raw) <= 2 * 1024 * 1024 and raw[:8] == b"\x89PNG\r\n\x1a\n", "PNG signature")
    offset, compressed, ended = 8, bytearray(), False
    while offset < len(raw):
        require(offset + 12 <= len(raw), "PNG chunk framing")
        size = struct.unpack_from(">I", raw, offset)[0]
        require(size <= 2 * 1024 * 1024 and offset + size + 12 <= len(raw), "PNG chunk bound")
        kind, data = raw[offset + 4:offset + 8], raw[offset + 8:offset + 8 + size]
        require(zlib.crc32(kind + data) & 0xffffffff == struct.unpack_from(">I", raw, offset + 8 + size)[0], "PNG CRC")
        if offset == 8:
            require(kind == b"IHDR" and size == 13 and struct.unpack(">IIBBBBB", data) == (128, 128, 8, 6, 0, 0, 0), "PNG dimensions")
        elif kind == b"IDAT":
            compressed.extend(data)
        elif kind == b"IEND":
            require(size == 0 and offset + 12 == len(raw), "PNG ending")
            ended = True
        else:
            require(kind[:1].islower(), "PNG critical chunk")
        offset += size + 12
    decoder = zlib.decompressobj()
    pixels = decoder.decompress(compressed, 128 * 513 + 1)
    require(ended and len(pixels) == 128 * 513 and decoder.eof and not decoder.unused_data
            and not decoder.unconsumed_tail and all(pixels[index * 513] <= 4 for index in range(128)), "PNG complete rows")
    return raw, {"width": 128, "height": 128, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                 "compressed_rows_verified": True, "visual_review_performed": False}


def module_facts(config):
    """Prove complete installed wheel members, including absence of extra files."""
    import mcp_server
    prefix = Path(sys.prefix).resolve(strict=True)
    require(sys.flags.isolated and sys.flags.dont_write_bytecode, "Client requires isolated Python -I -B")
    require(Path(sys.executable).absolute() == Path(config["python"]["path"]), "Client interpreter path")
    require(prefix == Path(config["python"]["venv_root"]).resolve(strict=True), "Client virtual environment")
    module = Path(mcp_server.__file__).resolve(strict=True)
    require(module.is_relative_to(prefix) and "site-packages" in module.parts, "Installed MCP import origin")
    require(mcp_server.__version__ == config["version"]
            and importlib.metadata.version("blender-codex-bridge") == config["version"], "Installed MCP version")
    sdk = importlib.metadata.version("mcp")
    require(sdk == config["sdk_version"] and sdk in ("2.0.0", "2.2.0"), "Pinned MCP SDK version")
    wheel = config["wheel"]
    require(file_hash(wheel["path"]) == wheel["sha256"], "Wheel bytes changed")
    site = module.parent.parent
    expected = wheel["members_sha256"]
    actual = {path.relative_to(site).as_posix() for path in module.parent.rglob("*")
              if path.is_file() and path.suffix != ".pyc" and "__pycache__" not in path.parts}
    require(actual == set(expected), "Installed wheel member inventory")
    observed = {}
    with ZipFile(wheel["path"]) as archive:
        members = {name for name in archive.namelist() if name.startswith("mcp_server/") and not name.endswith("/")}
        require(members == set(expected) and archive.testzip() is None, "Wheel package member inventory")
        for name in sorted(expected):
            content = (site / name).read_bytes()
            require(content == archive.read(name), "Installed/wheel bytes differ: " + name)
            observed[name] = hashlib.sha256(content).hexdigest()
            require(observed[name] == expected[name], "Installed member fingerprint: " + name)
    require(not any(name == "blender_codex_bridge" or name.startswith("blender_codex_bridge.") for name in sys.modules),
            "Client imported Blender product")
    return {"python": str(Path(sys.executable).absolute()), "prefix": str(prefix), "sdk_version": sdk,
            "version": mcp_server.__version__, "module_path": str(module), "members_sha256": observed,
            "wheel_sha256": wheel["sha256"], "isolated": True, "dont_write_bytecode": True}


def server_process():
    """Optional Linux process observation; no SDK/private transport mutation."""
    try:
        children = Path(f"/proc/self/task/{os.getpid()}/children").read_text().split()
        matches = []
        for text in children:
            if not text.isdecimal():
                continue
            pid = int(text)
            args = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
            if b"mcp_server" in args and b"-m" in args:
                matches.append(pid)
        return matches[0] if len(matches) == 1 else None
    except OSError:
        return None


class Flow:
    def __init__(self, config, proof, started):
        self.config, self.proof, self.started = config, proof, started

    def remaining(self):
        value = FLOW_SECONDS - (time.monotonic() - self.started)
        require(value > 0, "Installed static asset whole-flow deadline")
        return value

    async def call(self, client, name, params):
        require(len(self.proof["calls"]) < MAX_CALLS, "MCP call ledger bound")
        require(len(canonical(params)) <= 65536, "MCP input bound")
        row = {"sequence": len(self.proof["calls"]), "method": name, "params": params,
               "sent_at": time.monotonic(), "received_at": None, "result": None, "error": None}
        self.proof["calls"].append(row)
        try:
            response = await asyncio.wait_for(client.call_tool(name, params), timeout=min(JOB_SECONDS, self.remaining()))
            value, encoded = response_value(response)
            row["received_at"], row["result"] = time.monotonic(), value
            if encoded is not None:
                row["image"] = {"base64_bytes": len(encoded), "encoded_sha256": hashlib.sha256(encoded.encode()).hexdigest()}
            return value, encoded
        except Exception as error:
            row["error"] = {"type": type(error).__name__, "message": str(error)[:1024]}
            raise

    async def result(self, client, method, **params):
        value, image = await self.call(client, method, params)
        require(image is None, "Unexpected image result")
        return value

    async def terminal(self, client, identifier):
        require(type(identifier) is str and re.fullmatch(r"job_[0-9a-f]{32}", identifier) is not None, "Job identity")
        deadline = time.monotonic() + JOB_SECONDS
        while True:
            require(time.monotonic() < deadline, "Installed public job deadline")
            row = await self.result(client, "jobs.inspect", job_id=identifier)
            require(row.get("job_id") == identifier and type(row.get("terminal")) is bool, "Job response identity")
            if row["terminal"]:
                require(row.get("state") == "SUCCEEDED", "Installed public job did not succeed: " + json.dumps(row, default=str)[:2048])
                return row
            await asyncio.sleep(.02)

    async def run(self, port):
        from mcp import Client
        from mcp.client.stdio import StdioServerParameters, stdio_client

        output = Path(self.config["output_dir"]).resolve(strict=True)
        arguments = ["-I", "-B", "-m", "mcp_server", "--transport", "stdio", "--blender-host", "127.0.0.1",
                     "--blender-port", str(port), "--timeout", "120", "--connect-timeout", "5"]
        self.proof["server_command"] = [self.config["python"]["path"], *arguments]
        environment = {"PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1"}
        params = StdioServerParameters(command=self.config["python"]["path"], args=arguments,
                                       cwd=str(output), env=environment)
        # SDK 2.0 requires an actual async transport. Passing parameters directly
        # only became supported by Client in 2.2. This works on both pinned SDKs.
        async with Client(stdio_client(params), read_timeout_seconds=120.) as client:
            self.proof["MCP_stdio"] = True
            self.proof["mcp_server_pid"] = server_process()
            listing = await asyncio.wait_for(client.list_tools(), timeout=min(30., self.remaining()))
            names = sorted(tool.name for tool in listing.tools)
            require(names == self.config["expected_tools"], "Installed MCP tool inventory")
            self.proof["tool_names"] = names
            status = await self.result(client, "bridge.status")
            require(status.get("addon_version") == self.config["version"], "Installed add-on version")
            self.proof["status"] = status
            await self.result(client, "toolsets.enable", name="objects")
            name = "Installed Static Prop"
            created = await self.result(client, "object.create", object_type="CUBE", name=name)
            require(created.get("object") == name, "Created asset identity")
            self.proof["created_object"] = name
            self.proof["creation"] = created
            self.proof["transform"] = await self.result(client, "transform.set", object_name=name, location=[1., 2., 3.])
            self.proof["inspection"] = await self.result(client, "object.inspect", object_name=name)
            inspected = self.proof["inspection"]
            require(inspected.get("name") == name and inspected.get("type") == "MESH"
                    and inspected.get("location") == [1., 2., 3.] and inspected.get("parent") is None,
                    "Same-asset structural inspection")
            accepted = await self.result(client, "preview.geometry_start", object_name=name, time_limit_seconds=120)
            require(accepted.get("accepted") is True and accepted.get("terminal") is False, "Geometry acceptance")
            geometry = await self.terminal(client, accepted["job_id"])
            require(geometry["result"].get("source_object") == name, "Geometry source asset")
            metadata, encoded = await self.call(client, "preview.geometry_image", {"preview_id": geometry["result"]["preview_id"]})
            png, png_row = png_proof(encoded)
            require(metadata.get("image_sha256") == png_row["sha256"], "Preview image fingerprint")
            png_path = output / "installed static prop preview.png"
            with png_path.open("xb") as stream:
                stream.write(png)
            self.proof["png"] = {**png_row, "path": str(png_path)}
            self.proof["geometry"] = {"accepted": accepted, "terminal": geometry, "image_metadata": metadata}
            target = output / "installed static prop.blend"
            intent = await self.result(client, "project.native_save_preview", mode="COPY_NEW", filepath=str(target), overwrite_policy="NO_CLOBBER")
            saved = await self.result(client, "project.native_save_start", mode="COPY_NEW", filepath=str(target),
                overwrite_policy="NO_CLOBBER", preview_id=intent["preview_id"], expected_fingerprint=intent["fingerprint"],
                accepted_losses=intent["required_accepted_losses"], time_limit_seconds=120)
            require(saved.get("accepted") is True and saved.get("terminal") is False, "Save acceptance")
            terminal = await self.terminal(client, saved["job_id"])
            result = terminal["result"]
            require(result.get("mode") == "COPY_NEW" and result.get("filepath") == str(target)
                    and result.get("fresh_process_reopen_verified") is True
                    and result.get("declared_source_verified") is True, "Same-asset save/read verification")
            cleanup = result["reader_cleanup"]
            require(cleanup.get("worker_reaped") is True and cleanup.get("worker_exit_code") == 0
                    and cleanup.get("staging_cleanup") == "complete", "Fresh reader process cleanup")
            reader = result["reader_evidence"]
            require(reader.get("declared_projection_reopened") is True
                    and reader.get("status") == "succeeded" and type(reader.get("process_id")) is int
                    and reader.get("process_id") != os.getpid()
                    and reader.get("actual_projection_sha256") == reader.get("projection_sha256")
                    and reader.get("saved_sha256") == file_hash(target), "Fresh reader file/projection evidence")
            self.proof["save"] = {"preview": intent, "accepted": saved, "terminal": terminal,
                                  "path": str(target), "sha256": file_hash(target), "bytes": target.stat().st_size}
            self.proof["completed"] = True


def read_config(path):
    source = Path(__file__).with_name("static_asset_probe_config.py")
    spec = importlib.util.spec_from_file_location("_installed_static_asset_config", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.load_config(path, allow_output=True)


def write_report(path, proof):
    raw = canonical(proof) + b"\n"
    require(0 < len(raw) <= MAX_REPORT, "Client report bound")
    # The owner reads only after this process exits. Exclusive creation keeps
    # a rerun or conflicting report from replacing previously retained proof.
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--port", required=True, type=int)
    options = parser.parse_args()
    started = time.monotonic()
    proof = {"schema": SCHEMA, "completed": False, "client_pid": os.getpid(), "mcp_server_pid": None,
             "calls": [], "version": None, "installed": None, "sdk_version": None, "modulehashes": None,
             "created_object": None, "inspection": None, "creation": None, "transform": None,
             "status": None, "server_command": None, "tool_names": None,
             "geometry": None, "save": None, "png": None, "error": None,
             "whole_flow_seconds": 300, "public_job_seconds": 120,
             "Blender_API_imported": False, "MCP_stdio": False, "direct_RPC": False,
             "permissions_granted_by_client": False, "visual_review_performed": False}
    try:
        config = read_config(options.config)
        output = Path(config["output_dir"]).resolve(strict=True)
        require(options.report.parent.resolve(strict=True) == output and not options.report.exists(), "Owned client report path")
        require(1 <= options.port <= 65535 and Path.cwd().resolve() == output, "Owned client working directory/port")
        proof["version"] = config["version"]
        proof["installed"] = module_facts(config)
        proof["sdk_version"] = proof["installed"]["sdk_version"]
        proof["modulehashes"] = proof["installed"]["members_sha256"]
        asyncio.run(asyncio.wait_for(Flow(config, proof, started).run(options.port), timeout=max(.001, FLOW_SECONDS-(time.monotonic()-started))))
        require(module_facts(config) == proof["installed"], "Installed wheel changed during workflow")
    except Exception as error:
        proof["completed"] = False
        proof["error"] = {"type": type(error).__name__, "message": str(error)[:4096]}
    proof["seconds"] = time.monotonic() - started
    write_report(options.report, proof)
    raise SystemExit(0 if proof["completed"] else 1)


if __name__ == "__main__":
    main()
