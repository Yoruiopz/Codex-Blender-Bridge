from pathlib import Path
import hashlib,json,tarfile,io,re,zipfile
B=Path('/dev/shm/blender-codex-resume-20261025');R=B/'release-0.6';O=B/'publication-0.6';O.mkdir(exist_ok=True);D=O/'blender-codex-bridge-0.6.0-development-evidence.tar.gz';assert not D.exists();M={};ex=[]
def add(p,n):
 assert p.is_file() and not p.is_symlink(),str(p)
 assert n not in M and not Path(n).is_absolute() and '..' not in Path(n).parts,n
 M[n]=p
# Curated release-only synthetic evidence; no broad workspace/archive collection.
for directory,excluded in [(B/'integration-0.6-final-source-root-validation',()),(R/'ci',('package-assets','artifacts-cli-failed')),(R/'installed-wheel',('venv','process-profile','packages')),(R/'root',())]:
 prefix='source-validation' if directory.name=='integration-0.6-final-source-root-validation' else directory.name
 for p in sorted(directory.rglob('*')):
  rel=p.relative_to(directory)
  if any(x in excluded for x in rel.parts) or p.is_dir():continue
  assert not p.is_symlink(),str(p)
  if p.suffix not in {'.json','.jsonl','.log','.py','.xml','.zip'}:ex.append(str(p));continue
  add(p,prefix+'/'+rel.as_posix())
for n in ('source.bundle','verification.json'):add(R/'source-bundle'/n,'source-bundle/'+n)
for run in ('bcb-int06-final-01','bcb-06-install03-02','bcb-06-install05-02'):
 p=Path('/tmp')/run;prefix='native/'+run
 for n in ('invocation-receipt.json','invocation.json','launcher-source.json','runner.log','private_display.py'):
  add(p/n,prefix+'/'+n)
 script='run_focused.py' if run=='bcb-int06-final-01' else 'run_installed.py';add(p/script,prefix+'/'+script);add(p/'native/report.json',prefix+'/native/report.json')
 for row in (p/'native').glob('blender-*'):
  for f in sorted(row.glob('*.log')):add(f,prefix+'/native/'+f.relative_to(p/'native').as_posix())
  if run=='bcb-int06-final-01':
   for case,fnames in {'geometry_preview':['registered-geometry-preview.json','registered-geometry-preview.png'],'executor_history_containment':['executor-history-containment.json'],'scene_job_kernel':['scene-job-kernel-evidence.json','scene-job-kernel-progress.json']}.items():
    for n in fnames:
     f=row/(case+'-temp')/n;add(f,prefix+'/native/'+f.relative_to(p/'native').as_posix())
  else:
   evidence=row/'installed_addon_probe-temp/installed preview evidence with spaces'
   for f in sorted(evidence.glob('*')):
    assert f.suffix in {'.json','.png'};add(f,prefix+'/native/'+f.relative_to(p/'native').as_posix())
for f in sorted(Path('/tmp/bcb-06-install-config').glob('previous*.json')):add(f,'installed-configs/'+f.name)
for n in ('make_alpha_acceptance06.py','archive_evidence06.py'):add(B/n,'root-recipes/'+n)
h=lambda d:hashlib.sha256(d).hexdigest();patterns=[rb'gh[pousr]_[A-Za-z0-9]{20,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'https?://[^\s"<>]*[?&](?:sig|signature|X-Amz-Signature|se|skoid)=',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
def scan(data,n):
 for pattern in patterns:assert not re.search(pattern,data,re.I),(n,'possible secret or temporary URL')
manifest={}
for n,p in M.items():
 data=p.read_bytes();manifest[n]={'bytes':len(data),'sha256':h(data)}
 if p.suffix in {'.json','.jsonl','.log','.py','.xml','.txt','.md'}:scan(data,n)
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   for zi in z.infolist():
    assert not Path(zi.filename).is_absolute() and '..' not in Path(zi.filename).parts
    if Path(zi.filename).suffix in {'.json','.xml','.txt','.log','.md','.py'}:scan(z.read(zi),n+'!'+zi.filename)
meta={'schema_version':1,'source_commit':'73cad805903fcd0be9175b49a5ecf78505ecd4a5','source_tree':'2703f46038cd8f970437686f3fddabe9ea5a8ca9','payload':manifest,'excluded_scope':['No workspace/recovery/checkpoint archives or .blend files','No source WIP/user-edited files','No native preferences/datafiles/extensions/installed payload/profile/auth/display folders','No venv/process profile/third-party dependency payload','No raw signed download references','No historical0.5native4K proof relabeled as0.6'], 'all_14_stable_gates':'OPEN','Windows':'Deferred/unverified','full_artist_A_F_acceptance':False}
readme=b'0.6.0 alpha curated synthetic acceptance evidence. Read root/alpha-acceptance.json and root/visual-review.json for exact scope. CI seven jobs and all original seven artifactZIPs/logs; exact source eight selected interactive native cases; four fresh background installed-addon processes with sixteen install/upgrade/rollback observations and eight geometry images; a new installed MCP stdio session; standalone public-source Git bundle restored and fsck --strict verified. Ten selected structural-preview images reviewed; no material/fullviewport/fullartist appearance qualification. No user scenes, preferences, recovery/checkpoint/workspace archives, private WIP, live credentials or signed download URLs are included. All fourteen stable gates remain open; Windows deferred. Every regular payload is hashed in MANIFEST.json. No links or special members.\n'
with tarfile.open(D,'w:gz',compresslevel=9) as t:
 for n,p in sorted(M.items()):
  data=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(data);i.mode=0o644;t.addfile(i,io.BytesIO(data))
 for n,data in [('MANIFEST.json',(json.dumps(meta,indent=2)+'\n').encode()),('README.txt',readme)]:
  i=tarfile.TarInfo(n);i.size=len(data);i.mode=0o644;t.addfile(i,io.BytesIO(data))
with tarfile.open(D,'r:gz') as t:
 assert len(t.getmembers())==len(M)+2
 for m in t.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name in manifest:
   data=t.extractfile(m).read();assert len(data)==manifest[m.name]['bytes'] and h(data)==manifest[m.name]['sha256']
for n,p in M.items():assert h(p.read_bytes())==manifest[n]['sha256']
a={'status':'ROOT_VERIFIED_CURATED_SYNTHETIC_RELEASE_EVIDENCE','archive':str(D),'bytes':D.stat().st_size,'sha256':h(D.read_bytes()),'regular_payload_members':len(M),'archive_members':len(M)+2,'all_payload_readback_verified':True,'all_originals_unchanged':True,'no_secret_or_signed_URL_patterns':True,'no_workspace_recovery_checkpoint_archives':True,'no_user_project_or_preferences_files':True,'full_allowlist':manifest,'omitted_non_payload_files':ex}
(O/'archive-verification.json').write_text(json.dumps(a,indent=2)+'\n');(O/'EVIDENCE-SHA256SUMS.txt').write_text(a['sha256']+'  '+D.name+'\n');print(json.dumps({k:v for k,v in a.items() if k not in ('full_allowlist','omitted_non_payload_files')}))
