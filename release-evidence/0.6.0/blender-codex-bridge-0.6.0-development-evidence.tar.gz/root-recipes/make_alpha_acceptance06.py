from pathlib import Path
import hashlib,json,subprocess,platform,datetime
B=Path('/dev/shm/blender-codex-resume-20261025');S=B/'integration-0.6';O=B/'release-0.6/root';C='73cad805903fcd0be9175b49a5ecf78505ecd4a5';T='2703f46038cd8f970437686f3fddabe9ea5a8ca9'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 p=O/n;assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');return {'path':str(p),'sha256':h(p)}
assert subprocess.check_output(['git','status','--porcelain'],cwd=S)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==C
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=S,text=True).strip()==T
ci=B/'release-0.6/ci/combined-audit.json';wheel=B/'release-0.6/installed-wheel/final-verification.json'
for p in (ci,wheel):
 d=json.loads(p.read_text());assert d['status']=='passed' and d['source_commit']==C and d['source_tree']==T
installed=json.loads((O/'installed-addon-review.json').read_text());images=[]
for n in installed['images_pending_visual_review']:
 p=Path(n);images.append({'path':str(p),'sha256':h(p),'bytes':p.stat().st_size,'review':'PASS: complete grey cube framed without clipping; transparent background; structural geometry preview only.'})
for i in (0,1):
 p=Path('/tmp/bcb-int06-final-01/native')/f'blender-{i}/geometry_preview-temp/registered-geometry-preview.png'
 images.append({'path':str(p),'sha256':h(p),'bytes':p.stat().st_size,'review':'PASS: complete grey triangle framed without clipping; structural geometry preview only.'})
visual_path=O/'visual-review.json'
visual=({'path':str(visual_path),'sha256':h(visual_path)} if visual_path.exists() else put('visual-review.json',{'status':'ROOT_REVIEWED_SELECTED_GEOMETRY_VISUALS','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':C,'images':images,'appearance_or_material_fidelity_claimed':False,'current_viewport_or_complete_protected_scene_capture_claimed':False,'scope':'Eight installed cube images and two exact-source triangle images viewed by root. This is not full artist-workflow visual acceptance.'}))
assert json.loads(visual_path.read_text())['images']==images
reports=[]
for n,count in [('bcb-int06-final-01',8),('bcb-06-install03-02',2),('bcb-06-install05-02',2)]:
 p=Path('/tmp')/n;r=json.loads((p/'native/report.json').read_text());receipt=json.loads((p/'invocation-receipt.json').read_text())
 assert r['commit']==C and len(r['results'])==count and r['checks_passed'] and receipt['exit_code']==0
 assert receipt.get('source_and_helper_unchanged',receipt.get('source_and_config_unchanged')) is True
 assert all(x['status']=='passed' and x['exit_code']==0 and x['execution_mode']==('interactive_display' if n=='bcb-int06-final-01' else 'background') for x in r['results'])
 for f,v in r['source_files'].items():assert h(S/f)==v,f
 reports.append({'name':n,'report_sha256':h(p/'native/report.json'),'invocation_sha256':h(p/'invocation-receipt.json'),'selected_cases':r['selected_cases'],'native_processes_passed':count,'all_native_inventory_selected':r['all_cases_selected'],'execution_modes':sorted({x['execution_mode'] for x in r['results']})})
primary=Path('/workspace/Codex-Blender-Bridge');protect={'AGENTS.md':'1390f648d92c5f0f9256bea75793c9544484b2c7b374ff93a68c522f1effce93','README.md':'9399c0f66682471b7933b8f3a5f73161b2174330a110729469c880604699f500','plugins/blender-codex-bridge/skills/blender-studio/SKILL.md':'184966e8f3059a07923b26ebaabf1f2dfa76e37613cfd50b848a7c39e1218bcf'}
for n,v in protect.items():assert h(primary/n)==v,n
cpu=next((x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),None)
mem={k:v for x in Path('/proc/meminfo').read_text().splitlines() for k,v in [x.split(':',1)] if k in ('MemTotal','SwapTotal')}
put('hardware-scope.json',{'platform':platform.platform(),'machine':platform.machine(),'CPU':cpu,'logical_cpus_available':__import__('os').cpu_count(),'memory':mem,'qualified_builds':{'4.5.14':'62c1db4208e862312bc36db5bc15d4a6dbcfa3e3','5.2.2':'d13f752e3b9c4f8c261cda552b1021f8bcc0382c'},'GPU_hardware_qualified':False,'constrained_memory_test':False,'native_blocking_intervals_and_parent_peak_RSS_fully_measured':False,'scope':'Host metadata only. Worker receipts record worker metrics and bounded deadlines; no real-time or constrained-memory guarantee.'})
result={'status':'ROOT_ACCEPTED_BOUNDED_0_6_ALPHA_PACKAGES','source_commit':C,'source_tree':T,'component_version':'0.6.0','public_tools':268,'registry_total':270,'portable_passed':8403,'Windows_only_skipped':3,'CI_run':40196147205,'CI_successful_jobs':7,'six_Python_3_10_to_3_12_MCP_2_0_and_2_2_cells':True,'CI_receipt_sha256':h(ci),'fresh_wheel_receipt_sha256':h(wheel),'fresh_wheel_SDK_receipts':240,'malformed_standard_JSON_rejections':210,'third_party_dependencies_reused_via_explicit_readonly_links':True,'native_reports':reports,'installed_observations':16,'installed_upgrade_rollback_routes':['0.3.0 to0.6.0','0.5.0 to0.6.0'],'visual_review':visual,'preserved_primary_user_edits_sha256':protect,'pr8_draft_head_preserved':'4470d88bb4d8fb1ed75e86090dd6886fb55eb589','main_preserved':'1e3c9898ca1f4cf0d91858a383a0b93bf6438db5','all_29_implementation_items_complete':False,'all_14_stable_release_gates':'OPEN','Windows':'Deferred by user/unverified','full_artist_workflow_A_to_F':False,'stable_1_0_release_acceptance':False,'complete_native_inventory_acceptance':False,'durable_recovery_qualified':False,'constrained_memory_qualified':False,'fully_installed_MCP_to_Blender_artist_loop_qualified':False,'limits':['Geometry preview is bounded authored static local mesh copied to an isolated official-Blender process, 128x128 opaque new material; original shading/current viewport/evaluated geometry unsupported.','Protection tests use a declared field projection and an unpopulated protected baseline; no whole-hidden-Main or populated protected-baseline proof.','Shared finalization/history failure containment is qualified by source models and selected native actual Runtime/transport lifetime requests; no universal native undo recovery.','Four installed processes each run fresh/previous/upgrade/rollback observations; no Blender process restart/preferences migration/full artist scenario proof.','Legacy project.save, protected viewport.capture, shader-interface REMOVE/conversion, held Timeline/provider reproduction, and old exact5.2typed-import quarantine remain held.','Weight/material/curve/cloth/native-save/new private GLB lanes are excluded. Historical0.5 4K evidence remains separately labeled and is not requalified by this release.']}
print(json.dumps(put('alpha-acceptance.json',result)))
