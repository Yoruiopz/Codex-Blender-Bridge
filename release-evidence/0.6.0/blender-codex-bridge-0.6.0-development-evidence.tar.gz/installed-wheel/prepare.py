"""Root-reviewed, opt-in preparation for one fresh Linux 0.6.0 wheel session."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import ast
import base64
import csv
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import tarfile
from email.parser import BytesParser
from zipfile import ZipFile

OUT = Path(__file__).resolve().parent
BUILD = Path("/workspace/Codex-Blender-Bridge/build")
OLD = BUILD / "artist-installed-wheel-20261023/venv"
HISTORY = BUILD / "artist-quaternion-installed-wheel-20261023"
OLD_SITE = OLD / "lib/python3.12/site-packages"
NEW = OUT / "venv"
SITE = NEW / "lib/python3.12/site-packages"
BASE_PYTHON = Path("/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12")
ROOT_PYTHON = Path("/workspace/Codex-Blender-Bridge/.venv/bin/python")
WHEEL_NAME = "blender_codex_bridge-0.6.0-py3-none-any.whl"
DIST = "blender_codex_bridge-0.6.0.dist-info/"
HARNESS = ("prepare.py", "run-installed.py", "installed_stdio.py", "finalize.py")
DEPENDENCIES = frozenset("""
_cffi_backend.cpython-312-x86_64-linux-gnu.so annotated_types annotated_types-0.8.0.dist-info
anyio anyio-4.15.1.dist-info attr attrs attrs-26.1.0.dist-info cffi cffi-2.1.1.dist-info
click click-8.5.0.dist-info cryptography cryptography-50.0.2.dist-info h11 h11-0.16.0.dist-info
httpcore2 httpcore2-2.16.0.dist-info httpx2 httpx2-2.16.0.dist-info idna idna-3.20.dist-info
jsonschema jsonschema-4.26.0.dist-info jsonschema_specifications jsonschema_specifications-2025.9.1.dist-info
jwt mcp mcp-2.2.0.dist-info mcp_types mcp_types-2.2.0.dist-info multipart opentelemetry
opentelemetry_api-1.45.1.dist-info pycparser pycparser-3.12.dist-info pydantic pydantic-2.14.1.dist-info
pydantic_core pydantic_core-2.50.1.dist-info pyjwt-2.15.1.dist-info python_multipart
python_multipart-0.0.32.dist-info referencing referencing-0.37.0.dist-info rpds rpds_py-2026.9.1.dist-info
sse_starlette sse_starlette-3.5.0.dist-info starlette starlette-1.9.0.dist-info truststore
truststore-0.10.5.dist-info typing_extensions-4.16.0.dist-info typing_extensions.py
typing_inspection typing_inspection-0.4.4.dist-info uvicorn uvicorn-0.54.0.dist-info
""".split())


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_once(name, value):
    with (OUT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def regular(path):
    path = Path(path)
    require(path.is_absolute() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode), "Expected regular absolute file: " + str(path))
    require(path.resolve(strict=True) == path, "Noncanonical file: " + str(path))
    return path


def git(repository, *arguments):
    return subprocess.check_output(["git", "-C", str(repository), *arguments])


def authority(path):
    path = regular(path)
    data = path.read_bytes()
    value = json.loads(data)
    require(value["status"] == "ROOT_AUTHORIZED_INSTALLED_0_6" and value["component_version"] == "0.6.0", "Root authority is not armed for 0.6.0")
    require(value["expected_tools"] == 268 and type(value["expected_tools"]) is int and value["mcp_sdk"] == "2.2.0", "Unexpected session contract")
    for key in ("source_commit", "source_tree"):
        require(type(value[key]) is str and re.fullmatch(r"[a-f0-9]{40}", value[key]), "Missing exact " + key)
    repository = Path(value["source_repository"])
    require(repository.is_absolute() and repository.resolve(strict=True) == repository and repository.is_dir(), "Source repository must be canonical")
    require(git(repository, "rev-parse", value["source_commit"] + "^{tree}").decode().strip() == value["source_tree"], "Git tree mismatch")
    require(set(value["harness_sha256"]) == set(HARNESS), "All four reviewed harness hashes are required")
    for name in HARNESS:
        require(digest(regular(OUT / name)) == value["harness_sha256"][name], "Harness differs from root authority: " + name)
    for name in ("accepted_ci_audit", "wheel"):
        row = value[name]
        require(type(row["sha256"]) is str and re.fullmatch(r"[a-f0-9]{64}", row["sha256"]), "Missing root hash: " + name)
        require(digest(regular(row["path"])) == row["sha256"], "Root pin mismatch: " + name)
    accepted = json.loads(Path(value["accepted_ci_audit"]["path"]).read_bytes())
    require(accepted["status"] == "passed" and accepted["source_commit"] == value["source_commit"] and accepted["source_tree"] == value["source_tree"], "Accepted CI identity mismatch")
    require(accepted["source_repository"] == str(repository) and accepted["packages"]["component_version"] == "0.6.0", "Accepted CI repository/version mismatch")
    require(accepted["new_candidate_install_and_stdio_required"] is True and accepted["old_stdio_session_reused"] is False, "CI must require a new candidate session")
    require(accepted["run"]["status"] == "completed" and accepted["run"]["conclusion"] == "success", "CI is incomplete")
    asset = accepted["packages"]["assets"][WHEEL_NAME]
    require(asset["path"] == value["wheel"]["path"] and asset["sha256"] == value["wheel"]["sha256"] and asset["bytes"] == Path(asset["path"]).stat().st_size, "Wheel does not match accepted CI asset")
    require(type(value["minimum_free_bytes"]) is int and value["minimum_free_bytes"] >= 8 * 1024 * 1024, "An explicit capacity floor of at least 8MiB is required")
    return value, accepted, sha(data)


def file_state(path):
    info = path.lstat()
    row = {"mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid, "gid": info.st_gid, "mtime_ns": info.st_mtime_ns}
    if stat.S_ISLNK(info.st_mode):
        row.update(kind="symlink", target=os.readlink(path))
    elif stat.S_ISDIR(info.st_mode):
        row["kind"] = "directory"
    else:
        require(stat.S_ISREG(info.st_mode), "Unexpected preserved file type: " + str(path))
        row.update(kind="file", bytes=info.st_size, sha256=digest(path))
    after = path.lstat()
    require((info.st_mode, info.st_uid, info.st_gid, info.st_mtime_ns, info.st_size) == (after.st_mode, after.st_uid, after.st_gid, after.st_mtime_ns, after.st_size), "Input changed during snapshot")
    return row


def preservation_snapshot():
    require(digest(HISTORY / "manifest.json") == "95717935b8bcb49485a87872f016671843ca7723e3e5ec4386460632df5bc054", "Historical c49 manifest changed")
    require(digest(HISTORY / "environment-proof.json") == "637d0f6a70d3b97a18a1c7661d4d614b25b19d3ab5f3a407f0bde1cb89a362aa", "Historical snapshot ledger changed")
    proof = json.loads((HISTORY / "environment-proof.json").read_bytes())
    frozen = json.loads((HISTORY / "manifest.json").read_bytes())
    for name, expected in frozen["files_excluding_manifest"].items():
        path = regular(HISTORY / name)
        require(path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], "Historical c49 evidence changed: " + name)
    snapshots = proof["retained_snapshots"]
    require(len(snapshots) == 15 and sum(len(row["files"]) for row in snapshots) == 756, "Historical inventory differs")
    selected = set()
    for snapshot in snapshots:
        folder = Path(snapshot["root"])
        archive = regular(snapshot["archive"])
        require(folder.parent == BUILD and archive.parent == BUILD and digest(archive) == snapshot["archive_sha256"], "Historical archive identity changed")
        selected.add(archive)
        with tarfile.open(archive, "r:gz") as retained:
            for name, expected in snapshot["files"].items():
                path = regular(folder / name)
                require(path.resolve().is_relative_to(folder) and path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], "Historical snapshot changed")
                member = retained.getmember(snapshot["archive_prefix"] + "/" + name)
                require(member.isfile() and sha(retained.extractfile(member).read()) == expected["sha256"], "Historical archive member changed")
                selected.add(path)
    for root in (OLD, HISTORY):
        require(root.is_dir() and not root.is_symlink(), "Missing preserved root")
        selected.add(root)
        for folder, directories, files in os.walk(root, followlinks=False):
            selected.add(Path(folder))
            selected.update(Path(folder) / name for name in (*directories, *files))
    return {str(path): file_state(path) for path in sorted(selected)}


def preserve(manifest):
    require(preservation_snapshot() == manifest["preserved_inputs"], "Old environment or historical evidence changed")


def manifest_for(value, accepted, authority_sha):
    repository, commit = Path(value["source_repository"]), value["source_commit"]
    names = [name for name in git(repository, "ls-tree", "-r", "--name-only", "-z", commit, "--", "mcp_server").decode().split("\0") if name]
    modules = {name: sha(git(repository, "show", commit + ":" + name)) for name in names}
    readme = git(repository, "show", commit + ":README.md").decode()
    block = readme.split("<!-- BEGIN GENERATED MCP TOOLS -->", 1)[1].split("<!-- END GENERATED MCP TOOLS -->", 1)[0]
    tools = sorted(re.findall(r"^\| `([^`]+)` \|", block, re.M))
    require(len(tools) == len(set(tools)) == 268, "Pinned tool inventory differs")
    wheel = regular(value["wheel"]["path"])
    with ZipFile(wheel) as archive:
        require(archive.testzip() is None, "Corrupt wheel")
        entries = archive.infolist()
        members = {item.filename for item in entries if not item.is_dir()}
        require(len(members) == len(entries) and len(members) == len(set(archive.namelist())), "Wheel duplicate/directory members")
        for item in entries:
            name = PurePosixPath(item.filename)
            require(not name.is_absolute() and ".." not in name.parts and "\\" not in item.filename and ":" not in item.filename and stat.S_IFMT(item.external_attr >> 16) in (0, stat.S_IFREG), "Unsafe wheel layout")
            require(item.filename.startswith(("mcp_server/", DIST)), "Unexpected wheel root")
        metadata = BytesParser().parsebytes(archive.read(DIST + "METADATA"))
        require(metadata["Name"] == "blender-codex-bridge" and metadata["Version"] == "0.6.0" and "Development Status :: 3 - Alpha" in metadata.get_all("Classifier", []), "Wheel metadata differs")
        versions = [ast.literal_eval(node.value) for node in ast.parse(archive.read("mcp_server/__init__.py")).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "__version__" for target in node.targets)]
        require(versions == ["0.6.0"], "Wheel runtime version differs")
        require({name for name in members if name.startswith("mcp_server/")} == set(modules), "Wheel MCP member set differs from Git")
        require(all(sha(archive.read(name)) == digest_value for name, digest_value in modules.items()), "Wheel MCP bytes differ from Git")
        records = list(csv.reader(io.StringIO(archive.read(DIST + "RECORD").decode())))
        require(len(records) == len({row[0] for row in records}) and {row[0] for row in records} == members, "Wheel RECORD member set differs")
        for name, signed, length in records:
            if name == DIST + "RECORD":
                require(signed == length == "", "Wheel RECORD self-hash differs")
            else:
                body = archive.read(name)
                require(signed == "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(body).digest()).rstrip(b"=").decode() and length == str(len(body)), "Wheel RECORD digest differs")
        expanded = sum(item.file_size for item in entries)
    require(len(modules) == accepted["packages"]["exact_git_mcp_members"], "CI MCP count differs")
    require(shutil.disk_usage(OUT).free >= max(value["minimum_free_bytes"], expanded + 8 * 1024 * 1024), "Insufficient free capacity")
    expected_tools = (json.dumps(tools, indent=2) + "\n").encode()
    manifest = {"commit": commit, "source_tree": value["source_tree"], "source_sha256": accepted["source_python_sha256"], "source_repository": str(repository), "authority_sha256": authority_sha,
        "accepted_ci_audit": value["accepted_ci_audit"], "packages": {WHEEL_NAME: value["wheel"]["sha256"]}, "expected_module_sha256": modules, "expected_tools_sha256": sha(expected_tools),
        "venv": str(NEW), "site_packages": str(SITE), "old_venv": str(OLD), "dependency_reuse": "Explicit third-party-only symlinks; no bridge, startup hook, .pth or old entrypoint reuse. Inputs are not OS-sandboxed; every preserved state is checked before/after owned processes.", "preserved_inputs": preservation_snapshot()}
    return manifest, expected_tools


def load_prepared(path):
    value, accepted, authority_sha = authority(path)
    manifest = json.loads((OUT / "distribution-manifest.json").read_bytes())
    require(manifest["authority_sha256"] == authority_sha and manifest["commit"] == value["source_commit"] and manifest["source_tree"] == value["source_tree"], "Prepared identity differs")
    require(digest(OUT / "packages" / WHEEL_NAME) == value["wheel"]["sha256"], "Staged wheel changed")
    require(digest(OUT / "expected-tools.json") == manifest["expected_tools_sha256"], "Prepared tool inventory changed")
    if (OUT / "dependency-links.json").exists():
        for name, target in json.loads((OUT / "dependency-links.json").read_bytes()).items():
            link = SITE / name
            require(link.is_symlink() and os.readlink(link) == target, "Borrowed dependency link changed")
    preserve(manifest)
    return value, accepted, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    args = parser.parse_args()
    require(sys.flags.isolated and sys.flags.dont_write_bytecode and os.name == "posix", "Use isolated Linux Python -I -B")
    value, accepted, authority_sha = authority(args.authority)
    require(not NEW.exists() and not (OUT / "distribution-manifest.json").exists() and not (OUT / "packages").exists(), "Preparation output already exists; preserve it")
    manifest, tools = manifest_for(value, accepted, authority_sha)
    write_once("distribution-manifest.json", manifest)
    with (OUT / "expected-tools.json").open("xb") as stream:
        stream.write(tools)
    (OUT / "packages").mkdir()
    with (OUT / "packages" / WHEEL_NAME).open("xb") as stream:
        stream.write(Path(value["wheel"]["path"]).read_bytes())
    receipt = {"status": "running", "source_commit": value["source_commit"], "phase": "create_new_venv", "old_inputs_preserved": False}
    primary = None
    try:
        command = [str(BASE_PYTHON), "-I", "-B", "-m", "venv", "--without-pip", str(NEW)]
        with (OUT / "prepare-venv.log").open("xb") as log:
            subprocess.run(command, cwd="/tmp", stdout=log, stderr=subprocess.STDOUT, timeout=180, check=True)
        require(SITE.is_dir() and SITE.resolve() == SITE, "New site is not regular")
        links = {}
        for source in sorted(OLD_SITE.iterdir()):
            name = source.name
            if name in {"mcp_server", "__pycache__", "sitecustomize", "usercustomize", "sitecustomize.py", "usercustomize.py", "pip"} or name.startswith(("blender_codex_bridge-", "pip-", "sitecustomize.", "usercustomize.")) or source.suffix in {".pth", ".pyc"}:
                continue
            require(name in DEPENDENCIES, "Dependency entry is outside the reviewed allowlist: " + name)
            require(not source.is_symlink() and source.resolve().is_relative_to(OLD_SITE) and (source.is_file() or source.is_dir()), "Unexpected dependency entry")
            target = SITE / name
            require(not target.exists() and not target.is_symlink(), "New dependency entry collides")
            target.symlink_to(source, target_is_directory=source.is_dir())
            links[name] = str(source)
        require(set(links) == DEPENDENCIES and not (SITE / "mcp_server").exists(), "Dependency/bridge separation failed")
        write_once("dependency-links.json", links)
        receipt.update(status="prepared", phase="completed", command=command, new_venv=str(NEW), dependency_links=len(links), package_installed=False, stdio_executed=False)
    except BaseException as error:
        primary = error
        receipt.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        try:
            preserve(manifest)
            receipt["old_inputs_preserved"] = True
        except BaseException as error:
            receipt.update(status="failed", preservation_error={"type": type(error).__name__, "message": str(error)})
            primary = primary or error
        try:
            write_once("environment-preparation-receipt.json", receipt)
        except Exception as error:
            sys.stderr.write(json.dumps({"receipt_failure": str(error), "primary_failure": None if primary is None else str(primary), "preparation": receipt}) + "\n")
            if primary is None:
                raise
        if primary is not None and sys.exc_info()[0] is None:
            raise primary


if __name__ == "__main__":
    main()
