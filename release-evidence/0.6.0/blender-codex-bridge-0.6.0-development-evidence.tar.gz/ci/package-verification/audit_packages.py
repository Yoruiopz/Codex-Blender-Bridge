"""Static audit of downloaded development artifacts against one immutable Git tree."""

from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import ast
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import tomllib

OUTPUT = Path(__file__).resolve().parent
IDENTITY_PATH = OUTPUT.parent / "audit-identity.json"


def _verified_publication_identity():
    identity_bytes = IDENTITY_PATH.read_bytes()
    if len(identity_bytes) > 65536:
        raise RuntimeError("Publication identity exceeds its bounded input budget")
    identity = json.loads(identity_bytes)
    if not isinstance(identity, dict) or identity.get("status") != "ROOT_ACCEPTED_PUBLIC_HEAD":
        raise RuntimeError("A verified publication identity is required before package auditing")
    if identity.get("component_version") != "0.6.0":
        raise RuntimeError("Expected the numeric 0.6.0 prerelease candidate")
    for field, length in (("source_commit", 40), ("source_tree", 40),
                          ("source_python_sha256", 64), ("artifact_sha256", 64)):
        value = identity.get(field)
        if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{" + str(length) + r"}", value) is None:
            raise RuntimeError("Invalid verified publication identity field: " + field)
    raw_checkout = identity.get("source_repository")
    if not isinstance(raw_checkout, str):
        raise RuntimeError("An exact canonical source checkout path is required")
    checkout = Path(raw_checkout)
    accepted_checkout = Path("/dev/shm/blender-codex-resume-20261025/integration-0.6")
    if (not checkout.is_absolute() or str(checkout) != raw_checkout
            or checkout != accepted_checkout
            or checkout.resolve(strict=True) != checkout or not checkout.is_dir()):
        raise RuntimeError("Source checkout must equal the exact pinned canonical 0.5 recovery checkout")
    for field in ("source_python_files", "expected_addon_members", "expected_mcp_members", "expected_plugin_members", "expected_wheel_members", "expected_source_members"):
        if type(identity.get(field)) is not int or identity[field] <= 0:
            raise RuntimeError("Accepted exact-source count required: " + field)
    return identity, hashlib.sha256(identity_bytes).hexdigest()


IDENTITY, IDENTITY_SHA = _verified_publication_identity()
REPO = Path(IDENTITY["source_repository"])
ARTIFACT = OUTPUT.parent / "artifacts/development-packages.zip"
COMMIT = IDENTITY["source_commit"]
TREE = IDENTITY["source_tree"]
OUTER_SHA = IDENTITY["artifact_sha256"]
PYTHON_SHA = IDENTITY["source_python_sha256"]
ADDON = "blender_codex_bridge-0.6.0.zip"
WHEEL = "blender_codex_bridge-0.6.0-py3-none-any.whl"
PLUGIN = "blender-codex-bridge-plugin-0.6.0.zip"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def git_files():
    records = git("ls-tree", "-rz", "--full-tree", COMMIT).split(b"\0")
    entries = {}
    for record in records:
        if not record:
            continue
        prefix, path = record.split(b"\t", 1)
        mode, kind, object_id = prefix.decode().split()
        require(kind == "blob" and mode in {"100644", "100755"}, "Unexpected Git entry type")
        entries[path.decode()] = object_id
    names = sorted(entries)
    batch = subprocess.run(
        ["git", "-C", str(REPO), "cat-file", "--batch"],
        input="".join(entries[name] + "\n" for name in names).encode(),
        capture_output=True, check=True,
    ).stdout
    stream = io.BytesIO(batch)
    result = {}
    for name in names:
        object_id, kind, length = stream.readline().decode().rstrip().split()
        require(object_id == entries[name] and kind == "blob", "Git object identity changed")
        payload = stream.read(int(length))
        require(len(payload) == int(length) and stream.read(1) == b"\n", "Truncated Git blob")
        result[name] = payload
    require(not stream.read(), "Unaccounted Git batch output")
    return result


def archive_members(data, label):
    devices = {"con", "prn", "aux", "nul"} | {
        stem + str(index) for stem in ("com", "lpt") for index in range(1, 10)
    }
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        require(len(entries) <= 10000, label + ": member budget exceeded")
        require(sum(item.file_size for item in entries) <= 128 * 1024 * 1024,
                label + ": expanded size budget exceeded")
        seen, members = set(), {}
        for item in entries:
            name = item.filename
            parts = name.rstrip("/").split("/")
            require(not name.startswith("/") and not item.is_dir(), label + ": unexpected directory")
            require(not any(part in {"", ".", ".."} or part.endswith((".", " "))
                            or any(ord(char) < 32 for char in part)
                            or any(char in part for char in "\\:<>\"|?*")
                            or part.split(".", 1)[0].casefold() in devices for part in parts),
                    label + ": unsafe archive member " + name)
            require(name.casefold() not in seen, label + ": duplicate or case-colliding member")
            seen.add(name.casefold())
            require(stat.S_IFMT(item.external_attr >> 16) in {0, stat.S_IFREG},
                    label + ": symlink/special member")
            require(not item.flag_bits & 1, label + ": encrypted member")
            payload = archive.read(item)
            require(len(payload) == item.file_size, label + ": member length mismatch")
            members[name] = payload
        require(archive.testzip() is None, label + ": CRC failure")
        return members, {
            "sha256": sha(data), "bytes": len(data), "members": len(entries),
            "expanded_bytes": sum(item.file_size for item in entries),
            "crc_verified": True, "safe_unique_regular_member_layout": True,
            "member_fingerprints": {
                name: {"bytes": len(payload), "sha256": sha(payload)}
                for name, payload in sorted(members.items())
            },
        }


def compare_source(members, expected, label):
    require(set(members) == set(expected), label + ": missing or extra source members")
    mismatches = [name for name in members if members[name] != expected[name]]
    require(not mismatches, label + ": Git source bytes differ: " + str(mismatches))
    return {"files_compared": len(expected), "member_set_exact": True,
            "every_member_byte_identical_to_git": True, "mismatches": []}


def assignment(payload, name):
    values = [ast.literal_eval(node.value) for node in ast.parse(payload).body
              if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    require(len(values) == 1, "Ambiguous literal assignment " + name)
    return values[0]


def main():
    require(git("cat-file", "-t", COMMIT).decode().strip() == "commit", "Pinned commit unavailable")
    require(git("rev-parse", COMMIT + "^{tree}").decode().strip() == TREE, "Git tree mismatch")
    # All comparisons read immutable Git blobs at COMMIT; no checkout or import is used.
    source = git_files()
    require(len(source) == IDENTITY["expected_source_members"], "Frozen full source member count mismatch")
    python_files = {name: sha(payload) for name, payload in source.items()
                    if PurePosixPath(name).parts[0] in {"addon", "mcp_server", "scripts"}
                    and name.endswith(".py")}
    python_fingerprint = sha(json.dumps(python_files, sort_keys=True).encode())
    require(len(python_files) == IDENTITY["source_python_files"] and python_fingerprint == PYTHON_SHA,
            "Frozen Python fingerprint mismatch")
    outer_data = ARTIFACT.read_bytes()
    require(sha(outer_data) == OUTER_SHA, "Downloaded outer artifact hash mismatch")
    outer, outer_proof = archive_members(outer_data, "CI artifact")
    require(set(outer) == {ADDON, WHEEL, PLUGIN, "SHA256SUMS.txt"}, "Unexpected outer asset set")
    checksum_lines = outer["SHA256SUMS.txt"].decode("ascii").splitlines()
    checksums = {}
    for line in checksum_lines:
        checksum, name = line.split("  ", 1)
        require(len(checksum) == 64 and all(char in "0123456789abcdef" for char in checksum),
                "Malformed checksum")
        require(name not in checksums and name in {ADDON, WHEEL, PLUGIN}, "Unexpected checksum entry")
        checksums[name] = checksum
    require(set(checksums) == {ADDON, WHEEL, PLUGIN}, "Incomplete checksum ledger")
    require(all(sha(outer[name]) == value for name, value in checksums.items()), "Asset checksum mismatch")

    addon, addon_proof = archive_members(outer[ADDON], "Add-on ZIP")
    addon_expected = {
        name.removeprefix("addon/"): payload for name, payload in source.items()
        if name.startswith("addon/blender_codex_bridge/")
        and "__pycache__" not in PurePosixPath(name).parts and not name.endswith(".pyc")
    }
    addon_proof["source_comparison"] = compare_source(addon, addon_expected, "Add-on ZIP")
    addon_proof["source_root"] = "addon/blender_codex_bridge/"
    require(len(addon) == IDENTITY["expected_addon_members"], "Expected exact accepted add-on member count")
    manifest = tomllib.loads(addon["blender_codex_bridge/blender_manifest.toml"].decode())
    metadata = assignment(addon["blender_codex_bridge/__init__.py"], "bl_info")
    constants_version = assignment(addon["blender_codex_bridge/constants.py"], "ADDON_VERSION")
    require(manifest["id"] == "blender_codex_bridge" and manifest["version"] == "0.6.0"
            and metadata["version"] == constants_version == (0, 6, 0), "Add-on identity mismatch")
    require(manifest["type"] == "add-on" and manifest["schema_version"] == "1.0.0",
            "Unexpected Blender manifest schema/type")
    addon_proof["identity"] = {"manifest": manifest, "bl_info": metadata,
                               "ADDON_VERSION": constants_version}

    plugin, plugin_proof = archive_members(outer[PLUGIN], "Plugin ZIP")
    plugin_prefix = "plugins/blender-codex-bridge/"
    plugin_expected = {
        "blender-codex-bridge/" + name.removeprefix(plugin_prefix): payload
        for name, payload in source.items() if name.startswith(plugin_prefix)
        and not any(part in {".agents", "__pycache__"} for part in PurePosixPath(name).parts)
        and not name.endswith(".pyc")
    }
    plugin_proof["source_comparison"] = compare_source(plugin, plugin_expected, "Plugin ZIP")
    plugin_proof["source_root"] = plugin_prefix
    require(len(plugin) == IDENTITY["expected_plugin_members"], "Expected exact five-member plugin payload")
    plugin_proof["intentional_builder_exclusions"] = [
        name for name in sorted(source) if name.startswith(plugin_prefix)
        and any(part in {".agents", "__pycache__"} for part in PurePosixPath(name).parts)
    ]
    plugin_manifest = json.loads(plugin["blender-codex-bridge/.codex-plugin/plugin.json"])
    plugin_mcp = json.loads(plugin["blender-codex-bridge/.mcp.json"])
    require(plugin_manifest["name"] == "blender-codex-bridge"
            and plugin_manifest["version"] == "0.6.0", "Plugin identity mismatch")
    server = plugin_mcp["mcpServers"]["blender-codex-bridge"]
    require(server["command"] == "blender-codex-mcp" and server["args"] == ["--transport", "stdio"]
            and server["env"]["BLENDER_CODEX_BRIDGE_HOST"] == "127.0.0.1",
            "Plugin MCP entrypoint mismatch")
    for relative in (plugin_manifest["mcpServers"], plugin_manifest["skills"] + "blender-studio/SKILL.md"):
        require("blender-codex-bridge/" + relative.removeprefix("./") in plugin,
                "Plugin manifest points to missing packaged content")
    plugin_proof["identity"] = {"manifest": plugin_manifest, "mcp_configuration": plugin_mcp}

    _, wheel_proof = archive_members(outer[WHEEL], "MCP wheel")
    project = tomllib.loads(source["pyproject.toml"].decode())["project"]
    mcp_version = assignment(source["mcp_server/__init__.py"], "__version__")
    require(project["name"] == "blender-codex-bridge"
            and project["version"] == mcp_version == manifest["version"] == plugin_manifest["version"],
            "Component versions disagree")
    report = {
        "schema_version": 1,
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed",
        "source_commit": COMMIT, "source_tree": TREE, "immutable_git_source_verified": True, "working_tree_used": False,
        "publication_identity": {"path": str(IDENTITY_PATH), "sha256": IDENTITY_SHA,
                                 "status": IDENTITY["status"]},
        "source_files": len(source),
        "python_source_files": len(python_files), "python_source_sha256": python_fingerprint,
        "artifact": {"path": str(ARTIFACT), **outer_proof},
        "checksum_file": {"sha256": sha(outer["SHA256SUMS.txt"]), "entries": checksums,
                          "all_three_named_assets_verified": True},
        "addon": addon_proof, "plugin": plugin_proof,
        "wheel_archive": wheel_proof,
        "wheel_record_and_mcp_source_audit": "See separate wheel-audit.json independent receipt.",
        "component_identity_agreement": {"name": project["name"], "version": project["version"],
                                         "development_classifier": "Development Status :: 3 - Alpha" in project["classifiers"]},
        "installed_smoke_repeated": False,
        "limitations": [
            "Static artifact/source audit only; no Blender or Windows process launched.",
            "No package installation or MCP stdio rerun; CI evidence is separate.",
            "Artifacts have 0.6.0 alpha prerelease identity; this static audit does not qualify or publish them.",
            "Build archives carry component versions but no embedded Git commit attestation; this receipt ties every audited source member to the pinned Git tree.",
            "Known native import failures and release-readiness gates remain unresolved by packaging checks.",
        ],
        "release_acceptance": False,
        "release_candidate_qualified": False,
        "new_candidate_install_and_stdio_required": True,
        "old_stdio_session_reused": False,
    }
    (OUTPUT / "addon-plugin-outer-audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "source_commit": COMMIT,
                      "addon_source_files": len(addon), "plugin_source_files": len(plugin),
                      "wheel_members": wheel_proof["members"], "checksums": checksums,
                      "receipt": str(OUTPUT / "addon-plugin-outer-audit.json")}))


if __name__ == "__main__":
    main()
