"""Combine exact public-head development CI and package evidence, without runtime tests."""
import sys
sys.dont_write_bytecode = True

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
IDENTITY=json.loads((ROOT/'audit-identity.json').read_bytes())
assert IDENTITY['status']=='ROOT_ACCEPTED_PUBLIC_HEAD', 'Wait for exact public commit notification'
assert IDENTITY["component_version"] == "0.5.0", "Expected the numeric 0.5.0 prerelease candidate"
assert re.fullmatch(r'[0-9a-f]{40}', IDENTITY['source_commit'])
assert re.fullmatch(r'[0-9a-f]{40}', IDENTITY['source_tree'])
assert re.fullmatch(r'[0-9a-f]{64}', IDENTITY['source_python_sha256'])
assert type(IDENTITY['run_id']) is int and IDENTITY['run_id'] > 0
SOURCE=Path(IDENTITY['source_repository'])
COMMIT=IDENTITY['source_commit']
TREE=IDENTITY['source_tree']
RUN=IDENTITY['run_id']
assert type(IDENTITY['accepted_native_local_source']) is dict
assert TREE==IDENTITY['accepted_native_local_source']['tree']
assert re.fullmatch(r'[0-9a-f]{40}', IDENTITY['accepted_native_local_source']['commit'])
assert type(IDENTITY['source_python_files']) is int and IDENTITY['source_python_files']>0
assert type(IDENTITY['expected_source_members']) is int and IDENTITY['expected_source_members']>0
assert type(IDENTITY['pull_request_number']) is int and IDENTITY['pull_request_number']>0

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((ROOT/name).read_bytes())

def main():
    matrix=read('matrix-verification.json')
    packages=read('package-verification/package-audit-summary.json')
    outer=read('package-verification/addon-plugin-outer-audit.json')
    wheel=read('package-verification/wheel-audit.json')
    agreement=read('plugin-rest-metadata-agreement.json')
    run=read('workflow-run.json')
    artifacts=read('artifacts-rest.json')['artifacts']
    pr=read('pr-info-plugin.json')['structuredContent']
    for report in (matrix,packages,outer,wheel,agreement):
        assert report['status']=='passed'
    for report in (matrix,packages,outer,wheel):
        assert report['source_commit']==COMMIT and report['source_tree']==TREE
    assert subprocess.check_output(['git','-C',str(SOURCE),'cat-file','-t',COMMIT]).decode().strip()=='commit'
    assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse',COMMIT+'^{tree}']).decode().strip()==TREE
    # Immutable source comes only from Git blobs, with no working-tree import.
    assert pr['number']==IDENTITY['pull_request_number'] and pr['head_sha']==COMMIT and pr['state']=='open' and pr['draft']
    assert run['id']==RUN and run['head_sha']==COMMIT and run['event']=='push'
    assert run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
    assert len(matrix['jobs'])==7 and len(matrix['matrix'])==6
    assert all(row['passed']==IDENTITY['expected_passed'] and row['skipped']==3 and row['tests']==(IDENTITY['expected_passed']+3) for row in matrix['matrix'])
    assert outer['source_files']==IDENTITY['expected_source_members']
    assert outer['python_source_files']==IDENTITY['source_python_files']
    assert outer['python_source_sha256']==IDENTITY['source_python_sha256']
    assert len(artifacts)==7
    downloads=[]
    for artifact in artifacts:
        path=ROOT/'artifacts'/('development-packages.zip' if artifact['name'].startswith('blender-codex-bridge-development-') else artifact['name']+'.zip')
        data=path.read_bytes()
        assert len(data)==artifact['size_in_bytes'] and artifact['digest']=='sha256:'+sha(data)
        assert artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==COMMIT and not artifact['expired']
        downloads.append({'id':artifact['id'],'name':artifact['name'],'bytes':len(data),'sha256':sha(data),'path':str(path),'api_digest_verified':True})
    (ROOT/'download-index.json').write_text(json.dumps(downloads,indent=2)+'\n')
    assets={}
    for name,meta in outer['artifact']['member_fingerprints'].items():
        path=ROOT/'package-assets'/name
        data=path.read_bytes()
        assert len(data)==meta['bytes'] and sha(data)==meta['sha256']
        assets[name]={'path':str(path),**meta}
    receipts={}
    for name in ('matrix-verification.json','plugin-rest-metadata-agreement.json','download-index.json',
                 'package-verification/package-audit-summary.json','package-verification/addon-plugin-outer-audit.json',
                 'package-verification/wheel-audit.json'):
        path=ROOT/name
        receipts[name]={'path':str(path),'sha256':sha(path.read_bytes())}
    result={'schema_version':1,'status':'passed','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'repository':'Yoruiopz/Codex-Blender-Bridge','pull_request':{'number':IDENTITY['pull_request_number'],'url':pr['url'],'draft':True,'head_sha_verified':COMMIT},
        'source_commit':COMMIT,'source_tree':TREE,'source_repository':str(SOURCE),'immutable_git_source_verified':True,'working_tree_used':False,
        'source_python_files':IDENTITY['source_python_files'],'source_files':IDENTITY['expected_source_members'],'source_python_sha256':outer['python_source_sha256'],
        'run':{'id':RUN,'url':run['html_url'],'event':'push','attempt':1,'status':'completed','conclusion':'success'},
        'all_seven_jobs_successful':True,'all_seven_checkout_commits_verified':True,
        'all_six_matrix_junit_member_sets_crc_digests_verified':True,
        'each_matrix_result':{'passed':IDENTITY['expected_passed'],'windows_only_skipped':3,'failures':0,'errors':0,'total_cases':(IDENTITY['expected_passed']+3),'same_test_identities_across_all_cells':True},
        'matrix_versions':{'python':['3.10','3.11','3.12'],'mcp_sdk':['2.0.0','2.2.0']},
        'known_windows_only_skips':matrix['known_windows_only_skips'],
        'all_seven_artifact_api_digests_sizes_and_zip_crc_verified':True,'downloaded_artifact_bytes':sum(x['bytes'] for x in downloads),
        'packages':{'exact_git_addon_members':IDENTITY['expected_addon_members'],'exact_git_mcp_members':IDENTITY['expected_mcp_members'],'exact_git_plugin_members':IDENTITY['expected_plugin_members'],
            'wheel_members':IDENTITY['expected_wheel_members'],'wheel_signed_record_payloads_verified':IDENTITY['expected_wheel_members']-1,'safe_unique_archive_layouts_verified':True,
            'metadata_and_component_identity_verified':True,'component_version':'0.5.0',
            'development_classifier':'Development Status :: 3 - Alpha','assets':assets},
        'evidence_receipts':receipts,
        'retrieval':'GitHub plugin job/artifact/log/download APIs and Sediment local byte download; read-only gh API for push-run/full metadata because connector commit-run discovery filters pull_request events. Persisted provenance excludes signed URLs/credential values/artifact file references.',
        'fresh_install_or_stdio_test_performed':False,'new_candidate_install_and_stdio_required':True,'old_stdio_session_reused':False,'fresh_install_scope':'This static-CI receipt does not execute the package. A separately retained NEW 0.5.0 wheel installation and real MCP stdio session must match these exact accepted artifact bytes and this source. Historical 0.3.0 sessions cannot be relabeled or reused as candidate-session acceptance.',
        'native_blender_or_windows_tested_by_this_audit':False,'source_or_pr_mutations_performed':False,
        'release_gates_closed':[],'all_14_release_gates_remain_open':True,'release_candidate_qualified':False,'release_acceptance':False,
        'limitations':['Exact-head development CI and package evidence only; not 1.0 acceptance.','CI wheel smoke uses installed --help; a NEW 0.5.0 installation and real stdio session remain separately required.','No native Blender, Windows or full artist-workflow qualification in this audit.']}
    (ROOT/'combined-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'passed','commit':COMMIT,'ci_jobs':7,'matrix_cells':6,'each_passed':IDENTITY['expected_passed'],'each_skipped':3,'assets':4}))

if __name__=='__main__':
    main()
