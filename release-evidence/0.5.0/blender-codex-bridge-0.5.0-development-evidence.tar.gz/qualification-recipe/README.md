# Recovered 0.5 qualification recipe

Source-only preparation, 2026-10-25. No build, installation, MCP session, Blender
execution, workflow/artifact download or release was run by this preparer. The
four installed-wheel helpers and native wrapper passed in-memory compilation;
the original helpers and published previous ZIPs were read and hashed only.
Root owns execution, source review, acceptance, durable retention and publication.

Use one clean reviewed 0.5 source commit containing the bounded painting and UV
increments. Current proposed source is
`/dev/shm/blender-codex-resume-20261025/integration-0.5`; root must substitute its
actual public release commit/tree in every authority and independently prove
source equality. The former RAM integration and its reports were lost during
restart. Earlier counts/timings recorded in the task ledger are historical
statements, not substitutes for the missing final combined evidence.

## Exact CI packages first

Follow [the current CI/package adapter recipe](ci-package/authority-adapter-v2/README.md).
The earlier `ci-package/` v1 freeze is retained as source history; use the complete
`authority-adapter-v2/` helper set for this candidate. Root supplies actual new
run/job/artifact metadata and downloads; preserved overlay metadata is from old
`0487430`, not accepted release `4470d88`. Reuse checking code only. Pin the new
candidate branch separately from unchanged draft PR #8. All six Python/SDK cells
and the package job, original JUnit ZIPs/logs, artifact API digests/sizes/CRC,
complete payload-to-Git equality and wheel RECORD checks must pass.

The extracted accepted `package-assets/` must contain exactly these component
files and their checksums before any installed check:

- `blender_codex_bridge-0.5.0.zip`
- `blender_codex_bridge-0.5.0-py3-none-any.whl`
- `blender-codex-bridge-plugin-0.5.0.zip`
- `SHA256SUMS.txt`

The package job's installed `--help` invocation does not replace a fresh MCP
session or installed Blender check. Package/file/member counts are taken from
the final source and accepted artifacts. Do not reuse an earlier wheel solely
because its filename or version matches.

## Fresh actual installed MCP session

`installed-wheel/` contains copied/adapted `prepare.py`, `run-installed.py`,
`installed_stdio.py`, `finalize.py` and an **unarmed** authority template.
`installed-adaptation.json` records the exact original and new bytes/hashes.
Adaptations are limited to component strings `0.4.0 -> 0.5.0`, the arming literal,
and `prepare.BUILD` becoming the original absolute build root, so relocation
cannot accidentally use a new folder as the old dependency/history source.

Root copies this directory to a fresh exclusive attempt location, reviews its
four script hashes and writes a new `authority.json`. Required fields are:

- `status = ROOT_AUTHORIZED_INSTALLED_0_5`, version `0.5.0`.
- Exact canonical source repository, full 40-character public commit and tree.
- Accepted current `combined-audit.json` absolute path and SHA-256.
- The same accepted wheel absolute path, SHA-256 and actual accepted asset size.
- Exactly 266 public tools, SDK `2.2.0`, at least the template's 12 MiB capacity
  floor, plus dynamic wheel expansion and actual new output headroom.
- Exact four copied helper hashes in `harness_sha256`.

The template remains unarmed until root verifies these real inputs. The accepted
CI receipt must require a new session; old stdio evidence is never rebound.

```bash
QUAL_PY=/workspace/Codex-Blender-Bridge/.venv/bin/python
QUAL_INSTALLED=/dev/shm/blender-codex-resume-20261025/installed-0.5-attempt-1
"$QUAL_PY" -I -B "$QUAL_INSTALLED/prepare.py" --authority "$QUAL_INSTALLED/authority.json"
"$QUAL_PY" -I -B "$QUAL_INSTALLED/run-installed.py" --authority "$QUAL_INSTALLED/authority.json"
"$QUAL_PY" -I -B "$QUAL_INSTALLED/finalize.py" --authority "$QUAL_INSTALLED/authority.json"
```

These are root execution commands, not commands run by this recipe. Root first
copies the prepared helpers/template to that new absent destination. They create
a fresh no-pip Python 3.12 venv, stage the exact new wheel, and borrow only the
explicit 59-entry third-party allowlist from the preserved c49 environment by
individual symlinks. No old bridge code/distribution/entrypoint, pip, `.pth`,
startup hooks or bytecode are borrowed. Symlinks are read-only inputs by contract,
not OS-enforced isolation. Complete frozen historical files/archives and old
environment types/modes/uid/gid/mtime/hash state are checked before/after each
owned subprocess and at finalization. A mismatch fails; never relax preservation.

Root pip runs with `--python NEW/bin/python --no-index --no-deps --no-cache-dir
--no-compile`, never upgrade or force-reinstall. The fresh interpreter and child
MCP server use `-I -B`, new writable HOME/cache/config/temp directories, and
`cwd=/tmp`. Every loaded bridge module must be a new regular installed file
matching both wheel and immutable Git; all installed RECORD/direct URL/entrypoint
rows are independently verified. Third-party dependency reuse is disclosed.

The unchanged 266-tool checking logic expects actual SDK initialization/listing,
core-only defaults, 25 disabled domains, 195 malformed standard-JSON cases and
225 retained SDK response receipts. Root must inspect a real discrepancy rather
than alter counts to fit a result. Direct annotation/stub forwarding checks are
separate from RPC; stored SDK responses are not raw wire frames. There is no
valid target-verification or preview RPC, Blender session, native sampling or
installed artist A–F acceptance in this MCP-only check.

## Installed Blender ZIP: mandatory 0.3 route and extra 0.4 route

Both previous ZIPs survived on overlay and were rehashed/read-only CRC/version
checked for this recipe; see `previous-package-inputs.json`:

| Previous input | SHA-256 | Required settings |
| --- | --- | --- |
| Published 0.3.0, 133,778 bytes | `6e06aafaac6378569aa89763d4074531320506c53fcb7d6e02e476f183689ea8` | 108 legacy tools; existing narrow undiscoverable-metadata exception only for this previous package |
| Published 0.4.0, 732,258 bytes | `1d212a02a5a1a4a30bab62c8043d3ae63e7a626687507a5262c2fec29c9b357b` | 266 tools; discovery required, no exception |

The 0.4 route supplements the original 0.3 upgrade/rollback requirement. It must
not replace it. The exact accepted 0.5 candidate requires discovery and the
current public tool-name file produced from its frozen Git inventory.

After the accepted wheel preparation creates `expected-tools.json`, root creates
two new pinned configs with the final source's existing configuration generator:

```bash
QUAL_SOURCE=/dev/shm/blender-codex-resume-20261025/integration-0.5
QUAL_PY=/workspace/Codex-Blender-Bridge/.venv/bin/python
QUAL_ASSETS=/dev/shm/blender-codex-resume-20261025/accepted-ci/package-assets
QUAL_NAMES=/dev/shm/blender-codex-resume-20261025/installed-0.5-attempt-1/expected-tools.json
QUAL_CONFIGS=/tmp/blender-codex-0.5-package-configs-20261025

"$QUAL_PY" -B "$QUAL_SOURCE/scripts/package_probe_config.py" \
  --candidate "$QUAL_ASSETS/blender_codex_bridge-0.5.0.zip" \
  --candidate-tools 266 --candidate-tools-file "$QUAL_NAMES" \
  --previous /workspace/Codex-Blender-Bridge/build/public-facing-20261022/anonymous-release-downloads/0.3.0/blender_codex_bridge-0.3.0.zip \
  --previous-tools 108 --allow-previous-undiscoverable \
  --output "$QUAL_CONFIGS/previous-0.3.json"

"$QUAL_PY" -B "$QUAL_SOURCE/scripts/package_probe_config.py" \
  --candidate "$QUAL_ASSETS/blender_codex_bridge-0.5.0.zip" \
  --candidate-tools 266 --candidate-tools-file "$QUAL_NAMES" \
  --previous /workspace/Codex-Blender-Bridge/build/prerelease-0.4-ci-20261024/package-assets/blender_codex_bridge-0.4.0.zip \
  --previous-tools 266 --output "$QUAL_CONFIGS/previous-0.4.json"
```

Root first creates the new config directory and rechecks actual ZIP hashes/free
capacity. Config creation refuses an existing output. `run_installed_addon.py`
and the unchanged reviewed `private_display.py` are source-only prepared beside
this README. Copy both into **two separate new absent `/tmp` attempt folders**,
then root invokes the wrapper, once with each config:

```bash
QUAL_NATIVE_03=/tmp/blender-codex-0.5-installed-previous03-20261025
QUAL_NATIVE_04=/tmp/blender-codex-0.5-installed-previous04-20261025
"$QUAL_PY" -B "$QUAL_NATIVE_03/run_installed_addon.py" "$QUAL_SOURCE" "$QUAL_CONFIGS/previous-0.3.json"
"$QUAL_PY" -B "$QUAL_NATIVE_04/run_installed_addon.py" "$QUAL_SOURCE" "$QUAL_CONFIGS/previous-0.4.json"
```

The wrapper calls only the approved private-display helper and isolated native
runner, with exactly `--case installed_addon_probe`, both explicit Linux binaries
and 180-second per-process supervision. It refuses dirty source, changed helper
or reused attempt paths, and binds initial/final source, helper and config hashes.
No direct Blender command, broad default inventory or interactive opt-in is used.

Each run is one fresh process per build: fresh candidate → previous → upgrade →
rollback, with clean-directory replacement inside its owned disposable profile.
This restarts the loopback server twice per row, **not the Blender process**.
Both configs therefore produce four process results total, each with four rows.
Root must independently verify exact candidate names/hidden metadata/member bytes,
installed module origins, default denial, discovery policy, bounded object
creation/transformation, eight successful connect/reconnect receipts per process,
unregister, no project save and no preference save. Previous0.3 actual names are
recorded with its 108-count pin; candidate names are exact, not count-only.

The fixture removes checkout import paths and grants only its disposable testing
authority after default-permission observations. It does not establish preference
migration, interactive uninstall, Blender restart/reopen, complete installed
MCP-to-Blender artist scenarios, native UV/paint execution, Windows or stable1.0.

## Combined source-native increments and retained scope

Root separately runs the final combined source's explicit `large_surface_paint`
and `uv_edit_guard` cases through `scripts/run_blender_checks.py` under the same
reviewed private display on both exact builds. Use a new `/tmp` native output,
900-second **supervisor** allowance for the paint fixture; its product job limit
stays at most 300 seconds. Do not change deadlines or switch to direct Blender.
Retain full raw reports/logs and exact source/helper fingerprints, complete 4K
pixel/stencil/sculpt-mask oracles, actual durations/RSS/blocking/cancellation
measurements, UV full maps/marker/prefix-recovery facts and every declared limit.

Passing this recipe supports only the exact bounded alpha checks described. It
does not qualify visual appearance, constrained-memory behavior, native global
undo/durable restoration, all native inventory, A–F, Windows or full artist1.0.
Save, protected capture, held shader REMOVE/Timeline-provider reproduction and
exact5.2 typed-import quarantine remain unchanged. All14 stable gates stay open.

Before publishing, retain exact commit/tree, source bundle, all package hashes,
original CI ZIPs/logs, native and installed reports, failure history and reviewed
visuals where required somewhere durable beyond ephemeral RAM/CI retention.
Validate archive member hashes and independently downloaded release bytes. Never
replace tags/assets, merge main or change the draft PR's status through this recipe.
