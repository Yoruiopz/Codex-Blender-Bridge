from __future__ import annotations
import hashlib, json, os, pathlib, secrets, signal, subprocess, sys, time
base = pathlib.Path(__file__).resolve().parent
profile = base / ('display-' + secrets.token_hex(4))
profile.mkdir(mode=0o700)
auth = profile / 'Xauthority'
auth.touch(mode=0o600)
display = next(':' + str(i) for i in range(170, 300) if not pathlib.Path('/tmp/.X' + str(i) + '-lock').exists() and not pathlib.Path('/tmp/.X11-unix/X' + str(i)).exists())
subprocess.run(['xauth', '-f', str(auth), 'add', display, 'MIT-MAGIC-COOKIE-1', secrets.token_hex(16)], check=True, stdout=subprocess.DEVNULL)
config = profile / 'xorg.conf'
config.write_text('''Section "ServerFlags"
 Option "AutoAddDevices" "false"
 Option "AutoEnableDevices" "false"
 Option "AllowMouseOpenFail" "true"
 Option "DontVTSwitch" "true"
EndSection
Section "Device"
 Identifier "OwnedDummyVideo"
 Driver "dummy"
 VideoRam 256000
EndSection
Section "Monitor"
 Identifier "OwnedDummyMonitor"
 HorizSync 5.0-1000.0
 VertRefresh 5.0-200.0
 Modeline "1364x1024_60.00" 115.91 1364 1456 1600 1836 1024 1025 1028 1052 -HSync +VSync
EndSection
Section "Screen"
 Identifier "OwnedDummyScreen"
 Device "OwnedDummyVideo"
 Monitor "OwnedDummyMonitor"
 DefaultDepth 24
 SubSection "Display"
  Depth 24
  Modes "1364x1024_60.00"
 EndSubSection
EndSection
''')
runtime_dir = profile / 'runtime'
runtime_dir.mkdir(mode=0o700)
env = dict(os.environ, DISPLAY=display, XAUTHORITY=str(auth), XDG_RUNTIME_DIR=str(runtime_dir))
env.pop('WAYLAND_DISPLAY', None)
log = (profile / 'launch.log').open('wb')
server = subprocess.Popen(['/usr/lib/xorg/Xorg', display, '-config', str(config), '-auth', str(auth), '-nolisten', 'tcp', '-noreset', '-novtswitch', '-sharevts', '-logfile', str(profile/'Xorg.log')], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
try:
 ready = False
 for attempt in range(60):
  if server.poll() is not None:
   raise RuntimeError('Owned dummy Xorg failed: ' + str(profile))
  check = subprocess.run(['xdpyinfo', '-display', display], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
  if check.returncode == 0:
   ready = True
   break
  time.sleep(0.1)
 if not ready:
  raise RuntimeError('Owned dummy Xorg not ready')
 manifest_path = profile / 'private-ui-manifest.json'
 manifest = {'schema_version': 1, 'display': display, 'input_disabled': True,
             'owned_process': True, 'tcp_disabled': True, 'screen_width': 1364,
             'screen_height': 1024, 'server_pid': server.pid, 'profile': str(profile),
             'launcher_path': str(pathlib.Path(__file__).resolve()),
             'launcher_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
             'xauthority_path': str(auth), 'xdg_runtime_dir': str(runtime_dir),
             'config_sha256': hashlib.sha256(config.read_bytes()).hexdigest(),
             'input_policy': 'Dummy Xorg; AutoAddDevices=false and AutoEnableDevices=false; no physical input devices attached',
             'original_launcher_sha256': 'de40be1fea26832a2473c5b32736eaee960e504dbbcb5a267ddc010b6f696f44'}
 manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
 manifest_path.chmod(0o600)
 env['BRIDGE_TEST_PRIVATE_UI_MANIFEST'] = str(manifest_path)
 print(json.dumps({'owned_private_display_ready': True, 'profile': str(profile), 'display': display, 'input_devices_disabled': True, 'tcp_disabled': True}), flush=True)
 result = subprocess.run(sys.argv[1:], env=env, check=False)
 sys.exit(result.returncode)
finally:
 if server.poll() is None:
  os.killpg(server.pid, signal.SIGTERM)
  try:
   server.wait(timeout=10)
  except subprocess.TimeoutExpired:
   os.killpg(server.pid, signal.SIGKILL)
   server.wait(timeout=5)
 log.close()
 auth.unlink(missing_ok=True)
