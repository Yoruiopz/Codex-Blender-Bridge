"""Source-only prepared wrapper; root reviews and executes in a new attempt folder.

Usage: ROOT_PYTHON -B run_installed_addon.py CLEAN_SOURCE PINNED_PACKAGE_CONFIG
Only scripts/run_blender_checks.py launches Blender, under the reviewed display.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Expected CLEAN_SOURCE and PINNED_PACKAGE_CONFIG")
    root = Path(sys.argv[1]).resolve(strict=True)
    config = Path(sys.argv[2]).resolve(strict=True)
    base = Path(__file__).resolve().parent
    helper = base / "private_display.py"
    if any((base / name).exists() for name in ("invocation.json", "invocation-receipt.json", "runner.log", "native")):
        raise SystemExit("Attempt already exists; preserve evidence and use a new folder")
    if git(root, "status", "--porcelain"):
        raise SystemExit("Source must be clean before installed composition")
    helper_pin = "d243355385d6179d85d3fe5adecd8c2e752f470b7d6cf686b71934f31e7e5aa9"
    if sha(helper) != helper_pin:
        raise SystemExit("Reviewed private-display helper differs")
    head = git(root, "rev-parse", "HEAD")
    tree = git(root, "rev-parse", "HEAD^{tree}")
    receipt = {
        "source": str(root), "commit": head, "tree": tree,
        "helper": str(helper), "helper_sha256_before": helper_pin,
        "package_config": str(config), "package_config_sha256_before": sha(config),
        "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "scope": "Bounded Linux installed ZIP discovery/defaults/origins/reconnect and four-row same-process replacement. No installed A-F, Blender process restart, preference migration, Windows or stable acceptance.",
    }
    command = [sys.executable, str(helper), sys.executable, str(root / "scripts/run_blender_checks.py")]
    for version in ("4.5.14", "5.2.2"):
        command += ["--blender", f"/workspace/Codex-Blender-Bridge/build/blender-runtimes-20261022/extracted/blender-{version}-linux-x64/blender"]
    command += ["--case", "installed_addon_probe", "--package-probe-config", str(config), "--timeout", "180", "--output", str(base / "native")]
    receipt["command"] = command
    with (base / "invocation.json").open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(receipt, indent=2) + "\n")
    start = time.monotonic()
    with (base / "runner.log").open("xb") as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=False)
    receipt.update(
        exit_code=result.returncode, duration_seconds=time.monotonic() - start,
        helper_sha256_after=sha(helper), package_config_sha256_after=sha(config),
        end_commit=git(root, "rev-parse", "HEAD"), end_tree=git(root, "rev-parse", "HEAD^{tree}"),
        end_status=git(root, "status", "--porcelain"), runner_log_sha256=sha(base / "runner.log"),
    )
    report = base / "native/report.json"
    if report.exists():
        receipt["report_sha256"] = sha(report)
    receipt["source_helper_and_config_unchanged"] = (
        receipt["helper_sha256_before"] == receipt["helper_sha256_after"]
        and receipt["package_config_sha256_before"] == receipt["package_config_sha256_after"]
        and receipt["end_commit"] == head and receipt["end_tree"] == tree and receipt["end_status"] == ""
    )
    with (base / "invocation-receipt.json").open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("commit", "exit_code", "duration_seconds", "source_helper_and_config_unchanged")}))
    raise SystemExit(result.returncode if receipt["source_helper_and_config_unchanged"] else 1)


if __name__ == "__main__":
    main()
