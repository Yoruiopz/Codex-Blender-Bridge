from __future__ import annotations
import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path(sys.argv[1]).resolve()
base=pathlib.Path(__file__).resolve().parent
helper=base/'private_display.py'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
if status: raise SystemExit('Source must be clean before native composition')
receipt={'source':str(root),'commit':head,'helper':str(helper),'helper_sha256_before':sha(helper),'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Focused Linux development only; no installed/Windows/release acceptance'}
command=[sys.executable,str(helper),sys.executable,str(root/'scripts/run_blender_checks.py')]
for version in ('4.5.14','5.2.2'):
    command += ['--blender',f'/workspace/Codex-Blender-Bridge/build/blender-runtimes-20261022/extracted/blender-{version}-linux-x64/blender']
for case in sys.argv[2:]: command += ['--case',case]
command += ['--timeout','900','--output',str(base/'native')]
receipt['command']=command
(base/'invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (base/'runner.log').open('wb') as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
receipt.update(exit_code=result.returncode,duration_seconds=time.monotonic()-start,helper_sha256_after=sha(helper),end_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),end_status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),runner_log_sha256=sha(base/'runner.log'))
report=base/'native/report.json'
if report.exists(): receipt['report_sha256']=sha(report)
receipt['source_and_helper_unchanged']=receipt['helper_sha256_before']==receipt['helper_sha256_after'] and receipt['end_commit']==head and receipt['end_status']==''
(base/'invocation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('commit','exit_code','duration_seconds','source_and_helper_unchanged')}),flush=True)
raise SystemExit(result.returncode)
