from pathlib import Path
import hashlib,json,subprocess
base=Path('/dev/shm/blender-codex-resume-20261025');out=base/'release-0.5/root';out.mkdir(exist_ok=True);source=base/'integration-0.5';commit='4a45b99927082e1448a963140d4895c4ae82a4c7';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=source)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==commit
names=['uv-native','paint-native','checkpoint-regression-native','installed-previous03','installed-previous04'];reports=[]
for name in names:
 p=Path('/tmp')/f'blender-codex-0.5-{name}-20261025';receipt=json.loads((p/'invocation-receipt.json').read_text());r=json.loads((p/'native/report.json').read_text());assert receipt['commit']==r['commit']==commit and receipt['exit_code']==0
 assert receipt.get('source_and_helper_unchanged',receipt.get('source_helper_and_config_unchanged')) is True
 processes=[]
 for x in r['results']:
  assert x['status']=='passed'
  if 'phases' in x:
   assert x['fresh_process_verified'] and x['reader_started'] and len(x['phases'])==2
   processes.extend(x['phases'])
  else:processes.append(x)
 assert all(x['status']=='passed' and x['exit_code']==0 for x in processes)
 for n,h in r['source_files'].items():assert sha(source/n)==h,n
 reports.append({'name':name,'directory':str(p),'report_sha256':sha(p/'native/report.json'),'invocation_receipt_sha256':sha(p/'invocation-receipt.json'),'passed_case_results':len(r['results']),'passed_process_results':len(processes),'selected_cases':r['selected_cases']})
paint=[]
for p in sorted(Path('/tmp/blender-codex-0.5-paint-native-20261025/native').glob('blender-*/large_surface_paint-temp/large-surface-paint-evidence.json')):
 o=json.loads(p.read_text());assert o['completed'] and 'failure' not in o and len(o['sculpt_rows'])==7
 native=next(x['result'] for x in o['jobs'] if x['kind']=='complete_native_output');assert native['complete_pixel_count']==16777216 and native['pixels_sha256_float32_le']==o['oracles']['sha256_float32_le']['output']
 normal=next(x for x in o['jobs'] if x['kind']=='normal_wall');assert normal['result_duration_ms']<300000
 paint.append({'blender_version':o['blender_version'],'build_hash':o['build_hash'],'raw_evidence_sha256':sha(p),'normal_job_duration_ms':normal['result_duration_ms'],'peak_process_resident_bytes':max(x['peak_resident_bytes'] for x in o['memory_samples'] if x.get('supported')),'complete_pixels':native['complete_pixel_count'],'output_sha256_float32_le':native['pixels_sha256_float32_le'],'sculpt_reads':7,'interruption_endpoints':[x for x in o['jobs'] if x['kind']=='interruption_wall'],'limits':o['limits']})
ci=base/'release-0.5/ci/combined-audit.json';mcp=base/'release-0.5/installed-wheel/final-verification.json';assert json.loads(ci.read_text())['status']==json.loads(mcp.read_text())['status']=='passed'
primary=Path('/workspace/Codex-Blender-Bridge');protected={'AGENTS.md':'1390f648d92c5f0f9256bea75793c9544484b2c7b374ff93a68c522f1effce93','README.md':'9399c0f66682471b7933b8f3a5f73161b2174330a110729469c880604699f500','plugins/blender-codex-bridge/skills/blender-studio/SKILL.md':'184966e8f3059a07923b26ebaabf1f2dfa76e37613cfd50b848a7c39e1218bcf'}
for n,h in protected.items():assert sha(primary/n)==h,n
result={'status':'ROOT_ACCEPTED_BOUNDED_0_5_ALPHA_INGREDIENTS_AND_PACKAGES','source_commit':commit,'source_tree':'c7daaead4cb9332b81768535248e1c7e67037d7c','portable_passed':7939,'Windows_only_skipped':3,'ci':{'run_id':40172422470,'successful_jobs':7,'six_cells_same7939plus3':True,'receipt_sha256':sha(ci)},'fresh_installed_MCP_receipt_sha256':sha(mcp),'native_reports':reports,'paint':paint,'UV':'15 localmainthread registered-tool cases perbuild; supportedfullmap/marker/prefix recovery checks, no transport/nativeUndo/durable/visual/schemaABA/nonIDidentity qualification','installed_addon':'Bothprevious0.3mandatory and0.4additional routes: freshcurrent/previous/upgrade/rollback4rows inonefreshprocess perbuild androute; notBlenderprocessrestart/preferencemigration/fullartistA-F','primary_user_edits_sha256':protected,'all_14_release_gates':'OPEN','Windows':'Deferred/unverified','full_artist_workflow_accepted':False,'stable_1_0_release_acceptance':False,'visual_review':False,'constrained_memory_acceptance':False,'durable_recovery_accepted':False,'limits':'Generated DATA/channel-packed orthographic narrow surface profile only. Queue/start interruption endpoints retained separately; no native-call preemption guarantee. Source-level native fixtures and installedaddon discovery/defaults/origins/reconnect are separate, not installednativepainting/UV A-F proof. Framework save/protectedcapture/heldREMOVE/Timeline/exact5.2import holds preserved.'}
p=out/'alpha-acceptance.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':sha(p),'paint_measurements':[{k:x[k] for k in ('blender_version','normal_job_duration_ms','peak_process_resident_bytes')} for x in paint],'native_process_results':sum(x['passed_process_results'] for x in reports)}))
