"""Collect exact-head Actions metadata with read-only gh API requests."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = 'Yoruiopz/Codex-Blender-Bridge'


def api(endpoint: str, *extra: str):
    return json.loads(subprocess.check_output(['gh', 'api', endpoint, *extra]))


def write(name: str, value) -> None:
    destination = ROOT / name
    with destination.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--head', required=True)
    parser.add_argument('--run-id', type=int, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--final', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.head)
    assert args.run_id > 0
    assert re.fullmatch(r'[a-z0-9-]{1,48}', args.label)
    runs = api(f'repos/{REPOSITORY}/actions/runs', '--method', 'GET', '-f', 'head_sha=' + args.head, '-f', 'per_page=100')
    candidates = [run for run in runs['workflow_runs'] if run['head_sha'] == args.head and run['event'] == 'push' and run['name'] == 'CI']
    assert len(candidates) == 1, [(run['id'], run['name'], run['event']) for run in candidates]
    run = candidates[0]
    run_id = run['id']
    assert run_id == args.run_id, 'Discovered push CI run differs from root-pinned run ID'
    run = api(f'repos/{REPOSITORY}/actions/runs/{run_id}')
    jobs = api(f'repos/{REPOSITORY}/actions/runs/{run_id}/jobs', '--method', 'GET', '-f', 'per_page=100')
    artifacts = api(f'repos/{REPOSITORY}/actions/runs/{run_id}/artifacts', '--method', 'GET', '-f', 'per_page=100')
    assert run['head_sha'] == args.head and run['head_commit']['id'] == args.head
    assert all(job['head_sha'] == args.head and job['run_id'] == run_id for job in jobs['jobs'])
    assert all(item['workflow_run']['head_sha'] == args.head and item['workflow_run']['id'] == run_id for item in artifacts['artifacts'])
    suffix = '.' + args.label + '.json'
    for stem, value in [('workflow-runs-rest', runs), ('workflow-run', run), ('jobs-rest', jobs), ('artifacts-rest', artifacts)]:
        write(stem + suffix, value)
    if args.final:
        assert run['status'] == 'completed' and run['conclusion'] == 'success'
        assert len(jobs['jobs']) == jobs['total_count'] == 7
        assert len(artifacts['artifacts']) == artifacts['total_count'] == 7
        assert all(job['status'] == 'completed' and job['conclusion'] == 'success' for job in jobs['jobs'])
        for stem, value in [('workflow-run', run), ('jobs-rest', jobs), ('artifacts-rest', artifacts)]:
            write(stem + '.json', value)
    print(json.dumps({'run_id': run_id, 'head': args.head, 'status': run['status'], 'conclusion': run['conclusion'], 'jobs': len(jobs['jobs']), 'artifacts': len(artifacts['artifacts']), 'final': args.final}))


if __name__ == '__main__':
    main()
