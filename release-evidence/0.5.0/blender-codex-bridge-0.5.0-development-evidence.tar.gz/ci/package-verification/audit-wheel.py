"""Static audit of one downloaded development wheel, without importing its code."""
import sys
sys.dont_write_bytecode = True


import ast
import base64
import configparser
import csv
import hashlib
import io
import json
import re
import stat
import subprocess
import zipfile
from datetime import datetime, timezone
from email.parser import BytesParser
from pathlib import Path, PurePosixPath

import tomllib
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

OUTPUT = Path(__file__).resolve().parent
IDENTITY_PATH = OUTPUT.parent / "audit-identity.json"


def _verified_publication_identity():
    identity_bytes = IDENTITY_PATH.read_bytes()
    if len(identity_bytes) > 65536:
        raise RuntimeError("Publication identity exceeds its bounded input budget")
    identity = json.loads(identity_bytes)
    if not isinstance(identity, dict) or identity.get("status") != "ROOT_ACCEPTED_PUBLIC_HEAD":
        raise RuntimeError("A verified publication identity is required before package auditing")
    if identity.get("component_version") != "0.5.0":
        raise RuntimeError("Expected the numeric 0.5.0 prerelease candidate")
    for field, length in (("source_commit", 40), ("source_tree", 40),
                          ("source_python_sha256", 64), ("artifact_sha256", 64)):
        value = identity.get(field)
        if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{" + str(length) + r"}", value) is None:
            raise RuntimeError("Invalid verified publication identity field: " + field)
    raw_checkout = identity.get("source_repository")
    if not isinstance(raw_checkout, str):
        raise RuntimeError("An exact canonical source checkout path is required")
    checkout = Path(raw_checkout)
    accepted_checkout = Path("/dev/shm/blender-codex-resume-20261025/integration-0.5")
    if (not checkout.is_absolute() or str(checkout) != raw_checkout
            or checkout != accepted_checkout
            or checkout.resolve(strict=True) != checkout or not checkout.is_dir()):
        raise RuntimeError("Source checkout must equal the exact pinned canonical 0.5 recovery checkout")
    for field in ("source_python_files", "expected_addon_members", "expected_mcp_members", "expected_plugin_members", "expected_wheel_members"):
        if type(identity.get(field)) is not int or identity[field] <= 0:
            raise RuntimeError("Accepted exact-source count required: " + field)
    return identity, hashlib.sha256(identity_bytes).hexdigest()


IDENTITY, IDENTITY_SHA = _verified_publication_identity()
ROOT = Path(IDENTITY["source_repository"])
COMMIT = IDENTITY["source_commit"]
TREE = IDENTITY["source_tree"]
OUTER_SHA = IDENTITY["artifact_sha256"]
OUTER = OUTPUT.parent / "artifacts/development-packages.zip"
DESTINATION = Path(__file__).with_name('wheel-audit.json')
WHEEL_NAME = 'blender_codex_bridge-0.5.0-py3-none-any.whl'
DIST_INFO = 'blender_codex_bridge-0.5.0.dist-info/'
failures = []


def check(condition, message):
    if not condition:
        failures.append(message)
    return bool(condition)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git(*arguments):
    return subprocess.run(['git', '-C', str(ROOT), *arguments], check=True,
                          capture_output=True).stdout


def source(path):
    return git('show', COMMIT + ':' + path)


def normalized_requirement(text):
    requirement = Requirement(text)
    return (canonicalize_name(requirement.name), tuple(sorted(requirement.extras)),
            tuple(sorted(str(item) for item in requirement.specifier)), requirement.url,
            str(requirement.marker) if requirement.marker else None)


check(git('cat-file', '-t', COMMIT).decode().strip() == 'commit', 'Pinned commit unavailable.')
source_tree = git('rev-parse', COMMIT + '^{tree}').decode().strip()
check(source_tree == TREE, 'Pinned source tree identity differs.')
project = tomllib.loads(source('pyproject.toml').decode())['project']
outer_bytes = OUTER.read_bytes()
if sha256(outer_bytes) != OUTER_SHA:
    raise RuntimeError('Downloaded outer artifact hash differs from verified publication identity')
with zipfile.ZipFile(io.BytesIO(outer_bytes)) as outer:
    outer_crc_verified = check(outer.testzip() is None, 'Outer CI artifact CRC failure.')
    check(outer.namelist().count(WHEEL_NAME) == 1, 'Outer CI artifact must contain exactly one expected wheel.')
    wheel_bytes = outer.read(WHEEL_NAME)

with zipfile.ZipFile(io.BytesIO(wheel_bytes)) as wheel:
    members = wheel.infolist()
    names = [item.filename for item in members]
    wheel_crc_verified = check(wheel.testzip() is None, 'Wheel CRC failure.')
    layout_failure_start = len(failures)
    check(len(names) == len(set(names)), 'Duplicate wheel member.')
    check(len(names) == len({name.casefold() for name in names}), 'Case-colliding wheel member.')
    for item in members:
        path = PurePosixPath(item.filename)
        mode = stat.S_IFMT(item.external_attr >> 16)
        check(not item.is_dir() and not path.is_absolute()
              and all(part not in {'.', '..'} for part in path.parts)
              and '\\' not in item.filename and ':' not in item.filename
              and not item.flag_bits & 1 and mode in {0, stat.S_IFREG},
              'Unsafe/special wheel member: ' + item.filename)
    safe_unique_layout_verified = len(failures) == layout_failure_start

    record_name = DIST_INFO + 'RECORD'
    record_rows = list(csv.reader(io.StringIO(wheel.read(record_name).decode('utf-8'))))
    check(all(len(row) == 3 for row in record_rows), 'Malformed wheel RECORD row.')
    check(len(record_rows) == len({row[0] for row in record_rows}), 'Duplicate RECORD row.')
    check({row[0] for row in record_rows} == set(names), 'RECORD and payload member sets differ.')
    record_verified = 0
    record_self_row_unsigned = False
    for name, expected_digest, expected_size in record_rows:
        if name == record_name:
            record_self_row_unsigned = check(expected_digest == expected_size == '', 'RECORD self-row must omit digest and size.')
            continue
        body = wheel.read(name)
        encoded = base64.urlsafe_b64encode(hashlib.sha256(body).digest()).rstrip(b'=').decode()
        digest_verified = check(expected_digest == 'sha256=' + encoded, 'RECORD digest mismatch: ' + name)
        size_verified = check(expected_size == str(len(body)), 'RECORD size mismatch: ' + name)
        record_verified += int(digest_verified and size_verified)

    tracked = git('ls-tree', '-r', '--name-only', '-z', COMMIT, '--', 'mcp_server').decode().split('\0')
    tracked = [name for name in tracked if name]
    actual_code = [name for name in names if name.startswith('mcp_server/')]
    check(len(tracked) == IDENTITY['expected_mcp_members'] and len(names) == IDENTITY['expected_wheel_members'], 'Unexpected MCP/total member count.')
    code_member_set_matches = check(set(tracked) == set(actual_code), 'Git MCP source and wheel payload member sets differ.')
    code_inventory = {}
    all_code_bytes_match = True
    for name in tracked:
        body = wheel.read(name)
        expected = source(name)
        all_code_bytes_match = check(body == expected, 'Git MCP source bytes differ: ' + name) and all_code_bytes_match
        code_inventory[name] = {'bytes': len(body), 'sha256': sha256(body)}

    metadata_raw = wheel.read(DIST_INFO + 'METADATA')
    metadata = BytesParser().parsebytes(metadata_raw)
    metadata_identity = {field: metadata.get(field) for field in
                         ('Metadata-Version', 'Name', 'Version', 'Requires-Python',
                          'Summary', 'License', 'Author', 'Keywords', 'Description-Content-Type')}
    check(metadata['Metadata-Version'] in {'2.1', '2.2', '2.3', '2.4'}, 'Unsupported core metadata version.')
    check(canonicalize_name(metadata['Name']) == canonicalize_name(project['name']), 'Wheel distribution name differs.')
    check(metadata['Version'] == project['version'] == '0.5.0', 'Wheel version differs.')
    check(metadata['Requires-Python'] == project['requires-python'], 'Requires-Python differs.')
    check(metadata['Summary'] == project['description'], 'Distribution summary differs.')
    check(metadata['License'] == project['license']['text'], 'Distribution license differs.')
    check(metadata.get('Author') == ', '.join(author['name'] for author in project['authors']), 'Distribution authors differ.')
    check(metadata.get('Author-email') is None, 'Unexpected distribution author email.')
    check(metadata.get('Keywords', '').split(',') == project['keywords'], 'Distribution keywords differ.')
    check(set(metadata.get_all('Classifier', [])) == set(project['classifiers']), 'Distribution classifiers differ.')
    expected_requirements = list(project['dependencies'])
    for extra, requirements in project['optional-dependencies'].items():
        expected_requirements.extend(requirement + '; extra == "' + extra + '"' for requirement in requirements)
    actual_requirements = metadata.get_all('Requires-Dist', [])
    check(sorted(map(normalized_requirement, actual_requirements)) ==
          sorted(map(normalized_requirement, expected_requirements)), 'Distribution requirements differ.')
    check(set(metadata.get_all('Provides-Extra', [])) == set(project['optional-dependencies']), 'Distribution extras differ.')
    check(dict(line.split(', ', 1) for line in metadata.get_all('Project-URL', [])) == project['urls'], 'Project URLs differ.')
    check(metadata['Description-Content-Type'] == 'text/markdown', 'README content type differs.')
    description = metadata_raw.partition(b'\n\n')[2]
    readme = source(project['readme'])
    readme_matches = check(description in {readme, readme + b'\n'}, 'Metadata description differs from Git README.')
    readme_exact = description == readme
    license_bytes = wheel.read(DIST_INFO + 'licenses/LICENSE')
    license_matches = check(license_bytes == source('LICENSE'), 'Wheel license differs from Git source.')
    check(metadata.get_all('License-File', []) == ['LICENSE'], 'License-File differs.')

    wheel_metadata = BytesParser().parsebytes(wheel.read(DIST_INFO + 'WHEEL'))
    wheel_identity = {key: wheel_metadata.get(key) for key in ('Wheel-Version', 'Generator', 'Root-Is-Purelib', 'Tag')}
    check(wheel_identity['Wheel-Version'] == '1.0', 'Unexpected wheel metadata version.')
    check(wheel_identity['Root-Is-Purelib'] == 'true', 'Wheel is not pure Python.')
    check(wheel_metadata.get_all('Tag', []) == ['py3-none-any'], 'Wheel compatibility tag differs.')
    entries = configparser.ConfigParser()
    entries.optionxform = str
    entries.read_string(wheel.read(DIST_INFO + 'entry_points.txt').decode())
    check(entries.sections() == ['console_scripts'] and dict(entries['console_scripts']) == project['scripts'], 'Console entry point differs.')
    check(wheel.read(DIST_INFO + 'top_level.txt') == b'mcp_server\n', 'Unexpected top-level import package.')
    runtime_module = ast.parse(wheel.read('mcp_server/__init__.py'))
    runtime_versions = [ast.literal_eval(node.value) for node in runtime_module.body
                        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                        and target.id == '__version__' for target in node.targets)]
    check(runtime_versions == ['0.5.0'], 'MCP runtime version differs.')
    expected_support = {DIST_INFO + name for name in
                        ('METADATA', 'WHEEL', 'entry_points.txt', 'top_level.txt', 'RECORD', 'licenses/LICENSE')}
    check(set(names) - set(actual_code) == expected_support, 'Unexpected wheel metadata/support payload.')

report = {
    'schema_version': 1, 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'passed' if not failures else 'failed', 'failures': failures,
    'source_repository': str(ROOT), 'source_commit': COMMIT,
    'source_tree': source_tree, 'immutable_git_source_verified': True, 'working_tree_used': False,
    'publication_identity': {'path': str(IDENTITY_PATH), 'sha256': IDENTITY_SHA,
                             'status': IDENTITY['status']},
    'outer_zip': {'path': str(OUTER), 'bytes': len(outer_bytes), 'sha256': sha256(outer_bytes),
                  'crc_verified': outer_crc_verified},
    'wheel': {'name': WHEEL_NAME, 'bytes': len(wheel_bytes), 'sha256': sha256(wheel_bytes),
              'members': len(names), 'record_rows': len(record_rows),
              'record_sha256_and_size_verified': record_verified,
              'record_self_row_unsigned': record_self_row_unsigned, 'crc_verified': wheel_crc_verified,
              'safe_unique_layout_verified': safe_unique_layout_verified},
    'source_bytes': {'mcp_member_count': len(tracked), 'complete_git_member_set_matches': code_member_set_matches,
                     'all_mcp_bytes_match_exact_commit': all_code_bytes_match,
                     'license_matches_exact_commit': license_matches,
                     'readme_description_matches': readme_matches,
                     'readme_description_bytes_exact': readme_exact,
                     'readme_trailing_newline_added': description == readme + b'\n',
                     'mcp_file_inventory': code_inventory},
    'metadata': metadata_identity, 'wheel_metadata': wheel_identity,
    'requires_dist': actual_requirements, 'classifiers': metadata.get_all('Classifier', []),
    'console_scripts': dict(entries['console_scripts']),
    'static_audit_only': True, 'wheel_installed': False, 'packaged_code_executed': False,
    'new_candidate_install_and_stdio_required': True, 'old_stdio_session_reused': False,
    'native_blender_tested': False, 'windows_tested': False,
    'release_candidate_qualification': False, 'release_acceptance': False,
    'limitations': ['Artifacts have 0.5.0 alpha prerelease identity; static agreement is not runtime or 1.0 acceptance.',
                    'Package archives do not themselves embed this source commit; exact source-byte comparison ties this receipt to it.',
                    'Dependency declarations were compared, but dependency resolution and runtime behavior were not rerun.',
                    'No install, MCP stdio execution, Blender, Windows, upgrade, or rollback test was performed.'],
}
DESTINATION.parent.mkdir(parents=True, exist_ok=True)
DESTINATION.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'failures': failures,
                  'mcp_members': len(tracked), 'wheel_members': len(names),
                  'record_entries_verified': record_verified,
                  'wheel_sha256': sha256(wheel_bytes), 'receipt': str(DESTINATION)}, indent=2))
raise SystemExit(1 if failures else 0)
