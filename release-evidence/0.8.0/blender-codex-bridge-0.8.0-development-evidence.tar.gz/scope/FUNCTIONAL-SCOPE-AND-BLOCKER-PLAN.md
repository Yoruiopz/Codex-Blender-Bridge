# 0.8.0 alpha functional boundary and remaining blocker plan

This plan records the finite 0.8 alpha boundary and the full implementation still
required beyond it. It does not establish a release date or close a requirement.
The [release evidence](https://github.com/Yoruiopz/Codex-Blender-Bridge/releases/tag/v0.8.0)
must bind accepted source/packages to their actual measured outcomes and verified
limitations. Source metadata or old development ZIPs are not qualification or
publication records; exact identities and results live in that separate record.

The completion target remains the full artist-workflow 1.0 with portable `.blend`,
textured/skinned/animated GLB and FBX delivery. **All 29 implementation items and
all fourteen stable gates are OPEN.** Use official, unmodified Blender. Windows
work is deferred until implementation completion, remains unverified and remains
mandatory for the later stable candidate. Do not reduce the target to the narrow
scope of an alpha increment.

## 1. Extend and preserve the bounded native-save workflow — H01, F01, F03, F05, I02

**0.8 boundary:** typed preview/start, canonical queued admission, local expiring
native-effects consent, finite declared-data save/reopen jobs and retained file
history/effects form the supported implementation profile. A version string,
direct-entry call or substituted classifier does not qualify the installed path.
Every accepted package must carry its own actual Runtime/TCP and source-specific
native evidence. The legacy `project.save` quarantine remains in place.

**Remaining implementation:** broaden ordinary startup palette/runtime/sequencer
and production asset support through reviewed declared-data/effect profiles.
Preserve current permissions, pure pre-provider protected refusal, immutable
admission, current source/per-write checks and default-off local consent. Extend
images/project limits only after direct native/installed evidence; do not silently
raise caps, delete artist data to force admission or claim universal confinement.

**Qualification requirement for accepted builds:** all nine save scenarios on
both builds; actual installed preview/start/status and fresh-reader contents using
the same accepted ZIP; denial, expiry/revocation, cancel/disconnect, manual drift,
protected refusal, history failure and retained files. Replay affected artist,
weight/curve/UV/quaternion, geometry/image/Scene and undo/history cases. Use a
persistent owner connection and genuine local preferences/Runtime. Preserve
failed attempts, keep wheel stdio/TCP boundaries distinct and record measured
native blocking/memory. Broader production save/recovery remains an open H01/I02
completion gate even when the finite alpha profile is qualified.

## 2. Finish portable current pixels and durable original-ID recovery — A04, F03, I02

**Current boundary:** existing CURRENT_PIXELS helpers are separate packed backup
Images; they do not by themselves make the edited original portable before
restoration. Private forward/reverse work is source-specific and is not a public
0.8 capability. The interrupted 4K attempt reported a 5.2 reader resource refusal
before project open; lost RAM-only records are historical until recovered or
requalified. No lower memory threshold or inferred PASS is permitted.

**Next implementation:** retain/reconstruct the bounded native prerequisite with
real Material→Object/Mesh consumers and actual helper OWNER reference. Independently
reopen/fsync three create-only old-packed/current-EXR/manifest backups before any
helper/Image mutation. Prove the paired reverse of old packed bytes and edited
dirty pixels on the same original, not a recreated/name-resolved replacement.
Nonmodifying previews must not silently decode unloaded images. Finalize finite
graph/manifest/resource caps and per-write authority/CAS before typed lifecycle code.

**Next gate:** complete coordinate-unique Float32 witnesses, packed bytes, color/
alpha roles, bindings, protected graph and identity; immediate/three-deferred-turn
checks; fresh-reader original edited pixels before any restoration. Use unchanged
300-second phases and at least 8 GiB observed startup headroom for 4K. Add corruption,
missing/rebound helper, manual-edit, cancellation/disconnect/history-eviction and
constrained-memory failure controls through real registered and installed tools.
Buffers, helpers and undo history are not durable external backups.

**Delivery dependency:** current H01's 1M-pixel/20 MiB packed/256 MiB file profile
does not admit these 4K projects. Separately qualify safe saved helper graphs and
4K delivery; a private fixture save is not a public production-save result.

## 3. Close actual material ownership and recovery — A06, H04, F01, F03, F04

**Next implementation:** recover the reviewed retained-intent source and finish
native pointer/tree/socket ownership rather than Python wrapper identity. Keep
strict existing profiles distinct from any explicitly named declared-RNA extension
for inactive Object physics. Qualify all exposed values/references and callback
closure before reads; disclose hidden/unobserved limits without pretending full
Main preservation or requiring a custom Blender API.

**Next gate:** first three genuine copy/bind/group-copy successes, then the complete
seventeen-case failure/shared-consumer/recovery matrix on both builds. Inject an
actually applied write failure, lost authority and foreign edits; measure only
earned recovery and retain unknown/orphan effects. Extend to textured, nested and
animated consumers. Shader removal/conversion remains a separate held migration.

## 4. Complete structured import and production delivery — H03, I02, F01, F04

**Next implementation:** review the finite new-ID GLB preview/execute/inspect
proposal against the final Runtime. Keep separate stage ownership, pure early
protection refusal, fresh request/session/deadline authority, a sealed partial-stage
lookup before allocation and main-thread disconnect handling. Preserve the existing
import quarantine and avoid destructive discard. Do not claim 4.5 support from a
private 5.2 constructor result; a second Scene also exceeds current H01's profile.

**Next gate:** real queued and installed success/denial/source-session drift,
unknown callbacks, partial allocation and retained failure/recovery. Then complete
both required Blender-version routes, textured/skinned/animated GLB and FBX,
units/transforms, dependencies, approved paths, explicit overwrite and pre-delivery
conversion-loss disclosure, with fresh-process reimport and portable `.blend`.

## 5. Prove procedural/cache operations — P01, P02, F05

**Next implementation:** finish the finite source-backed runtime-absence and
declared Scene-consumer reader needed by the cloth fixture, with explicit authorized
pre-intent Workspace preparation. Preserve home UI/authored data, never learn an
expected consumer count from the observation, and never switch Area types.

**Next gate:** actual bounded cloth bake→invalidate→free→rebake and complete
multi-frame geometry versus fresh reference, with interruption/revocation/manual
editing and measured recovery. Keep cache effects and nonpreemptible native blocking
visible. Apply equivalent lifecycle/ownership/jobs to rigid/fluid and nested GN
zones/modifiers/bake/free. Rigid evaluation and metadata catalogs are not baking.

## 6. Complete cross-domain safety and artist workflows — F01–F07, H02/H05, A01–A07, C01–C03, P03

**Next implementation:** finish the per-mutator permissions/context/ownership/
transitive-consumer/recovery matrix. Complete required modeling/retopology, UV
selection/quality/atlases, perspective strokes/stencils, sculpt/vertex/weight paint,
rig/IK/weights/deformation, curve handles/time/interpolation/drivers/Action/NLA,
camera/lighting/compositor and matched visual/cinematic iteration. Broaden each
supported authored-state profile through direct evidence, not arbitrary Python.

**Next gate:** reference-constrained asset creation/repair/texturing/revision,
sampled character motion/deformation correction/protected animation, and three
meaningful cinematic variants around an animated protected character. Include
permission denial, invalid context, partial failure, mixed manual undo/bridge
editing, memory pressure and measured recovery. Retain complete structural data
and reviewed matched visuals for appearance-sensitive outcomes. Geometry-only
neutral preview evidence does not qualify materials or current viewport appearance.

Integrate the external agent's inspect→plan→checkpoint→edit→verify→refine→authorized
save loop with references, persistent protection, progress/cancel/history and
corrections, without operator-by-operator instructions. Protected capture remains
held until a supported stock-Blender alternative passes its own declared contract.

## 7. Qualify final installed scenarios and stable release — I01–I04, F06, RC-01

After functional requirements pass, execute complete A–F scenarios on matching
installed packages, including all native/interactive fixtures, 4K, constrained
memory, manual editing, upgrade from 0.3, rollback, restart/reconnect and paths with
spaces. Record exact commit/source/package hashes, hardware, peak memory, native
blocking, deadlines, cancellation, logs and reviewed visuals. Retain durable evidence
beyond CI expiry; snapshot current WIP sources before an execution-environment reset.

Resume Windows-specific work only after implementation completion. At candidate
freeze select exact Windows 11 x64/Blender 4.5 LTS and newest compatible stable 5.x
patches and run the full private-desktop/installed A–F matrix. Align support
documentation with the measured result. No missing mandatory evidence may be
replaced by a tool count, historical report or release cadence. Do not label an
incomplete milestone stable 1.0.

Meaningful prereleases may follow fully qualified increments. Publication must
use accepted bytes, the reviewed fixed publisher, sanitized evidence and verified
anonymous downloads. Preserve main, draft PR #8, primary user edits, public
visibility and previous releases; no unrelated merge or permission change follows.
