"""Explicit allowlist of public-source and synthetic 0.8 qualification evidence."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

B = Path('/dev/shm/bcb-resume-20261026')
D = Path('/workspace/Codex-Blender-Bridge/build/resume-20261026')
O = B / 'publication-0.8'
payload, provenance = {}, {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def add_bytes(raw, name, origin):
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts and name not in payload
    large_paint_log = name in {
        'native/source/native/blender-0/paint_jobs.log',
        'native/source/native/blender-1/paint_jobs.log',
    }
    assert 0 <= len(raw) <= (40 if large_paint_log else 16) * 1024**2
    assert relative.suffix.lower() not in {'.blend', '.blend1', '.exr', '.bcbimg', '.bin'}
    assert relative.name != 'Xauthority'
    payload[name] = raw
    provenance[name] = {'source': origin, 'bytes': len(raw), 'sha256': sha(raw)}


def add(path, name):
    path = Path(path)
    assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
    add_bytes(path.read_bytes(), name, str(path))


def tree(root, prefix, suffixes, exclude=()):
    root = Path(root)
    assert root.is_dir()
    for path in sorted(root.rglob('*')):
        if (path.is_file() and path.suffix in suffixes and not path.is_symlink()
                and not any(part in exclude for part in path.parts)):
            add(path, prefix + '/' + path.relative_to(root).as_posix())


wheel = B / 'installed08-wheel-harness-02'
final = json.loads((wheel / 'final-verification.json').read_bytes())
assert final['status'] == 'passed' and final['source_commit'] == 'adfd0468946c7a4147b662715fb520be0afa7ae6'
assert final['malformed_standard_json_receipts'] == 277 and final['unexpected_forwarded_connections'] == 0
notes = (O / 'qualified/RELEASE-NOTES.md').read_text()
assert 'This draft must not be' not in notes

# This CI archive was independently audited as 24 explicit regular members.
# Other private checkpoint archives are deliberately not read or uploaded.
ci_path = D / 'ci-candidate08-20261026-evidence.tar.gz'
assert sha(ci_path.read_bytes()) == '54bee7fe38b441ef2100962bb1314e7140ac48aae073cc027df64b4d6ef7ea8a'
with tarfile.open(ci_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == 24 and len({m.name for m in members}) == 24 and all(m.isfile() for m in members)
    for member in members:
        assert not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
        add_bytes(archive.extractfile(member).read(), 'ci/' + member.name, 'Reviewed CI archive: ' + member.name)

for label, folder in [
    ('candidate', 'release-0.8-candidate-root-validation-01'),
    ('native-save-support', 'installed-native-save-08-root-validation-01'),
    ('upgrade-support', 'installed08-upgrade-root-validation-01'),
]:
    tree(B / folder, 'portable/' + label, {'.json', '.xml', '.log'})

for label, name in [
    ('source', 'bcb-release08-core-01'),
    ('installed-queued', 'bcb-installed-native-save-08-01'),
    ('upgrade-from-03', 'bcb-installed08-upgrade03-01'),
    ('upgrade-from-07', 'bcb-installed08-upgrade07-01'),
]:
    root = Path('/tmp') / name
    receipt = json.loads((root / 'invocation-receipt.json').read_bytes())
    assert receipt['exit_code'] == 0 and receipt['source_and_helper_unchanged'] is True
    for path in root.glob('*.json'):
        add(path, 'native/' + label + '/' + path.name)
    add(root / 'runner.log', 'native/' + label + '/runner.log')
    add(root / 'private_display.py', 'native/' + label + '/private_display.py')
    tree(root / 'native', 'native/' + label + '/native', {'.json', '.log', '.png'}, (
        'installed scripts with spaces', 'config', 'scripts', 'datafiles', 'home', 'working'))

for pattern in ('*.json', '*.jsonl', '*.py', '*.log'):
    for path in wheel.glob(pattern):
        add(path, 'installed-wheel/' + path.name)

# Keep the earlier harness failure as historical failure, without reusing its session.
for name in ('execution-receipt.json', 'observed-tools.json', 'forwarding-sentinel.json', 'step-3.log'):
    add(B / 'installed08-wheel-harness' / name, 'prior-wheel-harness-failure/' + name)

for label, folder in [
    ('core', 'release08-core-independent-review'),
    ('installed-queued', 'installed08-independent-review'),
    ('upgrade', 'upgrade08-independent-review'),
    ('wheel-source', 'installed08-wheel-harness-analysis/independent-review'),
    ('wheel-source-correction', 'installed08-wheel-harness-02-analysis/independent-review'),
    ('upgrade-source', 'installed08-upgrade-analysis/independent-review'),
]:
    tree(B / folder, 'reviews/' + label, {'.json'})

dynamic_review = B / 'wheel08-independent-review/review.json'
assert json.loads(dynamic_review.read_bytes())['status'].startswith('PASS')
tree(dynamic_review.parent, 'reviews/installed-wheel', {'.json'})

source_bundle = D / 'release08-public-source-with-upgrade-support.bundle'
assert sha(source_bundle.read_bytes()) == '30dd9e4e2e14e9e5e43547398cba57e08e313bd4dbb8657710f7715a1559a3d1'
add(source_bundle, 'source/public-candidate-and-qualified-support.bundle')
add(D / 'release08-public-source-with-upgrade-support.json', 'source/public-source-identities.json')
add(D / 'release08-hardware-facts.json', 'measurements/environment.json')
for name in ('RELEASE-NOTES.md', 'FUNCTIONAL-SCOPE-AND-BLOCKER-PLAN.md'):
    add(O / 'qualified' / name, 'scope/' + name)
add(Path(__file__), 'curation/build_public_evidence.py')

issues = []
for name, raw in payload.items():
    if name.endswith(('.json', '.jsonl', '.log', '.md', '.py', '.txt', '.xml')):
        value = raw.decode('utf-8-sig')
        for pattern in (r'https://[^\s"<>]*(?:sig=|[?&]se=)',
                        r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
                        r'gh[pousr]_[A-Za-z0-9]{30,}'):
            if re.search(pattern, value):
                issues.append({'member': name, 'pattern': pattern})
assert not issues, issues
assert sum(map(len, payload.values())) <= 192 * 1024**2
manifest = {
    'schema_version': 1, 'source_commit': 'adfd0468946c7a4147b662715fb520be0afa7ae6',
    'source_tree': '9c24b416ede7b80268496fcd47cfd33ab562c72e', 'CI_run': 40310834054,
    'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(payload.items())},
    'scope': 'Reviewed public source, exact CI packages, synthetic native/installed reports and reviewed previews, fresh wheel evidence and retained failed harness diagnostics. No user projects/preferences, recovery backups, private WIP branches, Xauthority cookies or signed download references. Windows deferred; all29implementation/14stable gates remain open.',
    'public_source_only_bundle': True,
}
payload['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
payload['PAYLOAD-SHA256SUMS.txt'] = ''.join(sha(raw) + '  ' + name + '\n' for name, raw in sorted(payload.items())).encode()
destination = O / 'blender-codex-bridge-0.8.0-development-evidence.tar.gz'
with destination.open('xb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', compresslevel=9, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, raw in sorted(payload.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
with tarfile.open(destination, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(payload) and all(member.isfile() for member in members)
    for member in members:
        assert archive.extractfile(member).read() == payload[member.name]
digest = sha(destination.read_bytes())
(O / 'EVIDENCE-SHA256SUMS.txt').write_text(digest + '  ' + destination.name + '\n')
record = {'status': 'ROOT_CURATED_HASH_VERIFIED_INDEPENDENT_PUBLIC_PAYLOAD_REVIEW_PENDING',
          'archive': str(destination), 'bytes': destination.stat().st_size, 'sha256': digest,
          'regular_members': len(payload), 'all_members_readback_exact': True,
          'excluded_private_archives_and_projects': True, 'files': provenance}
(O / 'archive-verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('status', 'archive', 'bytes', 'sha256', 'regular_members')}), flush=True)
