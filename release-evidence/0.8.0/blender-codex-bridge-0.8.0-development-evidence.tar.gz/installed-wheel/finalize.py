"""Independently bind NEW 0.8.0 package bytes, session receipts and preservation."""
# ruff: noqa: E402 -- disable bytecode before loading even standard-library helpers.
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import base64
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
from zipfile import ZipFile

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("new_prerelease_prepare", OUT / "prepare.py")
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    args = parser.parse_args()
    helpers.require(sys.flags.isolated and sys.flags.dont_write_bytecode, "Use root Python -I -B")
    value, _accepted, manifest = helpers.load_prepared(args.authority)
    execution = json.loads((OUT / "execution-receipt.json").read_bytes())
    evidence = json.loads((OUT / "installed-wheel-evidence.json").read_bytes())
    require = helpers.require
    require(execution["status"] == "passed" and execution["phase"] == "completed" and execution["old_inputs_preserved"] is True, "Execution did not pass")
    require(execution["source_commit"] == evidence["commit"] == manifest["commit"] == value["source_commit"], "Commit identity differs")
    require(execution["source_tree"] == evidence["source_tree"] == manifest["source_tree"] == value["source_tree"], "Tree identity differs")
    require(execution["authority_sha256"] == manifest["authority_sha256"] and execution["distribution_manifest_sha256"] == evidence["distribution_manifest_sha256"] == helpers.digest(OUT / "distribution-manifest.json"), "Manifest/authority identity differs")
    require(execution["accepted_ci_audit_sha256"] == value["accepted_ci_audit"]["sha256"], "Accepted CI binding differs")
    require(evidence["installed_version"] == "0.8.0" and evidence["mcp_sdk"] == "2.2.0" and evidence["stdio_verified"] is True and evidence["checkout_imports_used"] is False, "Fresh session identity differs")
    require(evidence["installed_module"] == str(helpers.SITE / "mcp_server/__init__.py") and evidence["python_executable"] == str(helpers.NEW / "bin/python") and evidence["isolated_python"] is True and evidence["cwd"] == "/tmp", "Fresh interpreter/module origin differs")
    require(evidence["installed_source_files"] == manifest["expected_module_sha256"] and evidence["installed_source_matches_wheel"] is True, "Installed MCP source identity differs")
    require(evidence["default_enabled"] == ["core"] and evidence["tools_discovered"] == 270
            and evidence["disabled_domain_check_count"] == 25
            and evidence["legacy_json_invalid_input_count"] == 210
            and evidence["native_save_invalid_input_count"] == 67
            and evidence["all_json_invalid_input_count"] == 277, "Expected session coverage differs")
    require(evidence["artist_target_verify_valid_call_performed"] is False and evidence["quaternion_valid_core_RPC_performed"] is False and evidence["native_blender_or_windows_acceptance"] is False, "Held/native scope changed")
    require(evidence["native_save_valid_RPC_performed"] is False
            and set(evidence["native_save_schemas"]) == {"project.native_save_preview", "project.native_save_start"},
            "Native-save registration or held valid-RPC scope differs")
    for method, row in evidence["native_save_schemas"].items():
        require(row["toolset"] == "core" and row["modifying"] is True
                and row["read_only_hint"] is False
                and row["destructive_hint"] is (method == "project.native_save_start")
                and row["open_world_hint"] is False
                and row["required_permissions"] == ["INSPECT_SCENE", "SAVE_PROJECT", "ACCESS_EXTERNAL_FILES", "NATIVE_SAVE_EFFECTS"],
                "Native-save installed metadata differs")
    sentinel = json.loads((OUT / "forwarding-sentinel.json").read_bytes())
    require(sentinel["host"] == "127.0.0.1" and type(sentinel["port"]) is int
            and 1 <= sentinel["port"] <= 65535 and sentinel["accepted_connections"] == 0
            and sentinel["network_thread_joined"] is True and sentinel["listener_closed"] is True
            and sentinel["failure"] is None and sentinel["primary_exception_type"] is None
            and sentinel["provided_Blender_protocol_responses"] is False
            and evidence["forwarding_sentinel_connections_at_session_end"] == 0,
            "Owned forwarding-sentinel proof differs")
    require(len(execution["steps"]) == 4, "Incomplete step sequence")
    for index, row in enumerate(execution["steps"]):
        require(row["step"] == index and row["spawned"] is True and row["exit_code"] == 0 and row["timed_out"] is False and row["cwd"] == "/tmp", "Failed execution step")
        require(helpers.digest(OUT / ("step-" + str(index) + ".log")) == row["log_sha256"], "Execution log changed")
        command = row["command"]
        if index in (0, 3):
            require(command[:3] == [str(helpers.NEW / "bin/python"), "-I", "-B"], "Fresh interpreter flags differ")
        else:
            require(command[:5] == [str(helpers.ROOT_PYTHON), "-I", "-B", "-m", "pip"] and "--python" in command and command[command.index("--python") + 1] == str(helpers.NEW / "bin/python"), "Root pip destination differs")
        if index == 1:
            require(all(flag in command for flag in ("--no-index", "--no-deps", "--no-cache-dir", "--no-compile")) and not any(flag in command for flag in ("--upgrade", "--force-reinstall")), "Installation bounds differ")

    modules = {}
    actual = {p.relative_to(helpers.SITE).as_posix() for p in (helpers.SITE / "mcp_server").rglob("*") if p.is_file()}
    require(actual == set(manifest["expected_module_sha256"]), "Installed MCP has missing/extra/cache files")
    for name in actual:
        path = helpers.regular(helpers.SITE / name)
        modules[name] = helpers.digest(path)
    require(modules == manifest["expected_module_sha256"], "Installed MCP bytes changed")
    wheel_path = OUT / "packages" / helpers.WHEEL_NAME
    require(helpers.digest(wheel_path) == value["wheel"]["sha256"] == evidence["wheel_sha256"], "Wheel binding differs")
    with ZipFile(wheel_path) as wheel:
        members = set(wheel.namelist())
        for name in members - {helpers.DIST + "RECORD"}:
            require(helpers.regular(helpers.SITE / name).read_bytes() == wheel.read(name), "Installed wheel member differs: " + name)
    record = helpers.regular(helpers.SITE / (helpers.DIST + "RECORD"))
    rows = list(csv.reader(io.StringIO(record.read_text())))
    expected_rows = members | {helpers.DIST + name for name in ("INSTALLER", "REQUESTED", "direct_url.json")} | {"../../../bin/blender-codex-mcp"}
    require(len(rows) == len({row[0] for row in rows}) and {row[0] for row in rows} == expected_rows, "Installed RECORD member set differs")
    for name, signed, length in rows:
        path = (helpers.SITE / name).resolve(strict=True)
        require(path.is_relative_to(helpers.NEW), "Installed RECORD escaped new venv")
        body = helpers.regular(path).read_bytes()
        if name == helpers.DIST + "RECORD":
            require(signed == length == "", "Installed RECORD self-hash differs")
        else:
            require(signed == "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(body).digest()).rstrip(b"=").decode() and length == str(len(body)), "Installed RECORD digest differs")
    require((helpers.SITE / (helpers.DIST + "INSTALLER")).read_bytes() == b"pip\n" and (helpers.SITE / (helpers.DIST + "REQUESTED")).read_bytes() == b"", "Installation metadata differs")
    direct = json.loads((helpers.SITE / (helpers.DIST + "direct_url.json")).read_bytes())
    require(direct["url"] == wheel_path.as_uri() and direct["archive_info"]["hashes"] == {"sha256": value["wheel"]["sha256"]}, "Installed direct URL differs")
    entry = helpers.regular(helpers.NEW / "bin/blender-codex-mcp").read_bytes()
    require(entry.startswith(("#!" + str(helpers.NEW / "bin/python") + "\n").encode()) and b"from mcp_server.server import main" in entry, "New console entrypoint differs")

    listing = json.loads((OUT / "observed-tools.json").read_bytes())
    expected_tools = json.loads((OUT / "expected-tools.json").read_bytes())
    require(sorted(row["name"] for row in listing) == expected_tools and len(listing) == 270, "Observed actual tools/list differs")
    rpc = [json.loads(line) for line in (OUT / "rpc-receipts.jsonl").read_text().splitlines()]
    require(len(rpc) == 307 and [row["index"] for row in rpc] == list(range(1, 308)), "Actual RPC receipt sequence differs")
    malformed = [row for row in rpc if row["is_error"] is True and any("validation error" in text.lower() for text in row["texts"])]
    disabled = [row for row in rpc if row["is_error"] is True and any("TOOLSET_DISABLED" in text for text in row["texts"])]
    require(len(malformed) == 277 and len(disabled) == 28 and len({row["tool"] for row in disabled}) == 25, "Actual retained SDK error coverage differs")
    native_calls = [row for row in rpc if row["tool"] in {"project.native_save_preview", "project.native_save_start"}]
    native_proofs = evidence["native_save_invalid_input_checks"]
    require(len(native_calls) == len(native_proofs) == 67
            and all(row["is_error"] is True and any("validation error" in text.lower() for text in row["texts"])
                    for row in native_calls)
            and all(row["standard_JSON"] is True and row["validation_before_core_forwarding"] is True
                    and row["accepted_connections"] == 0 for row in native_proofs),
            "Native-save strict standard-JSON rejection receipts differ")
    require(all(row["tool"] == "toolsets.list" and row["structured_content"]["enabled"] == ["core"] and row["is_error"] is False for row in (rpc[0], rpc[-1])), "Actual enabled-default observations differ")
    groups = {"rigid_evaluation_invalid_input_checks": 18, "animation_curve_invalid_input_checks": 23, "camera_focus_invalid_input_checks": 6, "animation_curve_sampling_invalid_input_checks": 29, "sculpt_mask_sample_invalid_input_checks": 50, "artist_target_verify_invalid_input_checks": 37, "quaternion_invalid_input_checks": 32, "geometry_preview_invalid_input_checks": 15}
    require(all(len(evidence[name]) == count for name, count in groups.items()), "Malformed group counts differ")
    helpers.preserve(manifest)
    helpers.write_once("final-verification.json", {"status": "passed", "source_commit": value["source_commit"], "source_tree": value["source_tree"], "authority_sha256": manifest["authority_sha256"], "accepted_ci_audit_sha256": value["accepted_ci_audit"]["sha256"], "wheel_sha256": value["wheel"]["sha256"], "execution_receipt_sha256": helpers.digest(OUT / "execution-receipt.json"), "installed_evidence_sha256": helpers.digest(OUT / "installed-wheel-evidence.json"), "actual_tools_listing_sha256": helpers.digest(OUT / "observed-tools.json"), "actual_rpc_receipts_sha256": helpers.digest(OUT / "rpc-receipts.jsonl"), "fresh_new_venv_install": True, "actual_fresh_stdio": True, "tools": 270, "disabled_domains": 25, "legacy_malformed_standard_json_receipts": 210, "native_save_malformed_standard_json_receipts": 67, "malformed_standard_json_receipts": 277, "native_save_valid_RPC_performed": False, "forwarding_sentinel_sha256": helpers.digest(OUT / "forwarding-sentinel.json"), "unexpected_forwarded_connections": 0, "all_current_MCP_bytes_equal_wheel_and_Git": True, "all_installed_RECORD_rows_verified": True, "old_environment_and_historical_evidence_preserved": True, "old_session_reused": False, "native_Blender_or_Windows_tested": False, "all_14_release_gates_remain_open": True, "release_acceptance": False, "scope": "Exact 0.8.0 Linux wheel install, current MCP origins, registration/schema/defaults/validation and preserved third-party reuse. Both native-save schemas and67 strict malformed standard-JSON calls are checked before forwarding to an owned rejection counter that returns no protocol responses. No installed addon, MCP-to-Blender artist scenarios, Windows or stable1.0 qualification. SDK responses are retained, not raw wire frames."})


if __name__ == "__main__":
    main()
