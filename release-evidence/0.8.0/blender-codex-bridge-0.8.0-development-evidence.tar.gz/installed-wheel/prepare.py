"""Root-reviewed, opt-in preparation for one fresh Linux 0.8.0 wheel session."""
# ruff: noqa: E402 -- disable bytecode before loading even standard-library helpers.
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import ast
import base64
import csv
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import tarfile
from email.parser import BytesParser
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

OUT = Path(__file__).resolve().parent
BUILD = Path("/workspace/Codex-Blender-Bridge/build")
OLD = BUILD / "artist-installed-wheel-20261023/venv"
HISTORY = BUILD / "artist-quaternion-installed-wheel-20261023"
OLD_SITE = OLD / "lib/python3.12/site-packages"
NEW = OUT / "venv"
SITE = NEW / "lib/python3.12/site-packages"
BASE_PYTHON = Path("/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12")
ROOT_PYTHON = Path("/workspace/Codex-Blender-Bridge/.venv/bin/python")
WHEEL_NAME = "blender_codex_bridge-0.8.0-py3-none-any.whl"
DIST = "blender_codex_bridge-0.8.0.dist-info/"
HARNESS = ("prepare.py", "run-installed.py", "installed_stdio.py", "finalize.py")
SOURCE_COMMIT = "adfd0468946c7a4147b662715fb520be0afa7ae6"
SOURCE_TREE = "9c24b416ede7b80268496fcd47cfd33ab562c72e"
CI_RUN = 40310834054
WHEEL_SHA256 = "837ffc2be4ce7e2368fe2672438b35d9f1a11d4e60cf7fa362e279d2b1e134b2"
DEPENDENCIES = frozenset(["_cffi_backend.cpython-312-x86_64-linux-gnu.so", "annotated_types", "annotated_types-0.8.0.dist-info", "anyio", "anyio-4.15.1.dist-info", "attr", "attrs", "attrs-26.1.0.dist-info", "cffi", "cffi-2.1.1.dist-info", "click", "click-8.5.0.dist-info", "cryptography", "cryptography-50.0.2.dist-info", "h11", "h11-0.16.0.dist-info", "httpcore2", "httpcore2-2.16.0.dist-info", "httpx2", "httpx2-2.16.0.dist-info", "idna", "idna-3.20.dist-info", "jsonschema", "jsonschema-4.26.0.dist-info", "jsonschema_specifications", "jsonschema_specifications-2025.9.1.dist-info", "jwt", "mcp", "mcp-2.2.0.dist-info", "mcp_types", "mcp_types-2.2.0.dist-info", "multipart", "opentelemetry", "opentelemetry_api-1.45.1.dist-info", "pycparser", "pycparser-3.12.dist-info", "pydantic", "pydantic-2.14.1.dist-info", "pydantic_core", "pydantic_core-2.50.1.dist-info", "pyjwt-2.15.1.dist-info", "python_multipart", "python_multipart-0.0.32.dist-info", "referencing", "referencing-0.37.0.dist-info", "rpds", "rpds_py-2026.9.1.dist-info", "sse_starlette", "sse_starlette-3.5.0.dist-info", "starlette", "starlette-1.9.0.dist-info", "truststore", "truststore-0.10.5.dist-info", "typing_extensions-4.16.0.dist-info", "typing_extensions.py", "typing_inspection", "typing_inspection-0.4.4.dist-info", "uvicorn", "uvicorn-0.54.0.dist-info"])


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_once(name, value):
    with (OUT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def regular(path):
    path = Path(path)
    require(path.is_absolute() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode), "Expected regular absolute file: " + str(path))
    require(path.resolve(strict=True) == path, "Noncanonical file: " + str(path))
    return path


def git(repository, *arguments):
    return subprocess.check_output(["git", "-C", str(repository), *arguments])


def authority(path):
    path = regular(path)
    data = path.read_bytes()
    value = json.loads(data)
    require(value["status"] == "ROOT_AUTHORIZED_INSTALLED_0_8" and value["component_version"] == "0.8.0", "Root authority is not armed for 0.8.0")
    require(value["expected_tools"] == 270 and type(value["expected_tools"]) is int and value["mcp_sdk"] == "2.2.0", "Unexpected session contract")
    for key in ("source_commit", "source_tree"):
        require(type(value[key]) is str and re.fullmatch(r"[a-f0-9]{40}", value[key]), "Missing exact " + key)
    require(value["source_commit"] == SOURCE_COMMIT and value["source_tree"] == SOURCE_TREE,
            "This reviewed harness accepts only the exact 0.8.0 candidate")
    repository = Path(value["source_repository"])
    require(repository.is_absolute() and repository.resolve(strict=True) == repository and repository.is_dir(), "Source repository must be canonical")
    require(git(repository, "rev-parse", value["source_commit"] + "^{tree}").decode().strip() == value["source_tree"], "Git tree mismatch")
    require(git(repository, "rev-parse", "HEAD").decode().strip() == SOURCE_COMMIT
            and git(repository, "status", "--porcelain") == b"", "Candidate checkout is not the exact clean source")
    require(set(value["harness_sha256"]) == set(HARNESS), "All four reviewed harness hashes are required")
    for name in HARNESS:
        require(digest(regular(OUT / name)) == value["harness_sha256"][name], "Harness differs from root authority: " + name)
    for name in ("accepted_ci_audit", "wheel"):
        row = value[name]
        require(type(row["sha256"]) is str and re.fullmatch(r"[a-f0-9]{64}", row["sha256"]), "Missing root hash: " + name)
        require(digest(regular(row["path"])) == row["sha256"], "Root pin mismatch: " + name)
    accepted = json.loads(Path(value["accepted_ci_audit"]["path"]).read_bytes())
    require(accepted["status"] == "PASS_EXACT_CI_AND_PACKAGE_SOURCE_AUDIT"
            and accepted["commit"] == SOURCE_COMMIT and accepted["tree"] == SOURCE_TREE,
            "Current accepted CI receipt identity/schema differs; legacy receipt conversion is forbidden")
    require(type(accepted["run_id"]) is int and accepted["run_id"] == CI_RUN
            and type(accepted["ci_jobs_success"]) is int and accepted["ci_jobs_success"] == 7,
            "Exact candidate CI run or seven-job success differs")
    for flag in ("all_api_sizes_digests_and_zip_crcs_verified", "all_six_test_identity_sets_equal",
                 "all_required_ci_steps_success", "ci_artifact_run_heads_exact",
                 "clean_source_unchanged_after_audit", "wheel_RECORD_complete_hashes_sizes"):
        require(accepted[flag] is True, "Accepted candidate audit is incomplete: " + flag)
    cells = accepted["six_matrix_cells"]
    require(type(cells) is list and len(cells) == 6, "Six accepted matrix cells are required")
    require({(row["python"], row["mcp_sdk"]) for row in cells} == {
        (python, sdk) for python in ("3.10", "3.11", "3.12") for sdk in ("2.0.0", "2.2.0")},
        "Accepted Python/MCP matrix differs")
    for row in cells:
        require(all(type(row[key]) is int and row[key] == expected for key, expected in
                    (("tests_total", 9690), ("passed", 9687), ("skipped", 3), ("failures", 0), ("errors", 0))),
                "Accepted matrix counts differ")
    require(all(type(row["test_identity_sha256"]) is str
                and re.fullmatch(r"[a-f0-9]{64}", row["test_identity_sha256"]) for row in cells)
            and len({row["test_identity_sha256"] for row in cells}) == 1, "Accepted test identities differ")
    require(accepted["component_versions"] == {"pyproject": "0.8.0", "addon_manifest": "0.8.0",
        "addon_constants": [0, 8, 0], "addon_bl_info": [0, 8, 0], "mcp_runtime": "0.8.0", "plugin": "0.8.0"},
        "Accepted component versions differ")
    assets = accepted["package_assets"]
    require(type(assets) is list and len(assets) == 4 and len({row["name"] for row in assets}) == 4,
            "Accepted package list differs")
    require({row["name"] for row in assets} == {WHEEL_NAME, "SHA256SUMS.txt",
        "blender_codex_bridge-0.8.0.zip", "blender-codex-bridge-plugin-0.8.0.zip"}, "Accepted asset names differ")
    asset, = [row for row in assets if row["name"] == WHEEL_NAME]
    require(asset["sha256"] == value["wheel"]["sha256"] == WHEEL_SHA256, "Accepted exact wheel pin differs")
    require(asset["path"] == value["wheel"]["path"] and asset["sha256"] == value["wheel"]["sha256"] and asset["bytes"] == Path(asset["path"]).stat().st_size, "Wheel does not match accepted CI asset")
    require(type(value["minimum_free_bytes"]) is int and value["minimum_free_bytes"] >= 8 * 1024 * 1024, "An explicit capacity floor of at least 8MiB is required")
    return value, accepted, sha(data)


def file_state(path):
    info = path.lstat()
    row = {"mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid, "gid": info.st_gid, "mtime_ns": info.st_mtime_ns}
    if stat.S_ISLNK(info.st_mode):
        row.update(kind="symlink", target=os.readlink(path))
    elif stat.S_ISDIR(info.st_mode):
        row["kind"] = "directory"
    else:
        require(stat.S_ISREG(info.st_mode), "Unexpected preserved file type: " + str(path))
        row.update(kind="file", bytes=info.st_size, sha256=digest(path))
    after = path.lstat()
    require((info.st_mode, info.st_uid, info.st_gid, info.st_mtime_ns, info.st_size) == (after.st_mode, after.st_uid, after.st_gid, after.st_mtime_ns, after.st_size), "Input changed during snapshot")
    return row


def preservation_snapshot():
    require(digest(HISTORY / "manifest.json") == "95717935b8bcb49485a87872f016671843ca7723e3e5ec4386460632df5bc054", "Historical c49 manifest changed")
    require(digest(HISTORY / "environment-proof.json") == "637d0f6a70d3b97a18a1c7661d4d614b25b19d3ab5f3a407f0bde1cb89a362aa", "Historical snapshot ledger changed")
    proof = json.loads((HISTORY / "environment-proof.json").read_bytes())
    frozen = json.loads((HISTORY / "manifest.json").read_bytes())
    for name, expected in frozen["files_excluding_manifest"].items():
        path = regular(HISTORY / name)
        require(path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], "Historical c49 evidence changed: " + name)
    snapshots = proof["retained_snapshots"]
    require(len(snapshots) == 15 and sum(len(row["files"]) for row in snapshots) == 756, "Historical inventory differs")
    selected = set()
    for snapshot in snapshots:
        folder = Path(snapshot["root"])
        archive = regular(snapshot["archive"])
        require(folder.parent == BUILD and archive.parent == BUILD and digest(archive) == snapshot["archive_sha256"], "Historical archive identity changed")
        selected.add(archive)
        with tarfile.open(archive, "r:gz") as retained:
            for name, expected in snapshot["files"].items():
                path = regular(folder / name)
                require(path.resolve().is_relative_to(folder) and path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], "Historical snapshot changed")
                member = retained.getmember(snapshot["archive_prefix"] + "/" + name)
                require(member.isfile() and sha(retained.extractfile(member).read()) == expected["sha256"], "Historical archive member changed")
                selected.add(path)
    for root in (OLD, HISTORY):
        require(root.is_dir() and not root.is_symlink(), "Missing preserved root")
        selected.add(root)
        for folder, directories, files in os.walk(root, followlinks=False):
            selected.add(Path(folder))
            selected.update(Path(folder) / name for name in (*directories, *files))
    return {str(path): file_state(path) for path in sorted(selected)}


def preserve(manifest):
    require(preservation_snapshot() == manifest["preserved_inputs"], "Old environment or historical evidence changed")


def manifest_for(value, accepted, authority_sha):
    repository, commit = Path(value["source_repository"]), value["source_commit"]
    names = [name for name in git(repository, "ls-tree", "-r", "--name-only", "-z", commit, "--", "mcp_server").decode().split("\0") if name]
    modules = {name: sha(git(repository, "show", commit + ":" + name)) for name in names}
    readme = git(repository, "show", commit + ":README.md").decode()
    block = readme.split("<!-- BEGIN GENERATED MCP TOOLS -->", 1)[1].split("<!-- END GENERATED MCP TOOLS -->", 1)[0]
    tools = sorted(re.findall(r"^\| `([^`]+)` \|", block, re.M))
    require(len(tools) == len(set(tools)) == 270, "Pinned tool inventory differs")
    wheel = regular(value["wheel"]["path"])
    with ZipFile(wheel) as archive:
        require(archive.testzip() is None, "Corrupt wheel")
        entries = archive.infolist()
        members = {item.filename for item in entries if not item.is_dir()}
        require(len(members) == len(entries) and len(members) == len(set(archive.namelist())), "Wheel duplicate/directory members")
        for item in entries:
            name = PurePosixPath(item.filename)
            require(not name.is_absolute() and ".." not in name.parts and "\\" not in item.filename and ":" not in item.filename and stat.S_IFMT(item.external_attr >> 16) in (0, stat.S_IFREG), "Unsafe wheel layout")
            require(item.filename.startswith(("mcp_server/", DIST)), "Unexpected wheel root")
        metadata = BytesParser().parsebytes(archive.read(DIST + "METADATA"))
        require(metadata["Name"] == "blender-codex-bridge" and metadata["Version"] == "0.8.0" and "Development Status :: 3 - Alpha" in metadata.get_all("Classifier", []), "Wheel metadata differs")
        versions = [ast.literal_eval(node.value) for node in ast.parse(archive.read("mcp_server/__init__.py")).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "__version__" for target in node.targets)]
        require(versions == ["0.8.0"], "Wheel runtime version differs")
        require({name for name in members if name.startswith("mcp_server/")} == set(modules), "Wheel MCP member set differs from Git")
        require(all(sha(archive.read(name)) == digest_value for name, digest_value in modules.items()), "Wheel MCP bytes differ from Git")
        records = list(csv.reader(io.StringIO(archive.read(DIST + "RECORD").decode())))
        require(len(records) == len({row[0] for row in records}) and {row[0] for row in records} == members, "Wheel RECORD member set differs")
        for name, signed, length in records:
            if name == DIST + "RECORD":
                require(signed == length == "", "Wheel RECORD self-hash differs")
            else:
                body = archive.read(name)
                require(signed == "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(body).digest()).rstrip(b"=").decode() and length == str(len(body)), "Wheel RECORD digest differs")
        expanded = sum(item.file_size for item in entries)
    require(type(accepted["wheel_mcp_members_exact_git"]) is int
            and len(modules) == accepted["wheel_mcp_members_exact_git"] == 63, "CI MCP count differs")
    require(shutil.disk_usage(OUT).free >= max(value["minimum_free_bytes"], expanded + 8 * 1024 * 1024), "Insufficient free capacity")
    expected_tools = (json.dumps(tools, indent=2) + "\n").encode()
    manifest = {"commit": commit, "source_tree": value["source_tree"],
        "source_sha256": sha(json.dumps(modules, sort_keys=True).encode()),
        "source_sha256_scope": "Canonical path-to-SHA256 map of all 63 Git MCP source members", "source_repository": str(repository), "authority_sha256": authority_sha,
        "accepted_ci_audit": value["accepted_ci_audit"], "packages": {WHEEL_NAME: value["wheel"]["sha256"]}, "expected_module_sha256": modules, "expected_tools_sha256": sha(expected_tools),
        "venv": str(NEW), "site_packages": str(SITE), "old_venv": str(OLD), "dependency_reuse": "Explicit third-party-only symlinks; no bridge, startup hook, .pth or old entrypoint reuse. Inputs are not OS-sandboxed; every preserved state is checked before/after owned processes.", "preserved_inputs": preservation_snapshot()}
    return manifest, expected_tools


def load_prepared(path):
    value, accepted, authority_sha = authority(path)
    manifest = json.loads((OUT / "distribution-manifest.json").read_bytes())
    require(manifest["authority_sha256"] == authority_sha and manifest["commit"] == value["source_commit"] and manifest["source_tree"] == value["source_tree"], "Prepared identity differs")
    require(digest(OUT / "packages" / WHEEL_NAME) == value["wheel"]["sha256"], "Staged wheel changed")
    require(digest(OUT / "expected-tools.json") == manifest["expected_tools_sha256"], "Prepared tool inventory changed")
    if (OUT / "dependency-links.json").exists():
        for name, target in json.loads((OUT / "dependency-links.json").read_bytes()).items():
            link = SITE / name
            require(link.is_symlink() and os.readlink(link) == target, "Borrowed dependency link changed")
    preserve(manifest)
    return value, accepted, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    args = parser.parse_args()
    require(sys.flags.isolated and sys.flags.dont_write_bytecode and os.name == "posix", "Use isolated Linux Python -I -B")
    value, accepted, authority_sha = authority(args.authority)
    require(not NEW.exists() and not (OUT / "distribution-manifest.json").exists() and not (OUT / "packages").exists(), "Preparation output already exists; preserve it")
    manifest, tools = manifest_for(value, accepted, authority_sha)
    write_once("distribution-manifest.json", manifest)
    with (OUT / "expected-tools.json").open("xb") as stream:
        stream.write(tools)
    (OUT / "packages").mkdir()
    with (OUT / "packages" / WHEEL_NAME).open("xb") as stream:
        stream.write(Path(value["wheel"]["path"]).read_bytes())
    receipt = {"status": "running", "source_commit": value["source_commit"], "phase": "create_new_venv", "old_inputs_preserved": False}
    primary = None
    try:
        command = [str(BASE_PYTHON), "-I", "-B", "-m", "venv", "--without-pip", str(NEW)]
        with (OUT / "prepare-venv.log").open("xb") as log:
            subprocess.run(command, cwd="/tmp", stdout=log, stderr=subprocess.STDOUT, timeout=180, check=True)
        require(SITE.is_dir() and SITE.resolve() == SITE, "New site is not regular")
        links = {}
        for source in sorted(OLD_SITE.iterdir()):
            name = source.name
            if name in {"mcp_server", "__pycache__", "sitecustomize", "usercustomize", "sitecustomize.py", "usercustomize.py", "pip"} or name.startswith(("blender_codex_bridge-", "pip-", "sitecustomize.", "usercustomize.")) or source.suffix in {".pth", ".pyc"}:
                continue
            require(name in DEPENDENCIES, "Dependency entry is outside the reviewed allowlist: " + name)
            require(not source.is_symlink() and source.resolve().is_relative_to(OLD_SITE) and (source.is_file() or source.is_dir()), "Unexpected dependency entry")
            target = SITE / name
            require(not target.exists() and not target.is_symlink(), "New dependency entry collides")
            target.symlink_to(source, target_is_directory=source.is_dir())
            links[name] = str(source)
        require(set(links) == DEPENDENCIES and not (SITE / "mcp_server").exists(), "Dependency/bridge separation failed")
        write_once("dependency-links.json", links)
        receipt.update(status="prepared", phase="completed", command=command, new_venv=str(NEW), dependency_links=len(links), package_installed=False, stdio_executed=False)
    except BaseException as error:
        primary = error
        receipt.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        try:
            preserve(manifest)
            receipt["old_inputs_preserved"] = True
        except BaseException as error:
            receipt.update(status="failed", preservation_error={"type": type(error).__name__, "message": str(error)})
            primary = primary or error
        try:
            write_once("environment-preparation-receipt.json", receipt)
        except Exception as error:
            sys.stderr.write(json.dumps({"receipt_failure": str(error), "primary_failure": None if primary is None else str(primary), "preparation": receipt}) + "\n")
            if primary is None:
                raise
        if primary is not None and sys.exc_info()[0] is None:
            raise primary


if __name__ == "__main__":
    main()
