"""Execute only after root reviews/pins this NEW one-candidate harness."""
# ruff: noqa: E402 -- disable bytecode before loading even standard-library helpers.
from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import importlib.util
import json
import os
import signal
import subprocess
import tempfile
import time
from contextlib import suppress
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("new_prerelease_prepare", OUT / "prepare.py")
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def receipt(value, primary=None):
    temporary = None
    try:
        descriptor, name = tempfile.mkstemp(prefix=".execution-", suffix=".json", dir=OUT)
        temporary = Path(name)
        with os.fdopen(descriptor, "w") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, OUT / "execution-receipt.json")
    except Exception as error:
        sys.stderr.write(json.dumps({"receipt_failure": str(error), "primary_failure": None if primary is None else str(primary), "execution": value}) + "\n")
        if primary is None:
            raise
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink(missing_ok=True)


def stop_owned(process):
    if process.poll() is None:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
    process.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", type=Path, required=True)
    args = parser.parse_args()
    helpers.require(sys.flags.isolated and sys.flags.dont_write_bytecode and os.name == "posix", "Use Linux root Python -I -B")
    value, _accepted, manifest = helpers.load_prepared(args.authority)
    helpers.require(not (OUT / "execution-receipt.json").exists(), "Execution already attempted; retain it")
    preparation = json.loads((OUT / "environment-preparation-receipt.json").read_bytes())
    helpers.require(preparation["status"] == "prepared" and preparation["old_inputs_preserved"] is True and preparation["package_installed"] is False, "Environment preparation incomplete")
    profile = OUT / "process-profile"
    profile.mkdir()
    environment = {key: os.environ[key] for key in ("PATH", "LANG", "LC_ALL", "LD_LIBRARY_PATH") if key in os.environ}
    for key in ("HOME", "XDG_CACHE_HOME", "XDG_CONFIG_HOME", "TMPDIR"):
        folder = profile / key.lower()
        folder.mkdir(mode=0o700)
        environment[key] = str(folder)
    environment.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", PIP_DISABLE_PIP_VERSION_CHECK="1")
    python = helpers.NEW / "bin/python"
    wheel = OUT / "packages" / helpers.WHEEL_NAME
    probe = "import importlib.metadata,importlib.util,json,sys; assert importlib.util.find_spec('mcp_server') is None; print(json.dumps({'prefix':sys.prefix,'mcp_sdk':importlib.metadata.version('mcp')}))"
    commands = [
        [str(python), "-I", "-B", "-c", probe],
        [str(helpers.ROOT_PYTHON), "-I", "-B", "-m", "pip", "--isolated", "--disable-pip-version-check", "--python", str(python), "install", "--no-index", "--no-deps", "--no-cache-dir", "--no-compile", str(wheel)],
        [str(helpers.ROOT_PYTHON), "-I", "-B", "-m", "pip", "--isolated", "--python", str(python), "check"],
        [str(python), "-I", "-B", str(OUT / "installed_stdio.py"), "--output", str(OUT), "--authority", str(args.authority)],
    ]
    execution = {"status": "running", "source_commit": value["source_commit"], "source_tree": value["source_tree"], "authority_sha256": manifest["authority_sha256"], "distribution_manifest_sha256": helpers.digest(OUT / "distribution-manifest.json"), "accepted_ci_audit_sha256": value["accepted_ci_audit"]["sha256"], "new_venv": str(helpers.NEW), "old_venv_mutation_authorized": False, "steps": [], "old_inputs_preserved": True}
    primary = process = None
    started = time.monotonic()
    try:
        receipt(execution)
        for index, command in enumerate(commands):
            helpers.load_prepared(args.authority)
            row = {"step": index, "command": command, "cwd": "/tmp", "spawned": False, "exit_code": None, "timed_out": False}
            execution["steps"].append(row)
            log = OUT / ("step-" + str(index) + ".log")
            step_error = None
            with log.open("xb") as output:
                process = subprocess.Popen(command, cwd="/tmp", env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
                row["spawned"] = True
                try:
                    process.wait(timeout=180)
                except BaseException as error:
                    row["timed_out"] = isinstance(error, subprocess.TimeoutExpired)
                    step_error = error
                finally:
                    try:
                        stop_owned(process)
                    except Exception as error:
                        row["cleanup_error"] = {"type": type(error).__name__, "message": str(error)}
                        step_error = step_error or error
                    row["exit_code"] = process.returncode
                    if process.poll() is not None:
                        process = None
            row["log_sha256"] = helpers.digest(log)
            try:
                helpers.load_prepared(args.authority)
            except Exception as error:
                execution["old_inputs_preserved"] = False
                row["preservation_error"] = {"type": type(error).__name__, "message": str(error)}
                step_error = step_error or error
            if step_error is None and row["exit_code"] != 0:
                step_error = RuntimeError("Owned installed check failed: " + str(index))
            receipt(execution, primary=step_error)
            if step_error is not None:
                raise step_error
            if index == 0:
                observed = json.loads(log.read_bytes())
                helpers.require(observed == {"prefix": str(helpers.NEW), "mcp_sdk": "2.2.0"}, "Fresh interpreter/SDK mismatch")
        execution.update(status="passed", phase="completed")
    except BaseException as error:
        primary = error
        execution.update(status="failed", failure={"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        if process is not None:
            try:
                stop_owned(process)
            except Exception as error:
                execution["cleanup_failure"] = {"type": type(error).__name__, "message": str(error)}
                execution["status"] = "failed"
                primary = primary or error
        try:
            helpers.preserve(manifest)
        except Exception as error:
            execution["old_inputs_preserved"] = False
            execution["status"] = "failed"
            execution["preservation_failure"] = {"type": type(error).__name__, "message": str(error)}
            if primary is None:
                primary = error
        execution["duration_seconds"] = time.monotonic() - started
        receipt(execution, primary=primary)
        if primary is not None and sys.exc_info()[0] is None:
            raise primary


if __name__ == "__main__":
    main()
