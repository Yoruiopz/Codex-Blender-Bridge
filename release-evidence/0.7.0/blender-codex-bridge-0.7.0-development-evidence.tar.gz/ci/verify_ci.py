"""Verify retained exact-head CI metadata, job logs, and JUnit artifacts."""

from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import hashlib
import json
import re
import stat
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IDENTITY = json.loads((ROOT / "audit-identity.json").read_bytes())
assert IDENTITY["status"] == "ROOT_ACCEPTED_PUBLIC_HEAD", "Wait for the exact public commit notification"
assert IDENTITY["component_version"] == "0.7.0", "Expected the numeric 0.7.0 prerelease candidate"
assert re.fullmatch(r"[0-9a-f]{40}", IDENTITY["source_commit"])
assert re.fullmatch(r"[0-9a-f]{40}", IDENTITY["source_tree"])
assert type(IDENTITY["run_id"]) is int and IDENTITY["run_id"] > 0
COMMIT = IDENTITY["source_commit"]
TREE = IDENTITY["source_tree"]
RUN = IDENTITY["run_id"]
PASSED = IDENTITY["expected_passed"]
SKIPPED = IDENTITY["expected_windows_only_skipped"]
MCP_FILES = IDENTITY["expected_mcp_members"]
assert type(PASSED) is int and PASSED > 0 and SKIPPED == 3
assert type(MCP_FILES) is int and MCP_FILES > 0
TOTAL = PASSED + SKIPPED
EXPECTED_MATRIX = {(python, mcp) for python in ("3.10", "3.11", "3.12") for mcp in ("2.0.0", "2.2.0")}
EXPECTED_SKIPS = {
    ("tests.test_texture_staging", "test_windows_pins_parent_against_rename_then_releases_handles", "Windows directory pin semantics"),
    ("tests.test_windows_test_process", "test_native_child_really_creates_window_on_non_input_desktop", "Windows native desktop isolation"),
    ("tests.test_windows_test_process", "test_native_timeout_reaps_test_and_its_descendant", "Windows native job cleanup"),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    run = json.loads((ROOT / "workflow-run.json").read_bytes())
    jobs = json.loads((ROOT / "jobs-rest.json").read_bytes())
    artifacts = json.loads((ROOT / "artifacts-rest.json").read_bytes())
    assert run["id"] == RUN and run["head_sha"] == COMMIT
    assert run["status"] == "completed" and run["conclusion"] == "success"
    assert run["head_commit"]["id"] == COMMIT
    assert jobs["total_count"] == len(jobs["jobs"]) == 7
    assert artifacts["total_count"] == len(artifacts["artifacts"]) == 7
    matrix, rows, retained_jobs = set(), [], []
    junit_identities = None
    metadata_root = ROOT / "jobs"
    metadata_root.mkdir(exist_ok=True)
    for job in jobs["jobs"]:
        assert job["head_sha"] == COMMIT and job["run_id"] == RUN
        assert job["status"] == "completed" and job["conclusion"] == "success"
        assert all(step["status"] == "completed" and step["conclusion"] == "success" for step in job["steps"])
        raw = json.loads((ROOT / "job-logs" / f"{job['id']}.json").read_bytes())
        assert raw.get("isError") is not True
        log = raw["structuredContent"]["content"]
        assert "git log -1 --format=%H" in log and re.search(r"Z " + COMMIT + r"(?:\r?\n|$)", log)
        log_bytes = log.encode("utf-8")
        (ROOT / "job-logs" / f"{job['id']}.log").write_bytes(log_bytes)
        (metadata_root / f"{job['id']}.json").write_text(json.dumps(job, indent=2) + "\n")
        retained_jobs.append({"id": job["id"], "name": job["name"], "conclusion": job["conclusion"],
                              "source_checkout_verified": True, "decoded_log_bytes": len(log_bytes),
                              "decoded_log_sha256": sha(log_bytes), "steps": len(job["steps"])})
        target = re.fullmatch(r"test \((3\.(?:10|11|12)), (2\.(?:0|2)\.0)\)", job["name"])
        if target is None:
            assert job["name"] == "packages"
            assert "blender_codex_bridge-0.7.0.zip: OK" in log
            assert "blender_codex_bridge-0.7.0-py3-none-any.whl: OK" in log
            assert "blender-codex-bridge-plugin-0.7.0.zip: OK" in log
            continue
        python, mcp = target.groups()
        assert (python, mcp) not in matrix
        matrix.add((python, mcp))
        assert '"mcp==' + mcp + '"' in log and "mcp-" + mcp in log
        assert "python-version: " + python in log
        assert re.search(rf"{PASSED} passed, {SKIPPED} skipped in [\d.]+s", log)
        assert "All checks passed!" in log and f"Success: no issues found in {MCP_FILES} source files" in log
        name = f"python-tests-{python}-mcp-{mcp}-{COMMIT}"
        matches = [item for item in artifacts["artifacts"] if item["name"] == name]
        assert len(matches) == 1
        artifact = matches[0]
        assert artifact["workflow_run"]["id"] == RUN and artifact["workflow_run"]["head_sha"] == COMMIT
        assert not artifact["expired"]
        zip_path = ROOT / "artifacts" / (name + ".zip")
        zip_bytes = zip_path.read_bytes()
        assert len(zip_bytes) == artifact["size_in_bytes"]
        assert artifact["digest"] == "sha256:" + sha(zip_bytes)
        with zipfile.ZipFile(zip_path) as archive:
            assert archive.testzip() is None
            infos = archive.infolist()
            assert len(infos) == 1 and infos[0].filename == "python-tests.xml"
            assert not infos[0].is_dir() and not infos[0].flag_bits & 1
            assert stat.S_IFMT(infos[0].external_attr >> 16) in {0, stat.S_IFREG}
            xml = archive.read("python-tests.xml")
        tree = ET.fromstring(xml)
        suites = list(tree.iter("testsuite"))
        assert len(suites) == 1 and suites[0].attrib["tests"] == str(TOTAL)
        assert suites[0].attrib["skipped"] == "3" and suites[0].attrib["failures"] == suites[0].attrib["errors"] == "0"
        cases = list(tree.iter("testcase"))
        assert len(cases) == TOTAL and not list(tree.iter("failure")) and not list(tree.iter("error"))
        identities = {(case.get("classname"), case.get("name")) for case in cases}
        assert len(identities) == TOTAL
        if junit_identities is None:
            junit_identities = identities
        else:
            assert junit_identities == identities
        skipped = {(case.get("classname"), case.get("name"), case.find("skipped").get("message"))
                   for case in cases if case.find("skipped") is not None}
        assert skipped == EXPECTED_SKIPS
        # Keep the exact original CI ZIP; avoid a redundant multi-megabyte XML copy.
        rows.append({"python": python, "mcp_sdk": mcp, "job_id": job["id"], "artifact_id": artifact["id"],
                     "tests": TOTAL, "passed": PASSED, "skipped": 3, "failures": 0, "errors": 0,
                     "api_sha256_verified": True, "zip_crc_verified": True, "safe_exact_member_set": True,
                     "same_test_identities": True, "xml_sha256": sha(xml), "zip_sha256": sha(zip_bytes),
                     "junit_archive": str(zip_path), "junit_member": "python-tests.xml",
                     "junit_bytes": len(xml), "standalone_xml_copy_created": False, "duration_seconds": float(suites[0].attrib["time"])})
    assert matrix == EXPECTED_MATRIX
    report = {"schema_version": 1, "status": "passed", "checked_at_utc": datetime.now(timezone.utc).isoformat(),
              "source_commit": COMMIT, "source_tree": TREE, "run_id": RUN, "run_url": run["html_url"],
              "event": run["event"], "attempt": run["run_attempt"], "all_seven_jobs_successful": True,
              "all_seven_job_checkout_commits_verified": True, "six_matrix_junit_artifacts_verified": True,
              "matrix": sorted(rows, key=lambda row: (row["python"], row["mcp_sdk"])),
              "jobs": retained_jobs, "known_windows_only_skips": sorted(EXPECTED_SKIPS),
              "ci_packages_smoke_scope": "Fresh wheel installed; console entrypoint --help only, not a real stdio session.",
              "native_blender_tested": False, "windows_tested": False, "release_acceptance": False}
    (ROOT / "matrix-verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "passed", "jobs": len(retained_jobs), "matrix_cells": len(rows),
                      "each_passed": PASSED, "each_skipped": 3, "all_job_checkout_commits_verified": True}))


if __name__ == "__main__":
    main()
