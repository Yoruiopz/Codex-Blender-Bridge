"""Extract already audited exact package members and retain a concise static receipt."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / 'package-verification'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    identity = json.loads((ROOT / 'audit-identity.json').read_bytes())
    assert identity['status'] == 'ROOT_ACCEPTED_PUBLIC_HEAD' and identity['component_version'] == '0.7.0'
    outer = json.loads((VERIFY / 'addon-plugin-outer-audit.json').read_bytes())
    wheel = json.loads((VERIFY / 'wheel-audit.json').read_bytes())
    assert outer['status'] == wheel['status'] == 'passed'
    assert outer['source_commit'] == wheel['source_commit'] == identity['source_commit']
    assert outer['source_tree'] == wheel['source_tree'] == identity['source_tree']
    artifact = next(row for row in json.loads((ROOT / 'artifacts-rest.json').read_bytes())['artifacts'] if row['name'].startswith('blender-codex-bridge-development-'))
    data = (ROOT / 'artifacts/development-packages.zip').read_bytes()
    assert len(data) == artifact['size_in_bytes'] and artifact['digest'] == 'sha256:' + sha(data)
    destination = ROOT / 'package-assets'
    destination.mkdir(exist_ok=False)
    assets = {}
    with zipfile.ZipFile(ROOT / 'artifacts/development-packages.zip') as archive:
        assert archive.testzip() is None
        expected = outer['artifact']['member_fingerprints']
        assert set(archive.namelist()) == set(expected) and len(expected) == 4
        for name, meta in expected.items():
            assert Path(name).name == name
            body = archive.read(name)
            assert len(body) == meta['bytes'] and sha(body) == meta['sha256']
            path = destination / name
            with path.open('xb') as stream:
                stream.write(body)
            assets[name] = {'path': str(path), **meta}
    extraction = {'schema_version': 1, 'status': 'passed', 'source_commit': identity['source_commit'],
        'source_tree': identity['source_tree'], 'source_repository': identity['source_repository'],
        'outer_artifact_sha256': sha(data), 'exact_four_regular_assets_exclusively_created': True,
        'asset_files': assets, 'all_member_lengths_and_sha256_match_static_audit': True,
        'crc_reverified': True, 'package_installed': False, 'packaged_code_executed': False}
    (VERIFY / 'package-extraction-receipt.json').write_text(json.dumps(extraction, indent=2) + '\n')
    receipts = {}
    for name in ('addon-plugin-outer-audit.json', 'wheel-audit.json', 'package-extraction-receipt.json'):
        path = VERIFY / name
        body = path.read_bytes()
        receipts[name] = {'path': str(path), 'bytes': len(body), 'sha256': sha(body)}
    summary = {'schema_version': 1, 'status': 'passed', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': identity['source_commit'], 'source_tree': identity['source_tree'],
        'source_repository': identity['source_repository'], 'immutable_git_source_verified': True,
        'working_tree_used': False, 'source_mode': 'immutable Git blobs at exact published commit',
        'ci_run_id': identity['run_id'], 'artifact_id': artifact['id'], 'artifact_outer_bytes': len(data),
        'artifact_outer_sha256': sha(data), 'python_source_files': outer['python_source_files'],
        'python_source_sha256': outer['python_source_sha256'],
        'addon_members': outer['addon']['members'], 'mcp_members': wheel['source_bytes']['mcp_member_count'],
        'plugin_members': outer['plugin']['members'], 'wheel_members': wheel['wheel']['members'],
        'wheel_record_payloads_verified': wheel['wheel']['record_sha256_and_size_verified'],
        'all_source_member_sets_and_bytes_match_pinned_git': True,
        'all_zip_crc_and_safe_unique_regular_layout_checks_passed': True,
        'all_three_named_asset_checksums_verified': True, 'component_version': '0.7.0',
        'development_classifier': 'Development Status :: 3 - Alpha', 'asset_files': assets,
        'receipts': receipts, 'package_installed': False, 'packaged_code_executed': False,
        'new_candidate_install_and_stdio_required': True, 'old_stdio_session_reused': False,
        'blender_or_windows_run_performed': False, 'release_acceptance': False,
        'scope': 'Static exact-commit 0.7.0 package audit only. A new candidate installation and real stdio session are separately required; historical 0.3.0 session reuse is not candidate evidence. No native or release qualification.'}
    (VERIFY / 'package-audit-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'source_commit': identity['source_commit'],
        'addon_members': summary['addon_members'], 'mcp_members': summary['mcp_members'],
        'plugin_members': summary['plugin_members'], 'wheel_members': summary['wheel_members']}))


if __name__ == '__main__':
    main()
