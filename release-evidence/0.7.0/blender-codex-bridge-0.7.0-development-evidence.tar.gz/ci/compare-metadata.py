"""Compare connector-normalized jobs/artifacts with full read-only REST metadata."""
import sys
sys.dont_write_bytecode = True

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_bytes())


def main():
    identity = read('audit-identity.json')
    assert identity['status'] == 'ROOT_ACCEPTED_PUBLIC_HEAD' and identity['component_version'] == '0.7.0'
    jobs_plugin = read('jobs-plugin.json')
    artifacts_plugin = read('artifacts-plugin.json')
    assert not jobs_plugin.get('isError') and not artifacts_plugin.get('isError')
    jobs_rest = read('jobs-rest.json')
    artifacts_rest = read('artifacts-rest.json')
    jobs = {row['id']: row for row in jobs_rest['jobs']}
    artifacts = {row['id']: row for row in artifacts_rest['artifacts']}
    assert len(jobs) == jobs_rest['total_count'] == len(jobs_plugin['structuredContent']['jobs']) == 7
    assert len(artifacts) == artifacts_rest['total_count'] == len(artifacts_plugin['structuredContent']['artifacts']) == 7
    for row in jobs_plugin['structuredContent']['jobs']:
        other = jobs.pop(row['id'])
        assert all(row[key] == other[key] for key in ('id', 'name', 'status', 'conclusion', 'run_id'))
        assert row['status'] == 'completed' and row['conclusion'] == 'success'
        assert other['head_sha'] == identity['source_commit'] and other['run_id'] == identity['run_id']
        left = [{key: step[key] for key in ('name', 'number', 'status', 'conclusion')} for step in row['steps']]
        right = [{key: step[key] for key in ('name', 'number', 'status', 'conclusion')} for step in other['steps']]
        assert left == right
    assert not jobs
    for row in artifacts_plugin['structuredContent']['artifacts']:
        other = artifacts.pop(row['id'])
        assert all(row[key] == other[key] for key in row)
        assert row['workflow_run']['head_sha'] == identity['source_commit'] and row['workflow_run']['id'] == identity['run_id']
    assert not artifacts
    result = {'status': 'passed', 'jobs_compared': 7, 'artifacts_compared': 7,
        'run_id': identity['run_id'], 'source_commit': identity['source_commit']}
    (ROOT / 'plugin-rest-metadata-agreement.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
