# Retained preview raster and worker-source audit

Read-only audit of immutable source `2b1c25b62f2340b92201471d925b78e4b01a3b0b` and the existing four-process `/tmp/bcb-populated-preview-01` evidence. No repository edits, tests, Blender/native runs, builds or GitHub operations were performed. The candidate's four worker/DTO/process/job source files still exactly match that immutable source.

## Measured files and unresolved viewer observations

Root reported the 4.5.14 populated preview and 5.2.2 null preview as ALLBLACK in the viewer. Preserve those as viewer observations. Their retained PNG bytes contain nonblack geometry: all four files have 1,747 pixels with alpha >=128, the same alpha bounding box `[15,33,89,94]`, opaque RGB extrema R195–216/G202–222/B210–227, and alpha extrema 128–255 for that foreground. Whole-image alpha spans0–255. The read-only decoder independently checked PNG chunk CRCs, RGBA8 dimensions128×128 and scanline reconstruction.

The 4.5.14 null and populated **decoded RGBA byte streams are identical**, SHA256 `1dd864ba61b4e8346b5504024503e642981782753dde7bad4625e1857debd080`. The 5.2.2 pair is also identical, SHA256 `9f43188402466a9fd3836b09732479aa347d2cb1e01ceb364f44335f6f7948ff`. The two version pairs differ slightly from one another; the complete four-by-four equality matrix is retained in `black-preview-pixel-evidence.json`.

Every file SHA256 matches the returned image receipt and the worker's parent-validated PNG receipt. The embedded worker/DTO program hashes match the reviewed immutable source. Thus a black stored render is not established by these four files. The viewer discrepancy is unexplained. Byte equality does not resolve viewing behavior or establish material/artistic appearance acceptance.

## Finite source findings

- `geometry_preview_worker.py:164–192` reconstructs the bounded Mesh and creates a new opaque material with fixed base color(.55,.7,.9,1), roughness.65 and flat polygons; no original material is copied.
- `geometry_preview_dto.py:194–219` derives a deterministic orthographic basis, camera location, clipping and projected bounds from the DTO. `geometry_preview_worker.py:193–213` constructs that camera, a camera-aligned area light and a fixed world. The null/populated fixture variants render the same target DTO, so the protected-data setup should not change this scene.
- `geometry_preview_worker.py:214–235` explicitly selects Cycles CPU, eight fixed samples, seed0, one thread, fixed128² RGBA8, transparent film, worker-only ViewLayer update and a named-scene synchronous render. Source-owned pending state is never updated here.
- `geometry_preview_worker.py:160–161,248–280` requires an absent canonical owned output, validates the private bundle/token, renders before receipt creation and reports only after output validation. `geometry_preview_process.py:271–275` refuses a still-running worker; lines298–415 authenticate the exited worker, DTO/build/process identity, reconstructed geometry, camera, world bounds and exact PNG digest. No shared-output or parent-read-before-render race is demonstrated.
- `geometry_preview_jobs.py:203–259` retains validated immutable PNG bytes only after worker reaping and successful private-resource cleanup; lines372–397 recheck cache digest before base64 return. The fixture writes each returned PNG to its distinct per-case temporary folder with exclusive-create mode. The stored files match their receipts, so no stale-file substitution is demonstrated.

## Exact validation gap and next bounded action

`geometry_preview_dto.py:222–285` validates envelope/CRC/decompression/filters, requires opaque pixels and a nonclipped alpha bounding box, then returns `visual_review_performed=false`. It does **not** test foreground RGB brightness/contrast or independently review usefulness. Parent validation repeats that same check in `geometry_preview_process.py:412–415`. Consequently structural success cannot certify useful displayed geometry, and an opaque black silhouette could pass this validator in principle. The current four decoded files are not that negative case.

No worker fix is justified by this evidence. Retain the viewer negatives, exact PNG and decoded RGBA hashes, and compare the same accepted bytes in a separate viewer/visual-review path before any appearance claim. A later bounded acceptance enhancement could retain foreground RGB/alpha statistics and an exact-image visual-review result; it must not substitute metrics for appearance review or silently change renderer contracts. Investigate the display path only with reproduced byte-to-display evidence; do not claim a viewer root cause now.

For0.7 candidate notes: report structural selected-field checks separately, preserve the display discrepancy as under investigation, and keep appearance/current-viewport/full H02/F04/I01 acceptance unqualified. Windows and all29/14 stable requirements remain deferred/open as already agreed.
