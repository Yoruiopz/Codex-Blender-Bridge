from __future__ import annotations
import hashlib,json,pathlib,subprocess,sys,time
base=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/dev/shm/blender-codex-resume-20261025/installed-package-qualification-07')
config=pathlib.Path(sys.argv[1]).resolve(strict=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='864ad987c82f1ddaf5b7b0e6e0df40a23ee27ef3'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
helper=base/'private_display.py'
command=[sys.executable,str(helper),sys.executable,str(root/'scripts/run_blender_checks.py')]
for version in ('4.5.14','5.2.2'):command+=['--blender',f'/workspace/Codex-Blender-Bridge/build/blender-runtimes-20261022/extracted/blender-{version}-linux-x64/blender']
command+=['--case','installed_addon_probe','--package-probe-config',str(config),'--timeout','600','--output',str(base/'native')]
receipt={'source_commit':head,'config_sha256':sha(config),'private_display_helper_sha256':sha(helper),'command':command,'source_and_config_unchanged':False,'Windows_tested':False}
(base/'invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (base/'runner.log').open('xb') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
receipt.update(exit_code=r.returncode,seconds=time.monotonic()-start,source_and_config_unchanged=sha(config)==receipt['config_sha256'] and sha(helper)==receipt['private_display_helper_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and subprocess.check_output(['git','status','--porcelain'],cwd=root)==b'',runner_log_sha256=sha(base/'runner.log'))
if (base/'native/report.json').exists():receipt['report_sha256']=sha(base/'native/report.json')
(base/'invocation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exit_code':r.returncode,'seconds':receipt['seconds'],'source_and_config_unchanged':receipt['source_and_config_unchanged']}))
raise SystemExit(r.returncode)
