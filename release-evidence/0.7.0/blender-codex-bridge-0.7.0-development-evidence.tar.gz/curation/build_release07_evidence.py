from pathlib import Path, PurePosixPath
import json, hashlib, tarfile, gzip, io, stat, re
B=Path('/dev/shm/blender-codex-resume-20261025'); O=B/'publication-0.7'; payload={}; provenance={}
def digest(raw): return hashlib.sha256(raw).hexdigest()
def add(path, name):
 p=Path(path); n=PurePosixPath(name)
 assert not n.is_absolute() and '..' not in n.parts and name not in payload
 assert not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
 assert p.suffix.lower() not in {'.blend','.blend1','.exr','.bcbimg','.bin'} and p.name!='Xauthority'
 raw=p.read_bytes(); assert len(raw)<=16*1024*1024
 payload[name]=raw; provenance[name]={'source':str(p),'bytes':len(raw),'sha256':digest(raw)}
def tree(root,prefix,suffixes,exclude=()):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in suffixes and not any(x in p.parts for x in exclude): add(p,prefix+'/'+p.relative_to(root).as_posix())
ci=B/'release-0.7/ci'
for p in sorted(ci.glob('*.json')): add(p,'ci/'+p.name)
for sub,suffixes in [('artifacts',{'.zip'}),('job-logs',{'.json','.log'}),('jobs',{'.json'}),('package-verification',{'.json','.py'}),('package-assets',{'.zip','.whl','.txt'})]:tree(ci/sub,'ci/'+sub,suffixes)
for p in [ci/'collect-metadata.py',ci/'compare-metadata.py',ci/'verify_ci.py',ci/'finish-packages.py',ci/'combine-audit.py']:add(p,'ci/'+p.name)
for label,folder in [('candidate','candidate-0.7-root-validation-01'),('installed-artist-support','installed-artist-guards-root-validation-01'),('installed-receipt-support','installed-probe-receipt-root-validation-01')]:tree(B/folder,'portable/'+label,{'.json','.xml','.log'})
for label,root in [('source','bcb-int07-final-01'),('installed-artists','bcb-07-artists-01'),('installed-from-03','bcb-07-install03-02'),('installed-from-06','bcb-07-install06-02'),('prior-reporting-failure','bcb-07-install06-01')]:
 d=Path('/tmp')/root
 for p in sorted(d.glob('*.json')):add(p,'native/'+label+'/'+p.name)
 for name in ['runner.log','private_display.py','run_focused.py','run_installed.py']:
  if(d/name).exists():add(d/name,'native/'+label+'/'+name)
 tree(d/'native','native/'+label+'/native',{'.json','.log','.png'},('installed scripts with spaces','installed artist scripts with spaces','config','scripts','datafiles','home','working'))
wheel=B/'release-0.7/installed-wheel'
for suffix in ['*.json','*.jsonl','*.py','*.log']:
 for p in sorted(wheel.glob(suffix)):add(p,'installed-wheel/'+p.name)
tree(B/'release-0.7/root','reviews/root',{'.json','.png'})
for p in [B/'publication-0.7/qualified-review/review.json',B/'publication-0.7/blocker-plan-publication/anonymous-verification.json',B/'candidate-0.7-analysis/black-preview-pixel-evidence.json',B/'candidate-0.7-analysis/black-preview-source-audit.md',B/'candidate-0.7-analysis/conventions-audit-receipt.json',B/'candidate-0.7-analysis/postfreeze-contract-review.json',B/'candidate-0.7-analysis/installed-wheel-harness-review.json']:
 add(p,'reviews/independent/'+p.parent.name+'-'+p.name)
for name in ['RELEASE-NOTES.md','FUNCTIONAL-SCOPE-AND-BLOCKER-PLAN.md']:add(O/'qualified'/name,'scope/'+name)
for name in ['source-with-qualified-support.bundle','support-verification.json','support-standalone-fsck.log']:add(B/'release-0.7/source-bundle'/name,'source/'+name)
add(Path(__file__),'curation/build_release07_evidence.py')
assert len(payload)>100
issues=[]
patterns=[r'https://[^\s"<>]*(?:sig=|[?&]se=)',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'gh[pousr]_[A-Za-z0-9]{30,}']
for name,raw in payload.items():
 if name.endswith(('.json','.jsonl','.log','.md','.py','.txt','.xml')):
  text=raw.decode('utf-8-sig')
  for pattern in patterns:
   if re.search(pattern,text):issues.append({'member':name,'pattern':pattern})
assert not issues,issues
manifest={'schema_version':1,'source_commit':'8d07ad898ba92c5e94db57b1562fefef9c8e0e1c','source_tree':'4a9dccf8b3c9a6a05aad1d1d19187381fb4e6bbb','candidate_CI':40217002252,'payload_files':len(payload),'files':{n:{'bytes':len(v),'sha256':digest(v)}for n,v in sorted(payload.items())},'scope':'Reviewed public source and exact CI artifacts; synthetic fixture logs/reports/previews and fresh installed evidence. No user projects/preferences, recovery backups, private WIP source branches, Xauthority cookies, signed download references or credentials. All stable gates remain open; Windows deferred.'}
payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();payload['PAYLOAD-SHA256SUMS.txt']=''.join(digest(v)+'  '+n+'\n'for n,v in sorted(payload.items())).encode()
archive=O/'blender-codex-bridge-0.7.0-development-evidence.tar.gz'
with archive.open('xb')as target:
 with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0,compresslevel=9)as compressed:
  with tarfile.open(mode='w',fileobj=compressed)as output:
   for name,raw in sorted(payload.items()):
    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;output.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz')as check:
 members=check.getmembers();assert len(members)==len(payload)and all(m.isfile()for m in members)
 for member in members:assert check.extractfile(member).read()==payload[member.name]
sha=digest(archive.read_bytes());(O/'EVIDENCE-SHA256SUMS.txt').write_text(sha+'  '+archive.name+'\n')
(O/'archive-verification.json').write_text(json.dumps({'status':'ROOT_CURATED_BYTES_VERIFIED_PENDING_INDEPENDENT_REVIEW','archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'payload_files':manifest['payload_files'],'all_members':len(payload),'all_regular_unique_safe_members':True,'complete_readback_verified':True,'signed_references_or_secret_patterns':issues,'excluded':['User projects and preferences','Recovery backups and private WIP branches','All .blend/.blend1/.exr/.bcbimg/.bin files','Xauthority cookies and signed download references'],'source_bundle_only_public_candidate_and_qualified_support':True,'files':provenance},indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'payload_files':manifest['payload_files'],'regular_members':len(payload)}))
