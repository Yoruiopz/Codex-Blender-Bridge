"""Always-available inspection, capture, checkpoint, save, and registry tools."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..constants import ADDON_VERSION_STRING
from ..errors import BridgeError, ErrorCode, invalid_argument
from ..permissions import Permission
from ..scene_inspector import inspect_object, inspect_scene, project_info, scene_summary
from ..selection import inspect_selection
from ..tool_registry import ToolContext, ToolRegistry, check_final_mutation
from ..utils import bool_param, int_param, require_blender
from ..viewport import capture_viewport


def bridge_status(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    del params
    bpy = require_blender()
    state = context.state.snapshot()
    scene = bpy.context.scene
    active = bpy.context.view_layer.objects.active
    return {
        "blender_version": bpy.app.version_string,
        "addon_version": ADDON_VERSION_STRING,
        "connection_status": state["connection_status"],
        "server": {
            "running": state["server_running"],
            "host": state["host"],
            "port": state["port"],
            "connected_clients": state["connected_clients"],
        },
        "filepath": bpy.data.filepath,
        "mode": bpy.context.mode,
        "scene": scene.name,
        "active_object": active.name if active else None,
        "enabled_permissions": [
            name for name, enabled in context.permissions.snapshot().items() if enabled
        ],
        "permissions": context.permissions.snapshot(),
        "enabled_toolsets": list(context.registry.enabled_toolsets),
        "jobs": context.jobs.status() if context.jobs is not None else None,
        "agent": {
            "paused": state["paused"],
            "emergency_stopped": state["emergency_stopped"],
            "current_task": state["current_task"],
            "current_method": state["current_method"],
            "is_executing": state["is_executing"],
            "undo_group": (context.checkpoints.editor_session_status()
                           if callable(getattr(context.checkpoints, "editor_session_status", None)) else None),
            "recovery": (context.checkpoints.recovery_status(limit=0)
                         if callable(getattr(context.checkpoints, "recovery_status", None)) else None),
        },
    }


def bridge_task_set(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    description = params.get("description")
    if not isinstance(description, str) or not description.strip():
        raise invalid_argument("A non-empty task 'description' is required.")
    if len(description) > 500:
        raise invalid_argument("Task descriptions must be at most 500 characters.")
    context.state.set_task(description.strip())
    return {"task": description.strip(), "active": True}


def bridge_task_clear(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    del params
    context.state.set_task("")
    return {"task": "", "active": False}


def save_project(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    """Refuse native saving until its external/runtime effects can be bounded."""
    try:
        raw_filepath = params.get("filepath")
        if raw_filepath is not None and (not isinstance(raw_filepath, str) or not raw_filepath.strip()):
            raise invalid_argument("'filepath' must be a non-empty string.")
        # One final live snapshot checks all required grants together. No
        # Blender or caller-path reader follows this provider.
        required = [Permission.SAVE_PROJECT]
        if raw_filepath is not None:
            required.append(Permission.ACCESS_EXTERNAL_FILES)
        context.require(*required)
        check_final_mutation(context, "project.save")
        raise BridgeError(
            ErrorCode.NOT_IMPLEMENTED,
            "Project saving is unavailable until Blender's native catalog and runtime save effects can be bounded.",
            {"reason": "UNOBSERVABLE_NATIVE_SAVE_SIDE_EFFECTS", "safe_project_save_verified": False},
        )
    except BridgeError as error:
        # These facts describe this bridge handler, not arbitrary host/provider
        # code. Keep canonical denial identity/code and never finalize an old
        # editor session on behalf of this non-writing save request.
        error.context.update(execution_started=False, native_save_invoked=False,
                             project_saved=False, bridge_file_writes=False)
        raise


def checkpoint_create(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    description = params.get("description", "Agent checkpoint")
    if not isinstance(description, str):
        raise invalid_argument("'description' must be a string.")
    return context.checkpoints.create(description, before_write=lambda: check_final_mutation(context, "checkpoint.create"))


def scene_snapshot(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    return context.evidence.capture(require_blender(), params, context.check_cancelled)


def scene_compare(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    return context.evidence.compare(require_blender(), params, context.check_cancelled)


def checkpoint_undo_last(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    if not bool_param(params, "confirm_global_undo", False):
        raise invalid_argument(
            "Set 'confirm_global_undo' to true to acknowledge that Blender cannot prove undo ownership."
        )
    if bool_param(params, "restore_snapshot", False):
        return context.checkpoints.restore_operation(check_cancelled=context.check_cancelled)
    return context.checkpoints.undo_last()


def checkpoint_list(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    limit = int_param(params, "limit", 20, minimum=1, maximum=100)
    checkpoints = context.checkpoints.list(limit)
    history = context.state.history(limit)
    # Recovery controls remain available without scene inspection. Detailed
    # File/image evidence must not become an inspection bypass.
    if not context.permissions.snapshot().get(Permission.INSPECT_SCENE.value, False):
        for record in history:
            image_job = record.get("tool") in {"image.paint_job_start", "image.paint_surface_job_start",
                                              "image.export_job_start", "image.snapshot_job_start",
                                              "image.restore_snapshot_job_start"}
            if image_job or any(record.get(field) is not None for field in ("job_evidence", "external_effects", "recovery_evidence")):
                # Terminal descriptions can contain image names or file paths,
                # even after their structured evidence has been redacted.
                record["description"] = "Operation details require scene inspection."
                record["description_redacted"] = True
            if record.get("job_evidence") is not None:
                record["job_evidence"] = None
                record["job_evidence_redacted"] = True
            if record.get("external_effects") is not None:
                record["external_effects"] = None
                record["external_effects_redacted"] = True
            if record.get("recovery_evidence") is not None:
                record["recovery_evidence"] = None
                record["recovery_evidence_redacted"] = True
    return {
        "checkpoints": checkpoints,
        "checkpoint_count": len(checkpoints),
        "operation_history": history,
        "operation_count": len(history),
        "recovery": context.checkpoints.recovery_status(limit=limit),
    }


def checkpoint_restore_last(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    if not bool_param(params, "confirm_global_undo", False):
        raise invalid_argument(
            "Set 'confirm_global_undo' to true to acknowledge that restore uses Blender global undo."
        )
    return context.checkpoints.restore_last(check_cancelled=context.check_cancelled)


def toolsets_list(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    del params
    return context.registry.describe()


def _toolset_name(params: Mapping[str, Any]) -> str:
    value = params.get("name", params.get("toolset"))
    if not isinstance(value, str) or not value.strip():
        raise invalid_argument("A non-empty toolset 'name' is required.")
    return value.strip().lower()


def toolsets_enable(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    name = _toolset_name(params)
    was_enabled = name in context.registry.enabled_toolsets
    context.registry.enable_toolset(name)
    return {"changed": not was_enabled, "toolset": name, "enabled": True}


def toolsets_disable(context: ToolContext, params: Mapping[str, Any]) -> dict[str, Any]:
    name = _toolset_name(params)
    was_enabled = name in context.registry.enabled_toolsets
    context.registry.disable_toolset(name)
    return {"changed": was_enabled, "toolset": name, "enabled": False}


def register_tools(registry: ToolRegistry) -> None:
    registry.register("scene.snapshot", scene_snapshot, permissions=(Permission.INSPECT_SCENE,),
                      description="Capture bounded structural evidence for explicitly named objects and fields.")
    registry.register("scene.compare", scene_compare, permissions=(Permission.INSPECT_SCENE,),
                      description="Compare current measured object fields with a session snapshot; report incomplete coverage.")
    inspect_permission = (Permission.INSPECT_SCENE,)
    registry.register("bridge.status", bridge_status, description="Return Blender, bridge, permission, and agent state.")
    registry.register("bridge.task.set", bridge_task_set, description="Show the current high-level Codex task in Blender's interactive UI.")
    registry.register("bridge.task.clear", bridge_task_clear, description="Clear the completed or abandoned task from Blender's interactive UI.")
    registry.register("project.info", lambda c, p: project_info(p), permissions=inspect_permission, description="Inspect project-level state.")
    registry.register("scene.inspect", lambda c, p: inspect_scene(p), permissions=inspect_permission, description="Inspect bounded authoritative scene structure.")
    registry.register("scene.summary", lambda c, p: scene_summary(p), permissions=inspect_permission, description="Return an LLM-oriented scene summary in text and JSON.")
    registry.register("selection.inspect", lambda c, p: inspect_selection(p), permissions=inspect_permission, description="Inspect object and edit-mesh selection context.")
    registry.register("object.inspect", lambda c, p: inspect_object(p), permissions=inspect_permission, description="Inspect one object and compact mesh diagnostics.")
    registry.register(
        "viewport.capture",
        lambda c, p: capture_viewport(p),
        permissions=(Permission.CAPTURE_VIEWPORT,),
        modifies=True,
        automatic_checkpoint=False,
        description=(
            "Capture a managed temporary viewport PNG, restore temporary UI/render "
            "settings, and replace Blender's Render Result buffer."
        ),
    )
    registry.register("checkpoint.create", checkpoint_create, description="Create a named Blender undo marker.", modifies=True, automatic_checkpoint=False)
    registry.register(
        "checkpoint.undo_last",
        checkpoint_undo_last,
        modifies=True,
        description=(
            "Run one Blender global undo after explicit risk acknowledgement; interleaved user "
            "work cannot be distinguished."
        ),
        automatic_checkpoint=False,
    )
    registry.register(
        "checkpoint.restore_last",
        checkpoint_restore_last,
        modifies=True,
        description=(
            "Use repeated Blender global undo after local confirmation; interleaved user work "
            "cannot be distinguished."
        ),
        automatic_checkpoint=False,
        remote=False,
    )
    registry.register(
        "checkpoint.list",
        checkpoint_list,
        description="List bounded checkpoint labels, history and conservative native recovery availability.",
    )
    registry.register(
        "project.save",
        save_project,
        permissions=(Permission.SAVE_PROJECT,),
        modifies=True,
        automatic_checkpoint=False,
        description="Project saving is unavailable until native save side effects can be bounded.",
    )
    registry.register("toolsets.list", toolsets_list, description="List Blender-side structured toolsets and tools.")
    registry.register("toolsets.enable", toolsets_enable, description="Enable one Blender-side domain toolset.")
    registry.register("toolsets.disable", toolsets_disable, description="Disable one Blender-side domain toolset.")
