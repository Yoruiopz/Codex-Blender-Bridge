"""Isolated real-Blender evidence for the unreleased structured artist tools.

Run with --background --factory-startup --python-exit-code 1. Creates only
disposable fixtures and one explicitly named render under build/; no .blend save.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "addon"))
import blender_codex_bridge  # noqa: E402
from blender_codex_bridge.errors import BridgeError  # noqa: E402
from blender_codex_bridge.permissions import Permission, PermissionManager  # noqa: E402
from blender_codex_bridge.runtime import get_runtime  # noqa: E402
from blender_codex_bridge.tools import animation_layers as anim  # noqa: E402
from blender_codex_bridge.tools import compositor, simulation, weights  # noqa: E402
from blender_codex_bridge.tools import geometry_nodes as gn  # noqa: E402


def call(handler, **params):
    runtime = get_runtime()
    name = next(
        name
        for name in runtime.registry.list_tools()
        if runtime.registry.get(name).handler == handler
    )
    return runtime.dispatch(name, params)


def denied(handler, **params):
    try:
        call(handler, **params)
    except BridgeError as exc:
        assert exc.code == "INVALID_ARGUMENT", exc
    else:
        raise AssertionError("Unsafe request accepted")


def empty(name):
    obj = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(obj)
    return obj


def main():
    blender_codex_bridge.register()
    runtime = get_runtime()
    allowed = {permission.value: True for permission in Permission}
    permissions = PermissionManager(lambda: allowed)
    runtime.permissions = runtime.executor.permissions = permissions
    for group in ("weights", "compositor", "animation_layers", "simulation", "geometry_nodes"):
        runtime.dispatch("toolsets.enable", {"name": group})
    for handler, permission in (
        (weights.group_create, "EDIT_MESH"),
        (compositor.create, "EDIT_RENDER"),
        (anim.driver_add, "EDIT_ANIMATION"),
        (simulation.cloth_add, "EDIT_SCENE"),
    ):
        allowed[permission] = False
        try:
            call(handler)
        except BridgeError as exc:
            assert exc.code == "PERMISSION_DENIED"
        else:
            raise AssertionError("Permission denial bypassed")
        finally:
            allowed[permission] = True
    scene = bpy.context.scene
    selected = [o.name for o in bpy.context.selected_objects]
    active = bpy.context.view_layer.objects.active
    cube = bpy.data.objects["Cube"]
    # Numeric weight workflows: explicit topology and source/target correspondence.
    line_mesh = bpy.data.meshes.new("Weight Line")
    line_mesh.from_pydata([(0, 0, 0), (1, 0, 0), (2, 0, 0)], [(0, 1), (1, 2)], [])
    line = bpy.data.objects.new("Weight Line", line_mesh)
    scene.collection.objects.link(line)
    for name in ("Skin", "Protected"):
        call(weights.group_create, object_name=line.name, group_name=name)
    call(weights.assign, object_name=line.name, group_name="Skin", vertex_indices=[0], weight=1.0)
    call(
        weights.assign,
        object_name=line.name,
        group_name="Protected",
        vertex_indices=[0, 1, 2],
        weight=0.25,
    )
    call(
        weights.smooth,
        object_name=line.name,
        group_name="Skin",
        vertex_indices=[1],
        iterations=3,
        factor=1.0,
    )
    assert line.vertex_groups["Skin"].weight(0) == 1.0
    assert line.vertex_groups["Skin"].weight(1) == 0.5
    call(
        weights.transfer,
        source_object=line.name,
        source_group="Skin",
        object_name=line.name,
        group_name="Skin",
        source_indices=[0, 1],
        vertex_indices=[1, 0],
    )
    assert line.vertex_groups["Skin"].weight(0) == 0.5
    assert line.vertex_groups["Skin"].weight(1) == 1.0
    call(
        weights.transfer,
        source_object=line.name,
        source_group="Skin",
        object_name=line.name,
        group_name="Skin",
        source_indices=[2],
        vertex_indices=[0],
    )
    assert len(line_mesh.vertices[0].groups) == 1
    assert all(line.vertex_groups["Protected"].weight(i) == 0.25 for i in range(3))
    assert [tuple(v.co) for v in line_mesh.vertices] == [(0, 0, 0), (1, 0, 0), (2, 0, 0)]
    line.vertex_groups["Skin"].lock_weight = True
    denied(weights.smooth, object_name=line.name, group_name="Skin", vertex_indices=[1])
    destination = bpy.data.objects.new("Weight Destination", line_mesh.copy())
    scene.collection.objects.link(destination)
    call(weights.group_create, object_name=destination.name, group_name="Copied")
    call(
        weights.transfer,
        source_object=line.name,
        source_group="Skin",
        object_name=destination.name,
        group_name="Copied",
        source_indices=[1, 0],
        vertex_indices=[2, 1],
    )
    assert destination.vertex_groups["Copied"].weight(2) == 1.0
    assert all(
        g.group != destination.vertex_groups["Copied"].index
        for g in destination.data.vertices[1].groups
    )
    assert line.vertex_groups["Skin"].weight(1) == 1.0
    for name, value in (("A", 0.2), ("B", 0.3)):
        call(weights.group_create, object_name=cube.name, group_name=name)
        call(
            weights.assign,
            object_name=cube.name,
            group_name=name,
            vertex_indices=list(range(8)),
            weight=value,
        )
    call(
        weights.normalize,
        object_name=cube.name,
        group_names=["A", "B"],
        vertex_indices=list(range(8)),
    )
    assert abs(cube.vertex_groups["A"].weight(0) - 0.4) < 1e-6
    assert abs(cube.vertex_groups["B"].weight(7) - 0.6) < 1e-6
    cube.vertex_groups["A"].lock_weight = True
    denied(weights.assign, object_name=cube.name, group_name="A", vertex_indices=[0], weight=0.9)
    cube.vertex_groups["A"].lock_weight = False
    call(weights.assign, object_name=cube.name, group_name="A", vertex_indices=[0], weight=None)
    assert len(cube.data.vertices[0].groups) == 1
    page = call(weights.inspect, object_name=cube.name, offset=2, max_vertices=2)
    assert page["truncated"]

    source, target = empty("Driver Source"), empty("Driver Target")
    source.location.x = 2
    call(
        anim.driver_add,
        object_name=target.name,
        data_path="location",
        index=0,
        variables=[
            {
                "object_name": source.name,
                "transform_type": "LOC_X",
                "transform_space": "WORLD_SPACE",
            }
        ],
    )
    bpy.context.view_layer.update()
    assert (
        abs(
            target.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world.translation.x
            - 2
        )
        < 1e-5
    )
    denied(
        anim.driver_add,
        object_name=target.name,
        data_path="scale",
        driver_type="SCRIPTED",
        variables=[],
    )
    call(anim.driver_remove, object_name=target.name, data_path="location", index=0)
    assert not target.animation_data.drivers

    actor = empty("NLA Actor")
    actor.location.x = 0
    actor.keyframe_insert(data_path="location", frame=1)
    actor.location.x = 10
    actor.keyframe_insert(data_path="location", frame=11)
    action = actor.animation_data.action
    slot = getattr(actor.animation_data, "action_slot", None)
    before_motion = []
    for frame in (1, 6, 11, 15):
        scene.frame_set(frame)
        before_motion.append(tuple(actor.location))
    below = actor.animation_data.nla_tracks.new()
    below.name = "Below"
    actor.animation_data.nla_tracks.active = below
    pushed = call(
        anim.nla_push_down, object_name=actor.name, track_name="Motion", strip_name="Walk"
    )
    assert actor.animation_data.action is None
    assert actor.animation_data.nla_tracks.active == below
    assert actor.animation_data.nla_tracks[-1].name == "Motion"
    if slot is not None:
        assert actor.animation_data.nla_tracks["Motion"].strips["Walk"].action_slot == slot
    assert pushed["pushed_action"] == action.name
    for frame, expected in zip((1, 6, 11, 15), before_motion, strict=True):
        scene.frame_set(frame)
        assert all(abs(a - b) < 1e-5 for a, b in zip(actor.location, expected, strict=True))
    call(anim.nla_edit_track, object_name=actor.name, track_name="Below", remove=True)
    scene.frame_set(6)
    assert abs(actor.location.x - 5) < 0.01, actor.location.x
    protected = actor.animation_data.nla_tracks.new()
    protected.name = "Protected"
    call(
        anim.nla_add,
        object_name=actor.name,
        track_name="Alternate",
        strip_name="Slow",
        action_name=action.name,
    )
    call(
        anim.nla_edit,
        object_name=actor.name,
        track_name="Alternate",
        strip_name="Slow",
        settings={"scale": 2.0},
    )
    scene.frame_set(6)
    alternate_x = actor.location.x
    assert abs(alternate_x - 5) > 0.1
    solo = call(anim.nla_solo_track, object_name=actor.name, track_name="Motion", enabled=True)
    scene.frame_set(6)
    assert solo["solo_after"] == ["Motion"] and abs(actor.location.x - 5) < 0.01
    denied(anim.nla_solo_track, object_name=actor.name, track_name="Alternate", enabled=True)
    call(anim.nla_edit_track, object_name=actor.name, track_name="Motion", settings={"lock": True})
    denied(
        anim.nla_solo_track,
        object_name=actor.name,
        track_name="Alternate",
        enabled=True,
        replace_existing=True,
    )
    call(anim.nla_edit_track, object_name=actor.name, track_name="Motion", settings={"lock": False})
    call(
        anim.nla_solo_track,
        object_name=actor.name,
        track_name="Alternate",
        enabled=True,
        replace_existing=True,
    )
    scene.frame_set(6)
    assert abs(actor.location.x - alternate_x) < 0.01
    call(anim.nla_solo_track, object_name=actor.name, track_name="Alternate", enabled=False)
    call(
        anim.nla_edit,
        object_name=actor.name,
        track_name="Alternate",
        strip_name="Slow",
        remove=True,
    )
    call(anim.nla_edit_track, object_name=actor.name, track_name="Alternate", remove=True)
    assert not protected.is_solo and not protected.mute
    call(
        anim.nla_edit_track,
        object_name=actor.name,
        track_name="Motion",
        settings={"name": "Renamed", "mute": True},
    )
    actor.location.x = 42
    scene.frame_set(7)
    assert actor.location.x == 42
    denied(anim.nla_edit_track, object_name=actor.name, track_name="Renamed", remove=True)
    denied(
        anim.nla_edit_track,
        object_name=actor.name,
        track_name="Renamed",
        settings={"name": "Protected"},
    )
    call(
        anim.nla_edit_track,
        object_name=actor.name,
        track_name="Renamed",
        settings={"name": "Motion", "mute": False, "lock": True},
    )
    denied(
        anim.nla_edit,
        object_name=actor.name,
        track_name="Motion",
        strip_name="Walk",
        settings={"scale": 2.0},
    )
    call(anim.nla_edit_track, object_name=actor.name, track_name="Motion", settings={"lock": False})
    scene.frame_set(6)
    assert abs(actor.location.x - 5) < 0.01
    evidence = call(anim.inspect, object_name=actor.name)
    assert evidence["active_action"] is None and evidence["nla_enabled"]
    call(
        anim.nla_edit,
        object_name=actor.name,
        track_name="Motion",
        strip_name="Walk",
        settings={"scale": 2.0},
    )
    assert actor.animation_data.nla_tracks["Motion"].strips["Walk"].scale == 2
    call(anim.nla_edit, object_name=actor.name, track_name="Motion", strip_name="Walk", remove=True)
    assert not actor.animation_data.nla_tracks["Motion"].strips
    call(anim.nla_edit_track, object_name=actor.name, track_name="Motion", remove=True)
    assert [t.name for t in actor.animation_data.nla_tracks] == ["Protected"]
    assert not protected.mute and not protected.lock
    assert bpy.data.actions.get(action.name) == action

    for kind in ("REPEAT", "SIMULATION"):
        group = f"Artist {kind}"

        def graph(handler, group=group, **params):
            return call(handler, group_name=group, **params)

        graph(gn.create_graph)
        graph(
            gn.zone_create,
            zone_type=kind,
            input_name="Zone In",
            output_name="Zone Out",
            iterations=3,
        )
        graph(gn.zone_item_add, output_name="Zone Out", socket_type="FLOAT", name="Amount")
        tree = bpy.data.node_groups[group]
        assert tree.nodes["Zone In"].paired_output == tree.nodes["Zone Out"]
        graph(gn.set_node_input, node_name="Zone In", socket_name="Amount", value=2.5)
        graph(
            gn.link_nodes,
            from_node="Zone In",
            from_socket="Amount",
            to_node="Zone Out",
            to_socket="Amount",
        )
        denied(
            gn.zone_item_edit,
            group_name=group,
            output_name="Zone Out",
            name="Amount",
            operation="REMOVE",
        )
        socket_id = tree.nodes["Zone In"].inputs["Amount"].identifier
        graph(
            gn.zone_item_edit,
            output_name="Zone Out",
            name="Amount",
            operation="RENAME",
            new_name="Speed",
        )
        graph(gn.zone_item_edit, output_name="Zone Out", name="Speed", operation="MOVE", to_index=0)
        items = (
            tree.nodes["Zone Out"].repeat_items
            if kind == "REPEAT"
            else tree.nodes["Zone Out"].state_items
        )
        assert [item.name for item in items] == ["Speed", "Geometry"]
        assert tree.nodes["Zone In"].inputs["Speed"].default_value == 2.5
        assert tree.nodes["Zone In"].inputs["Speed"].identifier == socket_id
        assert tree.nodes["Zone Out"].inputs["Speed"].is_linked
        denied(
            gn.zone_item_edit,
            group_name=group,
            output_name="Zone Out",
            name="Speed",
            operation="RENAME",
            new_name="Geometry",
        )
        graph(
            gn.unlink_nodes,
            from_node="Zone In",
            from_socket="Speed",
            to_node="Zone Out",
            to_socket="Speed",
        )
        graph(gn.zone_item_edit, output_name="Zone Out", name="Speed", operation="REMOVE")
        assert [item.name for item in items] == ["Geometry"]
        assert tree.nodes["Zone Out"].inputs["Geometry"].is_linked
        denied(
            gn.zone_item_edit,
            group_name=group,
            output_name="Zone Out",
            name="Geometry",
            operation="REMOVE",
        )
        graph(gn.add_node, node_type="GeometryNodeTransform", name="Step")
        graph(gn.set_node_input, node_name="Step", socket_name="Translation", value=[1, 0, 0])
        for a, b in (
            ("Group Input", "Zone In"),
            ("Zone In", "Step"),
            ("Step", "Zone Out"),
            ("Zone Out", "Group Output"),
        ):
            graph(
                gn.link_nodes,
                from_node=a,
                from_socket="Geometry",
                to_node=b,
                to_socket="Geometry",
                replace_existing=True,
            )
        obj = bpy.data.objects.new(group, cube.data.copy())
        scene.collection.objects.link(obj)
        graph(gn.attach_graph, object_name=obj.name, modifier_name="Zones")
        scene.frame_set(1)
        bpy.context.view_layer.update()
        evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        coords = [v.co.x for v in evaluated.data.vertices]
        assert len(coords) == 8
        if kind == "REPEAT":
            assert abs(min(coords) - 2) < 1e-5 and abs(max(coords) - 4) < 1e-5, coords
            denied(
                gn.set_node_input,
                group_name=group,
                node_name="Zone In",
                socket_name="Iterations",
                value=65,
            )
        else:
            initial_x = min(coords)
            scene.frame_set(2)
            evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
            assert abs(min(v.co.x for v in evaluated.data.vertices) - initial_x - 1) < 1e-5
        denied(gn.remove_node, group_name=group, node_name="Zone In")
        graph(gn.zone_remove, output_name="Zone Out")
        assert tree.nodes.get("Zone In") is None and tree.nodes.get("Zone Out") is None

    mesh = bpy.data.meshes.new("Cloth Fixture")
    mesh.from_pydata(
        [(x / 3, y / 3, 2) for y in range(4) for x in range(4)],
        [],
        [
            (y * 4 + x, y * 4 + x + 1, (y + 1) * 4 + x + 1, (y + 1) * 4 + x)
            for y in range(3)
            for x in range(3)
        ],
    )
    cloth = bpy.data.objects.new("Cloth Fixture", mesh)
    scene.collection.objects.link(cloth)
    cp = {"object_name": cloth.name, "modifier_name": "Cloth"}
    call(simulation.cloth_add, **cp)
    call(simulation.configure, **cp, settings={"mass": 0.4, "quality": 2})
    scene.frame_set(7, subframe=.25)
    baked = call(simulation.cache, **cp, operation="BAKE", frame_start=1, frame_end=3)
    assert baked["cache"]["baked"] and (scene.frame_current, scene.frame_subframe) == (7, .25)
    scene.frame_set(3)
    evaluated = cloth.evaluated_get(bpy.context.evaluated_depsgraph_get())
    print("CLOTH_FRACTIONAL_LAST_FRAME_FIRST " + json.dumps({
        "blender": bpy.app.version_string, "min_z": min(v.co.z for v in evaluated.data.vertices),
        "cache_result": baked}), flush=True)
    fractional_coordinates = [tuple(vertex.co) for vertex in evaluated.data.vertices]
    assert min(v.co.z for v in evaluated.data.vertices) < 1.999
    call(simulation.cache, **cp, operation="FREE")
    assert not cloth.modifiers["Cloth"].point_cache.is_baked
    control = bpy.data.objects.new("Cloth Integer Control", mesh.copy())
    scene.collection.objects.link(control)
    control_params = {"object_name": control.name, "modifier_name": "Cloth"}
    call(simulation.cloth_add, **control_params)
    call(simulation.configure, **control_params, settings={"mass": 0.4, "quality": 2})
    scene.frame_set(7, subframe=0.)
    call(simulation.cache, **control_params, operation="BAKE", frame_start=1, frame_end=3)
    scene.frame_set(3)
    evaluated_control = control.evaluated_get(bpy.context.evaluated_depsgraph_get())
    control_coordinates = [tuple(vertex.co) for vertex in evaluated_control.data.vertices]
    print("CLOTH_MATCHED_TIME_PROBE " + json.dumps({
        "blender": bpy.app.version_string,
        "fractional_min_z": min(co[2] for co in fractional_coordinates),
        "integer_min_z": min(co[2] for co in control_coordinates),
        "max_coordinate_delta": max(abs(a-b) for first, second in zip(fractional_coordinates, control_coordinates, strict=True)
                                    for a, b in zip(first, second, strict=True))}), flush=True)
    assert fractional_coordinates == control_coordinates
    call(simulation.cache, **control_params, operation="FREE")
    cache_callbacks = []

    def revoke_during_bake(current_scene, *args):
        if cloth.modifiers["Cloth"].point_cache.is_baking:
            cache_callbacks.append(current_scene.frame_current)
            allowed["EDIT_SCENE"] = False

    scene.frame_set(7, subframe=.25)
    bpy.app.handlers.frame_change_pre.append(revoke_during_bake)
    try:
        try:
            call(simulation.cache, **cp, operation="BAKE", frame_start=1, frame_end=3)
        except BridgeError as error:
            assert error.code == "PERMISSION_DENIED", error
            assert error.context["cache_operation_started"] and error.context["possible_mutation"]
            assert not error.context["frame_recovery"]["attempted"]
            assert cloth.modifiers["Cloth"].point_cache.is_baked
        else:
            raise AssertionError("Live frame-handler permission revocation was ignored")
    finally:
        bpy.app.handlers.frame_change_pre.remove(revoke_during_bake)
        allowed["EDIT_SCENE"] = True
    assert cache_callbacks
    call(simulation.cache, **cp, operation="FREE")
    scene.frame_set(7, subframe=.25)
    print("CLOTH_LIVE_CALLBACK_GUARD_OK " + json.dumps({
        "blender": bpy.app.version_string, "revoked_at_frames": cache_callbacks,
        "late_bake_retained_for_explicit_free": True,
        "denied_compensation_started": False}), flush=True)
    cloth.modifiers["Cloth"].point_cache.use_disk_cache = True
    # Blender can refuse to enable disk caching for an unsaved fixture.
    if cloth.modifiers["Cloth"].point_cache.use_disk_cache:
        denied(simulation.cache, **cp, operation="BAKE")
    cloth.modifiers["Cloth"].point_cache.use_disk_cache = False

    call(compositor.create, scene_name=scene.name)

    def comp(operation, **params):
        return call(compositor.edit, scene_name=scene.name, operation=operation, **params)

    comp("ADD", node_type="CompositorNodeRGB", node_name="Red")
    tree = (
        scene.compositing_node_group
        if hasattr(scene, "compositing_node_group")
        else scene.node_tree
    )
    color_socket = tree.nodes["Red"].outputs[0].name
    comp("OUTPUT", node_name="Red", socket_name=color_socket, value=[1, 0, 0, 1])
    output = next(
        n for n in tree.nodes if n.bl_idname in {"NodeGroupOutput", "CompositorNodeComposite"}
    )
    comp(
        "LINK",
        from_node="Red",
        from_socket=color_socket,
        to_node=output.name,
        to_socket="Image",
        replace_existing=True,
    )
    denied(
        compositor.edit,
        scene_name=scene.name,
        operation="ADD",
        node_type="CompositorNodeOutputFile",
        node_name="Unsafe",
    )
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 1
    scene.cycles.use_denoising = False
    scene.render.resolution_x = scene.render.resolution_y = 64
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "Standard"
    path = ROOT / "build" / f"artist-compositor-{bpy.app.version[0]}.png"
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)
    image = bpy.data.images.load(str(path), check_existing=False)
    pixel = list(image.pixels[:4])
    assert pixel[0] > 0.9 and pixel[1] < 0.01 and pixel[2] < 0.01, pixel
    assert [o.name for o in bpy.context.selected_objects] == selected
    assert bpy.context.view_layer.objects.active == active
    print(
        json.dumps(
            {
                "artist_smoke": "PASS",
                "blender": bpy.app.version_string,
                "domains": ["weights", "drivers", "NLA", "zones", "cloth_cache", "compositor"],
                "compositor_pixel": pixel,
                "cloth_fractional_control_equal": True,
                "cloth_late_permission_revocation_verified": True,
                "render": str(path),
            }
        )
    )


try:
    main()
finally:
    blender_codex_bridge.unregister()
