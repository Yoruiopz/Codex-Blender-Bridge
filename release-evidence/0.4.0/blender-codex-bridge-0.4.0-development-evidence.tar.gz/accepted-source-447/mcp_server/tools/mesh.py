"""Lazily-enabled mesh inspection and selection-scoped editing wrappers."""

from __future__ import annotations

from typing import Annotated, Any

from pydantic import Field, StrictBool, StrictFloat, StrictInt, StrictStr

from ..tool_registry import ToolRegistry
from ._common import MCPToolBinding, params


class MeshTools:
    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry

    async def mesh_set_face_attributes(self, object_name: StrictStr, selection_id: StrictStr,
                                       smooth: StrictBool | None = None,
                                       material_index: Annotated[StrictInt, Field(ge=0, le=255)] | None = None) -> Any:
        """Set reviewed face attributes on 1-20,000 non-hidden faces in one active local single-user Edit Mode mesh. Requires a fresh face selection reference. smooth changes polygon shading, not custom/split normals; material_index uses a non-empty existing object slot and additionally requires live EDIT_MATERIALS. No material is created, copied or edited. Readback and scoped failure restoration are measured; recheck topology/UVs/material assignment, inspect rollback evidence and capture the appearance."""
        return await self.registry.call("mesh.set_face_attributes", params(object_name=object_name,
            selection_id=selection_id, smooth=smooth, material_index=material_index))

    async def mesh_analyze(
        self, object_name: str, distance_tolerance: StrictFloat = 1e-6,
        max_triangles: StrictInt = 8192, max_pair_tests: StrictInt = 250_000, max_reports: StrictInt = 64,
    ) -> Any:
        """Read-only whole-base-mesh topology, adjacent face-winding and native-triangle contact diagnostics. Separates positive-length crossings, boundary contacts and positive-area near-coplanar overlaps; shared non-coplanar topology edges and point-only contacts are excluded. Object/Edit Mode, including live shared mesh data. Tolerance is world units, not meters. At most 20,000 triangles / 1,000,000 pair tests / 256 examples per category. Degenerate, precision-limited, near-parallel ambiguous and budget-limited evidence stays incomplete. No outward/custom-normal, evaluated geometry, solid containment or other-object guarantee. Capture and compare the brief after structural checks."""
        return await self.registry.call("mesh.analyze", params(
            object_name=object_name, distance_tolerance=distance_tolerance, max_triangles=max_triangles,
            max_pair_tests=max_pair_tests, max_reports=max_reports,
        ))

    async def mesh_edge_ring_inspect(
        self, object_name: str, seed_edge_index: StrictInt, selection_id: str | None = None,
        cuts: StrictInt = 1, offset: StrictInt = 0, max_items: StrictInt = 100,
    ) -> Any:
        """Read-only paginated quad-ring preview on one active Edit Mode mesh. Seed propagation includes unselected edges/faces. Returns measured edge centers, open/closed state and expected counts for 1-32 cuts. Stops with explicit errors on hidden/non-quad/non-manifold/self-crossing scope. At most 4,096 ring edges; 256 per page. Does not reserve the mesh."""
        return await self.registry.call("mesh.edge_ring_inspect", params(
            object_name=object_name, seed_edge_index=seed_edge_index, selection_id=selection_id,
            cuts=cuts, offset=offset, max_items=max_items,
        ))

    async def mesh_loop_cut(
        self, object_name: str, seed_edge_index: StrictInt, selection_id: str, cuts: StrictInt = 1,
    ) -> Any:
        """Cut the entire connected quad ring, not just selected faces. Preview with edge_ring_inspect first; a fresh edge reference containing the seed is required. Even spacing, no slide/smoothing. Requires a local single-user active Edit Mode mesh without shape keys; rejects hidden/non-quad/non-manifold/self-crossing scope and output above 200,000 elements. Reinspect topology/attributes and capture wireframe afterwards."""
        return await self.registry.call("mesh.loop_cut", params(
            object_name=object_name, seed_edge_index=seed_edge_index, selection_id=selection_id, cuts=cuts,
        ))

    async def mesh_bridge_loops(
        self, object_name: str, selection_id: str, twist_offset: StrictInt = 0, material_index: StrictInt = 0,
    ) -> Any:
        """Bridge exactly two disjoint closed selected/referenced boundary or wire loops (3-1,024 edges each) on one local single-user active Edit Mode mesh without shape keys. Equal loops produce quads, unequal loops a native triangulated strip. Twist magnitude must be smaller than both loop sizes; nonzero twist for unequal loops returns NOT_IMPLEMENTED because native Blender ignores it. No merge. New faces use the requested material slot and zero, unpinned UVs. Verify correspondence/normals/crossings visually and unwrap; no automatic twist optimization."""
        return await self.registry.call("mesh.bridge_loops", params(
            object_name=object_name, selection_id=selection_id, twist_offset=twist_offset, material_index=material_index,
        ))

    async def mesh_subdivide_selected(
        self, object_name: str, cuts: int = 1, selection_id: str | None = None,
    ) -> Any:
        """Subdivide selected edges on one local single-user active Edit Mode mesh; no smoothing. Cuts 1-32, selection <=20,000, conservative total-element budget 200,000. Adjacent faces change too; reinspect topology and attributes."""
        return await self.registry.call("mesh.subdivide_selected", params(
            object_name=object_name, cuts=cuts, selection_id=selection_id,
        ))

    async def mesh_merge_by_distance(
        self, object_name: str, distance: float = 0.0001, selection_id: str | None = None,
    ) -> Any:
        """Weld only selected vertices on one local single-user active Edit Mode mesh. Distance is local-space (1e-12 to 1e6), not world-space. Incident faces/edges may collapse and attributes may reconcile; reinspect. No object/data-block deletion."""
        return await self.registry.call("mesh.merge_by_distance", params(
            object_name=object_name, distance=distance, selection_id=selection_id,
        ))

    async def mesh_fill_holes(
        self, object_name: str, material_index: int = 0, selection_id: str | None = None,
    ) -> Any:
        """Cap complete disjoint boundary-edge loops (3-1,024 sides) on one local single-user active Edit Mode mesh. No wire/interior/branched selection, grid or bridge. New n-gon faces use the requested material slot and zero UVs; unwrap and visually verify them."""
        return await self.registry.call("mesh.fill_holes", params(
            object_name=object_name, material_index=material_index, selection_id=selection_id,
        ))

    async def mesh_create(
        self,
        object_name: str,
        mesh_name: str,
        vertices: list[list[float]],
        edges: list[list[int]] | None = None,
        faces: list[list[int]] | None = None,
        collection_name: str | None = None,
        location: list[float] | None = None,
        rotation: list[float] | None = None,
        scale: list[float] | None = None,
        rotation_mode: str = "XYZ",
        face_smooth: Annotated[list[StrictBool], Field(max_length=100_000)] | None = None,
    ) -> Any:
        """Create an arbitrary mesh from fully prevalidated bounded topology arrays. Optional face_smooth is one strict boolean per input face (up to 100,000), applied and read back before linking the new object. Omission uses native flat-face defaults. This is creation-time shading, not custom/split-normal editing. Verify topology, silhouette and shading after creation."""

        return await self.registry.call(
            "mesh.create",
            params(
                object_name=object_name,
                mesh_name=mesh_name,
                vertices=vertices,
                edges=edges,
                faces=faces,
                collection_name=collection_name,
                location=location,
                rotation=rotation,
                scale=scale,
                rotation_mode=rotation_mode,
                face_smooth=face_smooth,
            ),
        )

    async def mesh_inspect(self, object_name: str | None = None) -> Any:
        """Inspect compact mesh and topology statistics."""

        return await self.registry.call(
            "mesh.inspect", params(object_name=object_name)
        )

    async def mesh_recalculate_normals(
        self,
        object_name: str | None = None,
        inside: bool = False,
        selection_only: bool = True,
        selection_id: str | None = None,
    ) -> Any:
        """Recalculate mesh normals for the selection or whole mesh."""

        return await self.registry.call(
            "mesh.recalculate_normals",
            params(
                object_name=object_name,
                inside=inside,
                selection_only=selection_only,
                selection_id=selection_id,
            ),
        )

    async def mesh_delete_selected(
        self,
        object_name: str | None = None,
        element_type: str = "VERT",
        selection_id: str | None = None,
    ) -> Any:
        """Delete selected VERT, EDGE, or FACE elements."""

        return await self.registry.call(
            "mesh.delete_selected",
            params(
                object_name=object_name,
                element_type=element_type,
                selection_id=selection_id,
            ),
        )

    async def mesh_dissolve_selected(
        self,
        object_name: str | None = None,
        use_verts: bool = False,
        use_face_split: bool = False,
        selection_id: str | None = None,
    ) -> Any:
        """Dissolve selected elements while preserving surrounding surface where possible."""

        return await self.registry.call(
            "mesh.dissolve_selected",
            params(
                object_name=object_name,
                use_verts=use_verts,
                use_face_split=use_face_split,
                selection_id=selection_id,
            ),
        )

    async def mesh_extrude_selected(
        self,
        offset: list[float],
        object_name: str | None = None,
        selection_id: str | None = None,
    ) -> Any:
        """Extrude selected geometry by a three-component local-space offset."""

        return await self.registry.call(
            "mesh.extrude_selected",
            params(
                object_name=object_name,
                offset=offset,
                selection_id=selection_id,
            ),
        )

    async def mesh_inset_selected(
        self,
        thickness: float,
        depth: float = 0.0,
        object_name: str | None = None,
        selection_id: str | None = None,
    ) -> Any:
        """Inset selected faces by explicit thickness and depth."""

        return await self.registry.call(
            "mesh.inset_selected",
            params(
                object_name=object_name,
                thickness=thickness,
                depth=depth,
                selection_id=selection_id,
            ),
        )

    async def mesh_bevel_selected(
        self,
        width: float,
        segments: int = 1,
        affect: str = "EDGES",
        object_name: str | None = None,
        selection_id: str | None = None,
    ) -> Any:
        """Bevel selected edges or vertices with explicit width and segments."""

        return await self.registry.call(
            "mesh.bevel_selected",
            params(
                object_name=object_name,
                width=width,
                segments=segments,
                affect=affect,
                selection_id=selection_id,
            ),
        )

    async def mesh_mark_seams(
        self, object_name: str, seam: bool = True, selection_id: str | None = None,
    ) -> Any:
        """Mark/clear selected edge UV seams on a single-user active Edit Mode mesh; preserve geometry, UV coordinates and selection."""
        return await self.registry.call(
            "mesh.mark_seams", params(object_name=object_name, seam=seam, selection_id=selection_id),
        )

    def bindings(self) -> tuple[MCPToolBinding, ...]:
        return (
            MCPToolBinding("mesh.set_face_attributes", self.mesh_set_face_attributes, self.mesh_set_face_attributes.__doc__ or ""),
            MCPToolBinding("mesh.analyze", self.mesh_analyze, self.mesh_analyze.__doc__ or ""),
            MCPToolBinding("mesh.edge_ring_inspect", self.mesh_edge_ring_inspect, self.mesh_edge_ring_inspect.__doc__ or ""),
            MCPToolBinding("mesh.loop_cut", self.mesh_loop_cut, self.mesh_loop_cut.__doc__ or ""),
            MCPToolBinding("mesh.bridge_loops", self.mesh_bridge_loops, self.mesh_bridge_loops.__doc__ or ""),
            MCPToolBinding("mesh.subdivide_selected", self.mesh_subdivide_selected, self.mesh_subdivide_selected.__doc__ or ""),
            MCPToolBinding("mesh.merge_by_distance", self.mesh_merge_by_distance, self.mesh_merge_by_distance.__doc__ or ""),
            MCPToolBinding("mesh.fill_holes", self.mesh_fill_holes, self.mesh_fill_holes.__doc__ or ""),
            MCPToolBinding("mesh.mark_seams", self.mesh_mark_seams, self.mesh_mark_seams.__doc__ or ""),
            MCPToolBinding("mesh.create", self.mesh_create, self.mesh_create.__doc__ or ""),
            MCPToolBinding("mesh.inspect", self.mesh_inspect, self.mesh_inspect.__doc__ or ""),
            MCPToolBinding("mesh.recalculate_normals", self.mesh_recalculate_normals, self.mesh_recalculate_normals.__doc__ or ""),
            MCPToolBinding("mesh.delete_selected", self.mesh_delete_selected, self.mesh_delete_selected.__doc__ or ""),
            MCPToolBinding("mesh.dissolve_selected", self.mesh_dissolve_selected, self.mesh_dissolve_selected.__doc__ or ""),
            MCPToolBinding("mesh.extrude_selected", self.mesh_extrude_selected, self.mesh_extrude_selected.__doc__ or ""),
            MCPToolBinding("mesh.inset_selected", self.mesh_inset_selected, self.mesh_inset_selected.__doc__ or ""),
            MCPToolBinding("mesh.bevel_selected", self.mesh_bevel_selected, self.mesh_bevel_selected.__doc__ or ""),
        )
