# Blender transport protocol

This document defines the local protocol between the standalone MCP server and the Blender add-on. It is not the MCP protocol itself.

Normative terms **MUST**, **MUST NOT**, **SHOULD**, and **MAY** describe the version 1 contract used by release 0.2.0. Unsupported methods/options fail explicitly rather than being emulated.

## Transport

- Transport: TCP.
- Bind address: the literal IPv4 loopback address `127.0.0.1`.
- Framing: newline-delimited JSON (NDJSON).
- Encoding: UTF-8 without a byte-order mark.
- One frame is one complete JSON object followed by `\n`. Receivers SHOULD accept `\r\n`.
- JSON text MUST NOT contain a literal unescaped newline inside a frame.
- Both sides MUST impose a finite frame-size limit and close or reject an oversized frame without attempting unbounded buffering. V1 allows at most 4 MiB (`4 * 1024 * 1024` bytes) of UTF-8 JSON payload; the trailing LF or CRLF delimiter is not counted.
- The add-on MUST NOT fall back to `0.0.0.0`, `::`, a hostname resolving to a non-loopback address, or a LAN address.

TCP provides byte ordering, not message framing; implementations must buffer partial reads and may receive several newline-terminated frames in one read.

## Protocol version

V1 uses the string version:

```json
"1.0"
```

Every request, response, and event includes `protocol_version`. The major component defines compatibility. A peer receiving an unsupported major version returns `UNSUPPORTED_PROTOCOL_VERSION` when the request ID can be recovered, then may close the connection.

Backward-compatible additions within major version 1 may add optional fields, error context, event kinds, methods, or enum values. Receivers MUST ignore unknown optional fields. Removing a field, changing its type/meaning, or changing framing requires a new major version.

The bridge does not currently require a separate handshake. `bridge.status` returns both peer/application version information and is the normal compatibility probe.

## Request envelope

```json
{
  "protocol_version": "1.0",
  "id": "req_01HZX6K9N8Q2",
  "method": "scene.inspect",
  "params": {
    "include_hidden": false,
    "max_objects": 200
  },
  "timestamp": "2026-08-07T20:15:01.125Z"
}
```

Fields:

| Field | Required | Contract |
| --- | --- | --- |
| `protocol_version` | yes | Version string described above. |
| `id` | yes | Non-empty caller-generated string, unique among active requests on that connection. It is opaque and echoed exactly. |
| `method` | yes | Registered dotted tool name resolved by exact registry lookup. The dispatcher never imports or reflects from this string; only the separately armed `python.execute` handler accepts source code. |
| `params` | yes | JSON object. Use `{}` when a method has no arguments. |
| `timestamp` | no | RFC 3339 UTC timestamp for diagnostics; it is not used for authorization or deadline calculation. |
| `timeout_ms` | no | Optional positive end-to-end caller budget, capped by local policy. Absence uses the server default. |

String envelope bounds are 256 characters for `id`, 128 for `method`, and 128 for `timestamp`. Tool-specific strings have their own narrower or Blender-defined limits where appropriate. A response whose encoded JSON would exceed the payload cap is replaced by a compact correlated `MESSAGE_TOO_LARGE` failure.

Unknown top-level optional fields are ignored for V1 forward compatibility. Invalid types, a missing required field, a duplicate active ID at the MCP client, or an unknown method produce an explicit failure.

## Successful response

```json
{
  "protocol_version": "1.0",
  "id": "req_01HZX6K9N8Q2",
  "ok": true,
  "timestamp": "2026-08-07T20:15:01.148+00:00",
  "result": {
    "scene": "Scene",
    "objects": [],
    "truncated": false
  }
}
```

Requirements:

- `id` exactly matches the request.
- `ok` is `true`.
- `protocol_version` is the add-on's response protocol version and `timestamp` records response creation in UTC.
- `result` is present and JSON-safe; it may be `null` only when the method contract allows it.
- `error` is absent.
- A mutating tool returns relevant post-operation state and affected-object metadata, not merely `true`.
- Bounded results expose truncation explicitly.

## Error response

```json
{
  "protocol_version": "1.0",
  "id": "req_01HZX6K9N8Q2",
  "ok": false,
  "timestamp": "2026-08-07T20:15:01.148+00:00",
  "error": {
    "code": "OBJECT_NOT_FOUND",
    "message": "Object 'Dragon_Left' does not exist.",
    "context": {
      "available_similar_objects": ["Dragon", "Dragon.Wing.L"]
    },
    "retryable": false
  }
}
```

Requirements:

- `ok` is `false` and `error` is present; `result` is absent.
- `message` is concise, user-safe, and actionable.
- `context`, when present, is a bounded object and must not contain secrets or an unrestricted traceback.
- `retryable`, when present, indicates whether retrying without changing request/user state may plausibly succeed. It is advisory and defaults to `false` when omitted.
- If malformed JSON prevents recovery of `id`, the implementation may use `id: null` for a parse error and then continue or close according to local safety policy.
- One accepted request receives at most one terminal response.

### Error codes

| Code | Meaning | Usually retryable |
| --- | --- | --- |
| `MALFORMED_JSON` | Frame is not valid UTF-8 JSON. | no |
| `INVALID_REQUEST` | Envelope is missing/has invalid fields. | no |
| `UNSUPPORTED_PROTOCOL_VERSION` | Peer major version is unsupported. | no |
| `MESSAGE_TOO_LARGE` | Frame exceeds the 4 MiB transport cap. | with a smaller request |
| `METHOD_NOT_FOUND` | No registered Blender method exists. | no |
| `INVALID_ARGUMENT` | Method parameters fail validation. | no |
| `OBJECT_NOT_FOUND` | Named/stable object reference is absent. | after reinspect |
| `MATERIAL_NOT_FOUND` | Named material is absent. | after reinspect |
| `INVALID_MODE` | Blender mode/context cannot perform the operation. | after context change |
| `INVALID_SELECTION` | Selection is missing, stale, or incompatible. | after reselection |
| `PERMISSION_DENIED` | Blender-side permission is disabled. | after user consent |
| `TOOLSET_DISABLED` | Domain toolset is not enabled. | after enablement |
| `AGENT_PAUSED` | Agent modifications are paused. | yes, after resume |
| `EMERGENCY_STOPPED` | Emergency stop prevents modifications. | after explicit reset |
| `BLENDER_CONTEXT_ERROR` | Required area/region/context is unavailable. | context-dependent |
| `OPERATION_FAILED` | Handler failed after validation. | context-dependent |
| `TIMEOUT` | Deadline expired before a terminal result. | context-dependent |
| `NOT_IMPLEMENTED` | Method/option is recognized but unsupported. | no |
| `SERVER_ERROR` | Queue saturation, shutdown, or an unexpected server failure. | context-dependent |

Public codes should remain stable. Method-specific context may include missing permission names, supported modes/options, similar object names, safe limits, or a local diagnostic ID.

Blender tool metadata may additionally expose `protected_scope_reviewed`. This states
that the registered modifying tool has a reviewed live affected-scope resolver for
opt-in task-plan protection; it grants no permission and is not whole-scene or visual
preservation certification. Under active protection, unreviewed modifying tools return
`NOT_IMPLEMENTED` before handler/checkpoint entry. Existing V1 envelopes are unchanged.
Runtime references, previews and policy generations are not serialized plan authority;
see [task plans](task-plans.md) for the bounded static-prop contract.
Prepared internal handler invocation tracks in-flight mutators on Blender's main
thread; protection cannot be enabled over one. Executor, direct registry dispatch
and batch steps use that wrapper. Calling a trusted handler directly is not a
remote protocol entry point and does not replace registered preflight.
Every handler entry has a final internal lifetime/toolset/identity check after
preflight callbacks. Pause and emergency-stop checks apply to the exact retained
modifying ToolSpec. Readonly inspection, status and nonmodifying controls remain
eligible while paused or stopped, subject to live permissions and any active Scene
reservation. A readonly registration does not certify that its native getters or
evaluation are passive. Its diagnostic entry counter is runtime-only. The
existing explicit local recovery override permits pause/stop recovery only for
the two canonical recovery methods; it never bypasses caller lifetime/toolsets.

Known artist context reads can synchronize a ViewLayer before the requested
handler starts, including before a subsequent permission denial. Failed entries
may add a bounded `error.context.entry_effects` record:

```json
{"view_layer_sync_possible":true,"context_change_measured":false,"handler_entered":false,"reinspection_required":true}
```

This optional record contains exactly four booleans and no denied scene data.
`handler_entered` refers to the exact canonical handler; nested reads can make
context effects possible without entering that handler. It is conservative
evidence of a known synchronizing read, not measurement or prevention of a
selection change. The primary error code/message and existing execution/mutation
facts retain their meanings; `verification_required` becomes true. Generic failed
history and runtime artist step receipts retain the same evidence before terminal
recording. A step may remain `rejected` with `handler_entered=false`. Unmarked
legacy records omit the addition; absence is not a passive-context guarantee.
See [entry context effects](entry-context-effects.md).

Unreleased `project.save` retains its optional `filepath`, permissions and V1
registration but returns `NOT_IMPLEMENTED` for Save and Save As after live grants
and the canonical final stop check, before any Blender/path/save access. Expected
errors report measured no-write facts and do not finalize an older editor session.
Prior alpha saving is unavailable until [native side effects are bounded](project-save-safety.md).

## Events

Events reserve a V1-compatible path for progress and lifecycle information. They are non-terminal and correlated where applicable.

```json
{
  "protocol_version": "1.0",
  "type": "event",
  "event": "progress",
  "request_id": "req_01HZX6K9N8Q2",
  "sequence": 1,
  "timestamp": "2026-08-07T20:15:01.600Z",
  "data": {
    "stage": "capturing",
    "completed": 1,
    "total": 3,
    "message": "Capturing front view"
  }
}
```

Event fields:

- `type` is always `event`.
- `event` is a stable event kind such as `progress`, `log`, `state_changed`, or `checkpoint_created`.
- `request_id` is present for request-scoped events and absent/null for connection-wide events.
- `sequence` increases monotonically within one request so clients can order progress.
- `data` is a bounded JSON object.

Events never replace the terminal response. A client must determine request completion only from the matching success/error response. Release 0.2.0 emits no events and its client is not required to consume them. Event emission must not be enabled until both peers recognize event envelopes; event-capable clients then ignore unknown event kinds. Callers must not require progress events in V1.

## Timeouts and cancellation

Timeouts exist at several layers:

1. MCP tool deadline.
2. MCP-server/Blender-client request deadline.
3. Add-on queue-wait/execution deadline.
4. Socket read/connect timeouts used for lifecycle detection.

The effective request budget is the smallest configured applicable deadline. `timeout_ms`, if accepted, is capped by policy and starts when the MCP server dispatches the Blender request. Queue wait consumes this budget.

An expired command that has not started MUST be removed/rejected without mutation. For an active Blender operation, a caller timeout does **not** imply rollback: most Blender calls cannot be safely interrupted at arbitrary bytecode points. Handlers should be short; long-running handlers need explicit cooperative safe points and cancellation semantics. `python.execute` adds a 0.1-30 second cooperative Python trace deadline, but long-running Blender C operations cannot always be preempted.

If a response arrives after the MCP caller has timed out, the Blender client discards it for correlation purposes and logs the late result. A mutation that may have completed must remain visible in operation history so the next agent action reinspects state. IDs are not immediately reused.

Caller cancellation closes the shared client connection. The add-on then atomically cancels requests that are still pending and fails the other in-flight calls; a Blender operation that had already crossed the running boundary is not interrupted and remains visible in operation history. The next call reconnects and must reinspect state.

Unreleased bounded object and rig mutations also check canonical request ownership
after their final live permission providers and content comparisons, immediately
before each owned field/context write, allocation, removal or native application.
This final safe point reads transport lifetime Events, the executor's exact queued
request check, any scheduler job deadline, toolset membership and pause/emergency
state. It does not rerun permission providers or arbitrary cancellation callbacks
after the content proof. Lost authority prevents subsequent writes and automatic
object compensation; already completed native calls remain possible mutations.
These are internal services, not caller-supplied protocol fields or universal
coverage of every modifying tool. Existing envelopes and terminal-response rules
are unchanged.

The 0.3.0 implementation adds cooperative safe points for `batch.execute`.
Disconnect/timeout signals a running request without attempting to interrupt its current
Blender call. Before each subsequent child step, the batch checks that signal, the queue
deadline, its own bounded budget, and live toolset/permission/pause/emergency gates.
The local batch budget is rechecked after live step preflight, at each initial
checkpoint write, and immediately before child handler entry. A slow provider
cannot consume that budget and still start the next child. The budget is
cooperative: a native call already running remains non-preemptible.
Failure returns bounded completed-step evidence with `rollback_performed: false` and
retains the logical recovery marker. No subsequent child is started after a stop is
observed. A C operation already started may still finish after caller timeout. Batch
preflight validates registration and static authorization, not handler arguments or
scene-dependent success; batches are explicitly non-atomic. See [agent workflows](agent-workflows.md).

Only a failure known to occur before a frame was sent carries `executed:false` and may be marked `retryable:true`. A timeout, cancellation, disconnect, or malformed response after sending carries `outcome_unknown:true` where an error can be returned and is never automatically retryable.

## Concurrency and ordering

Unreleased image job starters and `rigid_body.evaluate_job_start` return bounded
accepted job descriptors, not completed domain work. Image painting, delivery,
snapshot/recovery and rigid evaluation share the same single-active scheduler.
Trusted in-process lifetime flags are never accepted from wire fields. Job work waits until its
success response is flushed; failed delivery, observed disconnect or expired handoff cancels it.
After handoff, a separate 1–300 second job deadline applies while the owning connection remains
open. Main-thread timer slices service the normal request queue first. `jobs.inspect/list` poll
revisioned phase-local progress and terminal result/error; `jobs.cancel` requests safe-point
cancellation, not rollback. Native publication has its own final checkpoint/history record.
No events, new envelopes or duplicate terminal responses are introduced. A connection reader
preserves bounded partial frames across idle timeouts while active requests/jobs remain; inactive
connections still expire. See [painting jobs](painting-jobs.md) and
[rigid evaluation jobs](rigid-body-evaluation-jobs.md) for domain limits and recovery semantics.

Export/reimport descriptors additionally expose `duration_ms` and bounded `external_effects`.
Published or uncertain disk effects survive cancellation/native undo and are retained in
terminal operation history's optional `job_evidence`, separately from scene undo flags.
Detailed history evidence is redacted from `checkpoint.list` without live `INSPECT_SCENE`;
recovery controls remain callable and locally retained audit records are not changed.
Acceptance history explicitly says delivery is incomplete. A native reimport checkpoint is
finalized synchronously, never held across subsequent cooperative verification ticks. Late
verification failures retain the image for explicit recovery. These are additive method/result
fields, not new envelopes, unsolicited events or terminal responses for the start request.

Managed matched previews may additionally report `external_effects.artifacts`, a bounded
list of flat `filepath`, `file_sha256` and `file_bytes` descriptors, and
`render_result_replaced`. Runtime history copies at most four descriptors, reports
`artifacts_truncated`/`artifacts_incomplete`, and never invents missing hashes or sizes.
The preview tool may impose a smaller count. These facts describe retained files and
Render Result effects separately from scene restoration; native scene undo does not
remove them. They do not grant file access or certify crash durability. Inspection denial
redacts the whole external-effects record, including all nested paths and hashes.

`asset.import` holds an internal exclusive mutation lease from entry admission
through native work, cleanup and checkpoint finalization. Reentrant modifying
calls from permission providers, checkpoint/native callbacks or finalizers fail
before their providers and checkpoints with `OPERATION_FAILED` and
`reason: REENTRANT_MUTATION_BLOCKED`. Reusing a context, request ID or local
recovery override grants no entry. Read-only status/inspection and pause/stop
controls remain eligible under their other live gates; nested status retains the
outer execution display. An independent Scene reservation can restrict inspection.
The canonical executor-to-handler continuation uses a local single-use permit,
never a wire field or context-held grant. Exact lease loss stops subsequent
guarded writes; a primary error retains its identity and receives optional
`exclusive_mutation_lease_drift` evidence. Lifecycle reset cannot unlock an
active native call; only its owning scope can release its exact lease when it
unwinds. Ordinary batch/artist composition and image-job interleaving retain
their existing behavior. This is a structured-entry interlock, not a sandbox
for native handlers or arbitrary Python, a cancellation/preemption guarantee,
or a solution to whole-project serialization.

The [Scene job kernel](scene-job-kernel.md), used by the public rigid evaluation
adapter, retains a reservation across
turns. While it owns the evaluation context, only its exact frozen nonmodifying
status/control specifications may interleave: `bridge.status`, `jobs.inspect`,
`jobs.list`, `jobs.cancel`, `toolsets.list`, `toolsets.enable` and `toolsets.disable`.
They retain their own live permission requirements. Other structured calls,
including evaluation-capable inspection and viewport capture, fail before their
providers/handlers with `OPERATION_FAILED` and
`reason: SCENE_JOB_RESERVATION_BLOCKED`. Replacing a same-name specification does
not enter the frozen allowlist. The local-only `jobs._scene_turn` requires a fresh
scheduler origin; no wire parameter, copied context or recovery flag grants it.
Cached inspection exposes bounded progress/checkpoint/terminal receipts without
evaluating the Scene. `rigid_body.evaluate_preview` fingerprints the exact whole
world, proposed range and job limit; `rigid_body.evaluate_job_start` accepts that
proposal only under renewed Blender authority. The nonbatchable job performs at
most one checkpoint/domain phase per tick and keeps its owned pending checkpoint
across turns. Successful completion restores caller time and retains the proposed
cache range. Stops retain partial effects without automatic restoration or cleanup.
The bounded `native_effects` receipt describes selected declared intervals; it is
not complete native-state evidence. Unresolved Scene receipts remain discoverable
after ordinary 32-entry display-history eviction. This evaluation API performs no
BAKE/conversion and makes no cache-coverage, durability or native-preemption claim.
Its typed Blender RPC native fixture and portable official MCP SDK tests are
separate routes; installed native MCP end-to-end acceptance remains open.

- Multiple requests may be in flight at the transport/client layer.
- Writes on each socket are serialized so NDJSON frames never interleave.
- The Blender main-thread executor processes one command at a time in queue order in 0.2.0.
- The current add-on queue accepts at most 256 pending commands; saturation returns `SERVER_ERROR` rather than growing without bound.
- Completion order can differ from submission order only if a request is rejected/expired before execution or a later protocol-compatible implementation adds explicitly concurrent read paths.
- Callers MUST NOT issue dependent mutations concurrently. A later call should use the verified terminal result of the earlier call.
- Duplicate active IDs are rejected. IDs may be reused only after the previous lifecycle is fully retired, but globally unique IDs are recommended.
- Request order across separate TCP connections is undefined. Clients should prefer one active MCP bridge connection unless multi-client ownership is explicitly implemented.

## Connection lifecycle

1. The Blender user starts the bridge from the add-on panel.
2. The add-on validates the configured literal loopback host, binds, and begins listening.
3. The MCP server connects on demand or startup.
4. `bridge.status` verifies application/protocol versions and current Blender state.
5. Requests flow until either side closes.
6. Disconnect fails unresolved requests with a connection error; it does not stop Blender.
7. Add-on stop/unregister rejects new work, resolves queued requests, closes sockets, and removes its main-thread timer.

Reconnect does not make old selection IDs, pending requests, or connection-scoped state valid. Codex should re-run status/selection inspection.

## Method naming and parameters

Methods use lowercase dotted names:

```text
domain.verb
```

Examples: `scene.inspect`, `transform.translate`, `checkpoint.create`.

Parameter rules:

- Use JSON objects, never positional arrays at the method boundary.
- Distinguish omitted values from explicit `null` only when the schema defines that distinction.
- Reject unknown parameters by default for mutating tools; read tools may adopt explicitly documented forward-compatible behavior.
- Bound strings, arrays, image sizes, traversal depth, pagination limits, and numeric ranges.
- Object references must be explicit names or opaque IDs defined by a tool schema. Normal methods never treat input as code. The sole exception is the exact registered `python.execute` method, whose schema requires the disabled-by-default Python toolset; all four broad permissions `EXECUTE_PYTHON`, `DELETE_OBJECTS`, `ACCESS_EXTERNAL_FILES`, and `SAVE_PROJECT`; `confirm_dangerous=true`; and `expected_effect`, then applies its own code/import/output/deadline policy.

### Unreleased recovery option (backward-compatible)

`checkpoint.undo_last` still requires `confirm_global_undo=true`; its default is one native
global undo. Optional `restore_snapshot=true` instead navigates bounded native history to
the last finalized bridge operation's before-marker, checking cancellation between steps.
The result includes the actual `undo_steps`, `snapshot_marker_verified`, and
`verification_required=true`; it does not assert all scene invariants or user goals were restored.
Failures attempt to return to a guard snapshot and report `return_to_guard_verified` with
possible-mutation evidence. A canceled navigation may perform bounded redo for this recovery;
its terminal failure/history record retains that evidence. No native operation is preempted.

Modifying responses expose optional `operation.undo_boundary_finalized` in addition to
`undo_boundary_created`. A before-boundary alone is not evidence of a finalized recoverable
operation. These additions do not change envelopes, framing or default one-step undo semantics.

Tracked single-mesh Edit Mode intervals may return optional `operation.undo_group` metadata
(`deferred`, `finalized`, `invalidated` or `unavailable`). The before-boundary is captured at
Object Mode entry and the after-boundary on return. A failed modifying call may carry the
same group evidence in its error context. `bridge.status.agent.undo_group` reports a pending
interval. Snapshot restoration returns `recovered_scope` and `group_operation_attempts`;
these do not replace independent verification or change legacy one-step undo behavior.
The dispatcher rechecks cancellation after checkpoint setup before starting the handler.

Optional `checkpoint.list.recovery` and `bridge.status.agent.recovery` expose current native
step/memory settings and conservative `unverified`, `guard_would_exceed_step_limit` or
`expired` status. They do not enumerate native history, grant authorization or guarantee retention.
Known-expired operation targets are pruned; named labels retain separate availability by ID.
Known-expiry/guard-budget refusals occur before guard creation/navigation and report
`execution_started:false`, `scene_undo_performed:false`, and `undo_steps_completed:0`, unless
the call already finalized a pending edit group: that preceding mutation retains
`execution_started:true` and its group/finalized-boundary evidence without a scene undo.
Snapshot creation/finalization fields remain event evidence, not retention guarantees.
See [native recovery availability](native-recovery.md). These optional additions do not
change existing label objects, envelopes, framing, or the default one-step undo contract.

## Serialization conventions

- JSON finite numbers only; `NaN` and infinities are errors or become documented `null`/warning fields.
- Vectors are fixed-length arrays in XYZ order unless named otherwise.
- Matrices, if exposed, state row/column and coordinate-space conventions in their schema.
- Programmatic rotations use radians unless a field explicitly ends in `_degrees`.
- Times are RFC 3339 UTC strings.
- Paths are strings only for tools with external-file/save permission and must be normalized by Blender.
- Binary images are not embedded without a strict size policy. A capture result identifies a bounded artifact representation and its MIME type, dimensions, view, shading, and restoration status.

## Representative calls

Read-only selection inspection:

```json
{"protocol_version":"1.0","id":"req_101","method":"selection.inspect","params":{}}
```

Show the high-level task in Blender's sidebar:

```json
{"protocol_version":"1.0","id":"req_101a","method":"bridge.task.set","params":{"description":"Repair the selected mesh and verify its UVs"}}
```

Create a prevalidated triangle mesh without relying on current selection:

```json
{"protocol_version":"1.0","id":"req_101b","method":"mesh.create","params":{"object_name":"Triangle","mesh_name":"TriangleMesh","vertices":[[0,0,0],[1,0,0],[0,1,0]],"faces":[[0,1,2]]}}
```

This method requires the `mesh` toolset plus `EDIT_MESH` and `TRANSFORM_OBJECTS`. It validates the complete bounded topology before Blender data allocation and returns fresh counts, bounds, transform, and mesh post-state.

Permission denial:

```json
{"protocol_version":"1.0","id":"req_102","method":"object.delete","params":{"object_name":"Cube"}}
{"protocol_version":"1.0","timestamp":"2026-08-08T12:00:00+00:00","id":"req_102","ok":false,"error":{"code":"PERMISSION_DENIED","message":"Blender-side permission denied.","context":{"required":["DELETE_OBJECTS"],"missing_permissions":["DELETE_OBJECTS"]},"retryable":false}}
```

Post-state from a transform:

```json
{
  "protocol_version": "1.0",
  "timestamp": "2026-08-08T12:00:01+00:00",
  "id": "req_103",
  "ok": true,
  "result": {
    "changed": true,
    "object": "Key_Light",
    "location": [0.0, 0.0, 4.5],
    "rotation_mode": "XYZ",
    "rotation_euler": [0.0, 0.0, 0.0],
    "rotation_quaternion": [1.0, 0.0, 0.0, 0.0],
    "scale": [1.0, 1.0, 1.0],
    "dimensions": [0.0, 0.0, 0.0],
    "matrix_world": [
      [1.0, 0.0, 0.0, 0.0],
      [0.0, 1.0, 0.0, 0.0],
      [0.0, 0.0, 1.0, 4.5],
      [0.0, 0.0, 0.0, 1.0]
    ],
    "operation": {
      "operation_id": "op_42",
      "undo_boundary_created": true
    }
  }
}
```

Explicitly armed Python fallback for an otherwise unsupported Blender API operation:

```json
{
  "protocol_version": "1.0",
  "id": "req_104",
  "method": "python.execute",
  "params": {
    "code": "result = {'active_scene': bpy.context.scene.name}",
    "expected_effect": "Read the active scene name without changing project data",
    "confirm_dangerous": true,
    "time_limit_seconds": 2.0
  }
}
```

Transport acceptance does not arm Python by itself. Blender still requires the `python` toolset and all four of `EXECUTE_PYTHON`, `DELETE_OBJECTS`, `ACCESS_EXTERNAL_FILES`, and `SAVE_PROJECT`. Once armed, raw `bpy` bypasses normal structured `EDIT_*` gates. A successful result includes `verification_required: true`. Captured stdout is capped at 64 KiB. Script-result conversion allows at most 4,000 global items, depth 8, 4,000 integer digits, no cyclic/shared container expansion, and 256 KiB serialized. Violating a graph/scalar/byte budget—or encountering an unexpected conversion/size-check failure—replaces the result before transport encoding with `__truncated__` metadata while preserving audit/recovery fields; callers check `result_truncated` and `result_limit_bytes` rather than treating that placeholder as the requested value. A runtime/deadline failure after execution starts includes bounded digest/effect/output/delta evidence, `mutation_outcome_unknown: true`, and `verification_required: true`; it is recorded as a possible mutation with a finalized undo boundary. The Python policy is an accident guard, not a hard security sandbox, and it provides no shell or network tool.

## Security requirements

- Do not place authentication secrets in messages; the V1 TCP transport is local only.
- Never expose the socket using port forwarding, a reverse proxy, container publish flags, or public host binding.
- Dispatch only registered methods. Never use `eval`, reflective method traversal, arbitrary imports, or shell interpolation. Only the separately registered and explicitly armed `python.execute` handler may compile/execute caller source under its bounded policy; normal handlers must not route through it.
- Validate paths and permissions in Blender, even if MCP already validated them.
- Resolve each required permission set from one live Blender policy snapshot. Recheck
  enabled toolsets after permission callbacks; a grant cannot keep a disabled tool active.
  Cooperative image jobs also check owner lifetime, explicit cancellation and deadline
  after their final permission callbacks, before publishing another native mutation.
- Treat every local request as untrusted input for parser, type, range, and size purposes.

See [`security.md`](security.md) for the complete threat model and [`tool-design.md`](tool-design.md) for method-level contracts.
