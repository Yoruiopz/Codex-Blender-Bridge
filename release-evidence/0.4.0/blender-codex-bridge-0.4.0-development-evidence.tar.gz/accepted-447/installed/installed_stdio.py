"""NEW 0.4.0 installed-wheel stdio proof; prepared only, root executes separately."""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import struct
from typing import get_type_hints

import re
import sys
from pathlib import Path
from zipfile import ZipFile

def sha(data):
    return hashlib.sha256(data).hexdigest()


class RecordingClient:
    """Retain SDK response text/structure, not raw wire frames, in the new folder."""
    def __init__(self, client, output):
        self.client = client
        self.receipts = (output / 'rpc-receipts.jsonl').open('x', encoding='utf-8')
        self.index = 0

    def __getattr__(self, name):
        return getattr(self.client, name)

    async def call_tool(self, name, arguments):
        response = await self.client.call_tool(name, arguments)
        self.index += 1
        receipt = {'index': self.index, 'tool': name, 'arguments': arguments,
            'is_error': response.is_error,
            'texts': [item.text for item in response.content if hasattr(item, 'text')],
            'structured_content': response.structured_content}
        self.receipts.write(json.dumps(receipt, allow_nan=False) + '\n')
        self.receipts.flush()
        return response


async def check(output, authority_path):
    assert output == Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('new_prerelease_prepare', output/'prepare.py')
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    helpers.load_prepared(authority_path)
    helpers.require(sys.flags.optimize == 0, 'The retained assertion checks require unoptimized Python')
    # Mandatory authority/preservation checks precede any candidate or SDK import.
    from pydantic import TypeAdapter, ValidationError
    from mcp import Client
    from mcp.client.stdio import StdioServerParameters
    import mcp_server
    assert Path.cwd() == Path('/tmp') and sys.flags.isolated and sys.flags.dont_write_bytecode
    module=Path(mcp_server.__file__).resolve(strict=True)
    prefix=Path(sys.prefix).resolve(strict=True)
    assert module.is_relative_to(prefix) and 'site-packages' in module.parts
    distribution=json.loads((output/'distribution-manifest.json').read_text())
    assert re.fullmatch(r'[0-9a-f]{40}', distribution['commit'])
    assert re.fullmatch(r'[0-9a-f]{40}', distribution['source_tree'])
    assert re.fullmatch(r'[0-9a-f]{64}', distribution['source_sha256'])
    accepted_modules=distribution['expected_module_sha256']
    assert isinstance(accepted_modules, dict) and accepted_modules
    accepted_module_count=len(accepted_modules)
    assert all(isinstance(name,str) and re.fullmatch(r'[0-9a-f]{64}', digest)
        for name,digest in accepted_modules.items())
    assert str(prefix) == distribution['venv']
    assert module == prefix/'lib/python3.12/site-packages/mcp_server/__init__.py'
    wheel=output/'packages/blender_codex_bridge-0.4.0-py3-none-any.whl'
    assert sha(wheel.read_bytes()) == distribution['packages'][wheel.name]
    installed_files={}
    with ZipFile(wheel) as archive:
        expected={name for name in archive.namelist() if name.startswith('mcp_server/') and not name.endswith('/')}
        assert expected == set(accepted_modules) and len(expected) == accepted_module_count
        site=module.parent.parent
        actual={p.relative_to(site).as_posix() for p in module.parent.rglob('*')
                if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
        assert actual == expected, sorted(actual ^ expected)
        for name in sorted(expected):
            assert not (site/name).is_symlink()
            content=(site/name).read_bytes()
            assert content == archive.read(name), name
            installed_files[name]=sha(content)
            assert installed_files[name] == accepted_modules[name], name
    expected_tools_bytes=(output/'expected-tools.json').read_bytes()
    expected_tools_digest=sha(expected_tools_bytes)
    assert expected_tools_digest == distribution['expected_tools_sha256']
    expected_names=json.loads(expected_tools_bytes)
    assert len(expected_names) == len(set(expected_names)) == 266
    assert expected_names == sorted(expected_names)
    assert all(isinstance(name,str) and name for name in expected_names)
    server_python_arguments=['-I','-B','-m','mcp_server','--transport','stdio']
    transport=StdioServerParameters(command=sys.executable,
        args=server_python_arguments, cwd='/tmp',
        env={'PYTHONNOUSERSITE':'1'})
    # These direct installed-wrapper checks use a local stub, never Blender RPC.
    from mcp_server.tools.transforms import TransformTools
    from mcp_server.tools.task_plan import TaskPlanTools
    handlers=(TransformTools.transform_set,TaskPlanTools.task_plan_preview_transform)
    annotation_checks=[]
    for handler in handlers:
        adapter=TypeAdapter(get_type_hints(handler,include_extras=True)['rotation_quaternion'])
        for label,value in (('NaN',[float('nan'),0.,0.,0.]),('positive_infinity',[float('inf'),0.,0.,0.]),
                            ('negative_infinity',[-float('inf'),0.,0.,0.]),('tuple',(1.,0.,0.,0.))):
            try:
                adapter.validate_python(value)
            except ValidationError:
                annotation_checks.append({'wrapper':handler.__name__,'case':label,'rejected':True,
                    'scope':'Direct installed annotation validation; not wire JSON.'})
            else:
                raise AssertionError('Nonfinite or tuple quaternion accepted by installed annotation')
        assert adapter.validate_python([1,0,0,0])==[1.,0.,0.,0.]
    assert len(annotation_checks)==8
    stub_calls=[]
    class StubRegistry:
        async def call(self,method,values):
            stub_calls.append((method,values))
            return values
    transforms,plans=TransformTools(StubRegistry()),TaskPlanTools(StubRegistry())
    raw=[-1.,-0.,0.,0.]
    await transforms.transform_set('No User Object',rotation_quaternion=raw)
    await plans.task_plan_preview_transform('No Reference',3,step_id='revise',rotation_quaternion=raw)
    for method,values in stub_calls:
        assert [struct.pack('!d',x) for x in values['rotation_quaternion']]==[struct.pack('!d',x) for x in raw]
        assert math.copysign(1.,values['rotation_quaternion'][1])==-1.
    await transforms.transform_set('No User Object',location=[1.,2.,3.],rotation_quaternion=None)
    await plans.task_plan_preview_transform('No Reference',3,location=[1.,2.,3.],rotation_quaternion=None)
    assert all('rotation_quaternion' not in values for _,values in stub_calls[2:4])
    await transforms.transform_set('No User Object',rotation=[.1,.2,.3],rotation_quaternion=raw)
    await plans.task_plan_preview_transform('No Reference',3,rotation_mode='XYZ',rotation_quaternion=raw)
    assert stub_calls[4][1]['rotation']==[.1,.2,.3] and stub_calls[4][1]['rotation_quaternion']==raw
    assert stub_calls[5][1]['rotation_mode']=='XYZ' and stub_calls[5][1]['rotation_quaternion']==raw
    assert len(stub_calls)==6
    disabled_checks={}
    async with Client(transport,read_timeout_seconds=20.) as client:
        client = RecordingClient(client, output)
        listing=await client.list_tools()
        names=sorted(tool.name for tool in listing.tools)
        assert names == expected_names and len(names) == 266
        with (output/'observed-tools.json').open('x', encoding='utf-8') as stream:
            json.dump([{'name': tool.name, 'input_schema': tool.input_schema,
                'annotations': {key: getattr(tool.annotations, key, None) for key in
                    ('read_only_hint', 'destructive_hint', 'open_world_hint')}}
                for tool in listing.tools], stream, indent=2, allow_nan=False)
            stream.write('\n')
        by_name = {tool.name: tool for tool in listing.tools}
        quaternion_methods=('transform.set','task.plan.preview_transform')
        quaternion_schemas={}
        from mcp_server.tools import catalog
        definitions={item.name:item for item in (*catalog.CORE_DEFINITIONS,*catalog.load_object_definitions())}
        for method in quaternion_methods:
            tool=by_name[method]
            schema=tool.input_schema
            optional=schema['properties']['rotation_quaternion']
            assert optional['default'] is None and 'rotation_quaternion' not in schema['required']
            assert {item['type'] for item in optional['anyOf']}=={'array','null'}
            array,=[item for item in optional['anyOf'] if item.get('type')=='array']
            assert array['minItems']==array['maxItems']==4 and array['items']['type']=='number'
            preview=method=='task.plan.preview_transform'
            assert tool.annotations.read_only_hint is preview and tool.annotations.destructive_hint is False
            definition=definitions[method]
            assert definition.toolset==('core' if preview else 'objects')
            assert definition.modifying is (not preview)
            assert definition.required_permissions==(('INSPECT_SCENE',) if preview else ('TRANSFORM_OBJECTS',))
            quaternion_schemas[method]={'input_schema':schema,'toolset':definition.toolset,
                'modifying':definition.modifying,'required_permissions':list(definition.required_permissions),
                'read_only_hint':tool.annotations.read_only_hint,'destructive_hint':tool.annotations.destructive_hint}
        capture_schema = by_name['viewport.capture'].input_schema
        frame = capture_schema['properties']['frame_object']
        assert frame['type'] == 'boolean' and frame['default'] is False
        assert 'frame_object' not in capture_schema.get('required', [])
        preview_schema = by_name['task.plan.preview_transform'].input_schema
        assert 'step_id' in preview_schema['properties']
        assert 'step_id' not in preview_schema.get('required', [])
        rigid_schemas={}
        rigid_methods=('rigid_body.evaluate_preview','rigid_body.evaluate_job_start')
        base_required={'scene_name','body_names','constraint_names','frame_start','frame_end'}
        for method in rigid_methods:
            tool=by_name[method]
            schema=tool.input_schema
            fields=schema['properties']
            starting=method == 'rigid_body.evaluate_job_start'
            required=base_required | ({'expected_fingerprint'} if starting else set())
            assert set(schema['required']) == required
            assert set(fields) == required | {'time_limit_seconds'}
            assert fields['scene_name']['type'] == 'string'
            assert fields['scene_name']['minLength'] == 1 and fields['scene_name']['maxLength'] == 63
            bodies=fields['body_names']
            assert bodies['type'] == 'array' and bodies['minItems'] == 1 and bodies['maxItems'] == 16
            assert fields['constraint_names']['type'] == 'array' and fields['constraint_names']['maxItems'] == 0
            for names_field in ('body_names','constraint_names'):
                names_item=fields[names_field]['items']
                assert names_item['type'] == 'string'
                assert names_item['minLength'] == 1 and names_item['maxLength'] == 63
            for frame_name in ('frame_start','frame_end'):
                frame_field=fields[frame_name]
                assert frame_field['type'] == 'integer'
                assert frame_field['minimum'] == 1 and frame_field['maximum'] == 1048574
            limit=fields['time_limit_seconds']
            assert limit['type'] == 'integer' and limit['minimum'] == 1 and limit['maximum'] == 300
            assert limit['default'] == 60 and 'time_limit_seconds' not in required
            if starting:
                fingerprint=fields['expected_fingerprint']
                assert fingerprint['type'] == 'string' and fingerprint['pattern'] == '^[0-9a-f]{64}$'
            else:
                assert 'expected_fingerprint' not in fields
            assert tool.annotations.read_only_hint is (not starting)
            assert tool.annotations.destructive_hint is starting
            rigid_schemas[method]={'input_schema':schema,
                'read_only_hint':tool.annotations.read_only_hint,
                'destructive_hint':tool.annotations.destructive_hint}
        curve_method='animation.curve_inspect'
        curve_tool=by_name[curve_method]
        curve_schema=curve_tool.input_schema
        curve_fields=curve_schema['properties']
        assert set(curve_schema['required']) == {'object_name','data_path'}
        assert set(curve_fields) == {'object_name','data_path','index','slot_identifier','point_offset','point_limit'}
        for curve_name,maximum in (('object_name',256),('data_path',512)):
            field=curve_fields[curve_name]
            assert field['type'] == 'string' and field['minLength'] == 1 and field['maxLength'] == maximum
        for curve_name,minimum,maximum,default in (
                ('index',0,16384,0),('point_offset',0,1000000,0),('point_limit',1,256,64)):
            field=curve_fields[curve_name]
            assert field['type'] == 'integer' and field['minimum'] == minimum and field['maximum'] == maximum
            assert field['default'] == default and curve_name not in curve_schema['required']
        slot=curve_fields['slot_identifier']
        assert slot['default'] is None and 'slot_identifier' not in curve_schema['required']
        assert len(slot['anyOf']) == 2 and {choice['type'] for choice in slot['anyOf']} == {'string','null'}
        slot_name=next(choice for choice in slot['anyOf'] if choice['type'] == 'string')
        assert slot_name['minLength'] == 1 and slot_name['maxLength'] == 256
        assert curve_tool.annotations.read_only_hint is True and curve_tool.annotations.destructive_hint is False
        curve_schema_evidence={'input_schema':curve_schema,
            'read_only_hint':curve_tool.annotations.read_only_hint,
            'destructive_hint':curve_tool.annotations.destructive_hint}
        camera_method='camera.configure'
        camera_schema=by_name[camera_method].input_schema
        assert set(camera_schema['required']) == {'object_name'}
        focus=camera_schema['properties']['focus_distance']
        assert focus['default'] is None and 'focus_distance' not in camera_schema['required']
        assert len(focus['anyOf']) == 2 and {choice['type'] for choice in focus['anyOf']} == {'number','null'}
        focus_number=next(choice for choice in focus['anyOf'] if choice['type'] == 'number')
        assert focus_number['minimum'] == 0.0 and focus_number['maximum'] == 1.0e9
        sample_method='animation.curve_sample'
        sample_tool=by_name[sample_method]
        sample_schema=sample_tool.input_schema
        sample_fields=sample_schema['properties']
        assert set(sample_schema['required']) == {'object_name','data_path','frames'}
        assert set(sample_fields) == {'object_name','data_path','frames','index','slot_identifier'}
        for field_name,maximum in (('object_name',256),('data_path',512)):
            field=sample_fields[field_name]
            assert field['type']=='string' and field['minLength']==1 and field['maxLength']==maximum
        assert sample_fields['index']['type']=='integer' and sample_fields['index']['minimum']==0
        assert sample_fields['index']['maximum']==16384 and sample_fields['index']['default']==0
        sample_frames=sample_fields['frames']
        assert sample_frames['type']=='array' and sample_frames['minItems']==1 and sample_frames['maxItems']==128
        assert sample_frames['items']['type']=='number'
        assert sample_frames['items']['minimum']==-1000000 and sample_frames['items']['maximum']==1000000
        sample_slot=sample_fields['slot_identifier']
        assert sample_slot['default'] is None and {part['type'] for part in sample_slot['anyOf']} == {'string','null'}
        sample_slot_name=next(part for part in sample_slot['anyOf'] if part['type']=='string')
        assert sample_slot_name['minLength']==1 and sample_slot_name['maxLength']==256
        assert sample_tool.annotations.read_only_hint is True and sample_tool.annotations.destructive_hint is False
        mask_method='mesh.sculpt_mask_sample'
        mask_tool=by_name[mask_method]
        mask_schema=mask_tool.input_schema
        mask_fields=mask_schema['properties']
        mask_required={'object_name','uv_layer','vertex_indices','image_name','corner_reduction'}
        assert set(mask_schema['required']) == mask_required
        assert set(mask_fields) == mask_required | {'channel','invert'}
        for field_name in ('object_name','uv_layer','image_name'):
            field=mask_fields[field_name]
            assert field['type']=='string' and field['minLength']==1 and field['maxLength']==63
        mask_indices=mask_fields['vertex_indices']
        assert mask_indices['type']=='array' and mask_indices['minItems']==1 and mask_indices['maxItems']==1024
        assert mask_indices['uniqueItems'] is True
        assert mask_indices['items']['type']=='integer' and mask_indices['items']['minimum']==0
        assert mask_indices['items']['exclusiveMaximum']==100000
        assert mask_fields['channel']['type']=='string' and mask_fields['channel']['enum']==['R','G','B','A']
        assert mask_fields['channel']['default']=='R' and 'channel' not in mask_required
        assert mask_fields['invert']['type']=='boolean' and mask_fields['invert']['default'] is False
        assert 'invert' not in mask_required
        assert mask_fields['corner_reduction']['type']=='string'
        assert mask_fields['corner_reduction']['enum']==['MIN','MAX','MEAN']
        assert 'default' not in mask_fields['corner_reduction']
        assert mask_tool.annotations.read_only_hint is True and mask_tool.annotations.destructive_hint is False
        assert mask_tool.annotations.open_world_hint is False
        # Read metadata from the already byte-verified installed module; no handler is invoked.
        surface_module=importlib.import_module('mcp_server.tools.surface_brushes')
        mask_definition,=[item for item in surface_module.load_definitions() if item.name==mask_method]
        assert mask_definition.toolset=='mesh' and mask_definition.modifying is False
        assert mask_definition.required_permissions==('INSPECT_SCENE',)
        mask_metadata={'toolset':mask_definition.toolset,'modifying':mask_definition.modifying,
            'required_permissions':list(mask_definition.required_permissions),
            'read_only_hint':mask_tool.annotations.read_only_hint,
            'destructive_hint':mask_tool.annotations.destructive_hint,
            'open_world_hint':mask_tool.annotations.open_world_hint}
        target_method='task.plan.verify_transform'
        target_tool=by_name[target_method]
        target_schema=target_tool.input_schema
        target_fields=target_schema['properties']
        assert target_schema['required']==['step_id','receipt_id','expected_revision']
        assert set(target_fields)=={'step_id','receipt_id','expected_revision'}
        assert target_fields['step_id']['type']=='string'
        assert target_fields['step_id']['minLength']==1 and target_fields['step_id']['maxLength']==64
        assert target_fields['step_id']['pattern']=='^[A-Za-z0-9_-]{1,64}$'
        assert target_fields['receipt_id']['type']=='string'
        assert target_fields['receipt_id']['minLength']==target_fields['receipt_id']['maxLength']==45
        assert target_fields['receipt_id']['pattern']=='^step_receipt_[a-f0-9]{32}$'
        assert target_fields['expected_revision']['type']=='integer'
        assert target_fields['expected_revision']['minimum']==1
        assert target_fields['expected_revision']['maximum']==1_000_000_000
        assert target_tool.annotations.read_only_hint is True
        assert target_tool.annotations.destructive_hint is False
        assert target_tool.annotations.open_world_hint is False
        target_module=importlib.import_module('mcp_server.tools.task_plan')
        target_definition,=[item for item in target_module.load_definitions() if item.name==target_method]
        assert target_definition.toolset=='core' and target_definition.modifying is False
        assert target_definition.required_permissions==('INSPECT_SCENE',)
        target_metadata={'toolset':target_definition.toolset,'modifying':target_definition.modifying,
            'required_permissions':list(target_definition.required_permissions),
            'read_only_hint':target_tool.annotations.read_only_hint,
            'destructive_hint':target_tool.annotations.destructive_hint,
            'open_world_hint':target_tool.annotations.open_world_hint}
        status=await client.call_tool('toolsets.list',{})
        assert not status.is_error and status.structured_content['enabled'] == ['core']
        calls={
            'transform.set': {'object_name':'No User Object','rotation_quaternion':[-1.,-0.,0.,0.]},
            'mesh.bridge_chains_preview': {'object_name':'No User Object','selection_id':'No Selection','rail_a_start':0,'rail_a_end':1,'rail_b_start':2,'rail_b_end':3},
            'mesh.bridge_chains': {'object_name':'No User Object','selection_id':'No Selection','rail_a_start':0,'rail_a_end':1,'rail_b_start':2,'rail_b_end':3,'expected_fingerprint':'a'*64},
            'rigid_body.inspect': {'scene_name':'No User Scene'},
            'rigid_body.cache_preview': {'scene_name':'No User Scene','operation':'BAKE','body_names':['No User Body'],'constraint_names':[]},
            'rigid_body.cache': {'scene_name':'No User Scene','operation':'BAKE','body_names':['No User Body'],'constraint_names':[],'expected_fingerprint':'a'*64},
            'rigid_body.evaluate_preview': {'scene_name':'No User Scene','body_names':['No User Body'],
                'constraint_names':[],'frame_start':1,'frame_end':3},
            'rigid_body.evaluate_job_start': {'scene_name':'No User Scene','body_names':['No User Body'],
                'constraint_names':[],'frame_start':1,'frame_end':3,'expected_fingerprint':'a'*64},
            'shader_group.interface_preview': {'group_name':'No Group','socket_identifier':'No Socket','operation':'RENAME','new_name':'Renamed'},
            'shader_group.interface_edit': {'group_name':'No Group','socket_identifier':'No Socket','operation':'RENAME','new_name':'Renamed','expected_fingerprint':'a'*64},
            'image.snapshot_job_start': {'image_name':'No Original','new_name':'No Snapshot'},
            'image.recovery_job_preview': {'image_name':'No Original','snapshot_name':'No Snapshot'},
            'image.restore_snapshot_job_start': {'image_name':'No Original','snapshot_name':'No Snapshot','expected_target_fingerprint':'a'*64},
            'animation.action_inspect': {'action_name':'No User Action'},
            'animation.curve_inspect': {'object_name':'No User Object','data_path':'location'},
            'animation.curve_sample': {'object_name':'No User Object','data_path':'location','frames':[1.0,6.0,13.0]},
            'camera.configure': {'object_name':'No User Camera','focus_distance':5.0},
            'nla.track_reorder': {'object_name':'No User Character','affected_objects':['No User Character'],
                'track_names':['No User Track']},
            'scene.variant.inspect': {},
            'asset.import_preview': {'filepath':'No User Asset.glb','format':'GLB'},
            'mesh.sculpt_mask_sample': {'object_name':'No User Mesh','uv_layer':'UVMap',
                'vertex_indices':[2,0], 'image_name':'No User Mask','corner_reduction':'MEAN'},
            'mesh.sculpt_brush': {'object_name':'No User Scene','vertex_indices':[0],
                'strokes':[{'center':[0.,0.,0.],'direction':[0.,0.,1.]}]},
            'mesh.surface_projection_preview': {'object_name':'No User Scene','selection_id':'No Selection',
                'source_object':'No Reference','source_polygon_indices':[0],'max_distance':0.1},
            'rig.ik_inspect': {'object_name':'No User Rig','tip_bone_name':'No Bone','constraint_name':'No IK'},
            'geometry_nodes.zone_inspect': {'group_name':'No User Graph','output_name':'No Zone'},
        }
        for name,arguments in calls.items():
            response=await client.call_tool(name,arguments)
            assert response.is_error and any('TOOLSET_DISABLED' in item.text
                for item in response.content if hasattr(item,'text')), (name,response)
            disabled_checks[name]='TOOLSET_DISABLED'
        assert len(disabled_checks) == 25
        quaternion_compatibility=[]
        compatibility=(('optional_null',{'rotation_quaternion':None}),
            ('unknown_extra_ignored',{'rotation_quaternion':[1.,0.,0.,0.],'unknown_compatibility_field':'ignored'}),
            ('top_array_string_preparsed',{'rotation_quaternion':'[1.0,-0.0,0.0,0.0]'}))
        for label,changed in compatibility:
            arguments={'object_name':'No User Object',**changed}
            assert json.loads(json.dumps(arguments,allow_nan=False))==arguments
            response=await client.call_tool('transform.set',arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and any('TOOLSET_DISABLED' in item for item in texts),(label,response)
            quaternion_compatibility.append({'case':label,'tool':'transform.set','toolset_disabled':True,
                'SDK_validation_accepted_compatibility_input':True,'standard_JSON':True,
                'arguments':arguments,'response_texts':texts})
        quaternion_invalid=[]
        bad_quaternions=(('empty',[]),('one',[1.]),('two',[1.,0.]),('three',[1.,0.,0.]),
            ('five',[1.,0.,0.,0.,0.]),('seventeen',[0.]*17),('scalar_boolean',True),('scalar_number',1),
            ('non_array_string','not-an-array'),('object',{'w':1,'x':0,'y':0,'z':0}),
            ('true_item',[True,0,0,0]),('false_item',[False,0,0,0]),('string_item',['1',0,0,0]),
            ('null_item',[None,0,0,0]),('list_item',[[1],0,0,0]),('object_item',[{},0,0,0]))
        for method in quaternion_methods:
            base={'object_name':'No User Object'} if method=='transform.set' else {'reference_id':'No Reference','expected_revision':3}
            for label,value in bad_quaternions:
                arguments={**base,'rotation_quaternion':value}
                assert json.loads(json.dumps(arguments,allow_nan=False))==arguments
                response=await client.call_tool(method,arguments)
                texts=[item.text for item in response.content if hasattr(item,'text')]
                assert response.is_error and not any('TOOLSET_DISABLED' in item for item in texts),(method,label,response)
                assert any('validation error' in item.lower() and 'rotation_quaternion' in item for item in texts),(method,label,response)
                quaternion_invalid.append({'tool':method,'case':label,'field':'rotation_quaternion',
                    'input_error_verified':True,'standard_json_roundtrip_verified':True,
                    'validation_before_forwarding_verified':True,'validation_error_texts':texts})
        assert len(quaternion_invalid)==32
        rigid_invalid_checks=[]
        malformed=(('boolean_time_limit',{'time_limit_seconds':True}),
            ('time_limit_below_minimum',{'time_limit_seconds':0}),
            ('time_limit_above_maximum',{'time_limit_seconds':301}),
            ('string_frame_end',{'frame_end':'3'}),
            ('frame_end_below_minimum',{'frame_end':0}),
            ('frame_end_above_maximum',{'frame_end':1048575}),
            ('nonempty_constraints',{'constraint_names':['No Constraint']}),
            ('empty_body_names',{'body_names':[]}))
        for method in rigid_methods:
            invalid_calls=[(label,{**calls[method],**changed}) for label,changed in malformed]
            if method == 'rigid_body.evaluate_job_start':
                missing={key:value for key,value in calls[method].items() if key != 'expected_fingerprint'}
                invalid_calls.extend((('missing_fingerprint',missing),
                    ('malformed_fingerprint',{**calls[method],'expected_fingerprint':'a'*63})))
            for label,arguments in invalid_calls:
                response=await client.call_tool(method,arguments)
                texts=[item.text for item in response.content if hasattr(item,'text')]
                assert response.is_error and not any('TOOLSET_DISABLED' in text for text in texts), (method,label,response)
                rigid_invalid_checks.append({'tool':method,'case':label,
                    'input_error_verified':True,'disabled_dispatch_not_reached':True})
        assert len(rigid_invalid_checks) == 18
        curve_invalid_checks=[]
        curve_invalid_calls=[
            ('missing_object_name',{key:value for key,value in calls[curve_method].items() if key != 'object_name'}),
            ('missing_data_path',{key:value for key,value in calls[curve_method].items() if key != 'data_path'}),
        ]
        curve_malformed=(
            ('empty_object_name',{'object_name':''}),
            ('object_name_above_maximum',{'object_name':'x'*257}),
            ('nonstring_object_name',{'object_name':1}),
            ('empty_data_path',{'data_path':''}),
            ('data_path_above_maximum',{'data_path':'x'*513}),
            ('nonstring_data_path',{'data_path':1}),
            ('boolean_index',{'index':True}),
            ('string_index',{'index':'0'}),
            ('index_below_minimum',{'index':-1}),
            ('index_above_maximum',{'index':16385}),
            ('boolean_point_offset',{'point_offset':True}),
            ('string_point_offset',{'point_offset':'0'}),
            ('point_offset_below_minimum',{'point_offset':-1}),
            ('point_offset_above_maximum',{'point_offset':1000001}),
            ('boolean_point_limit',{'point_limit':True}),
            ('string_point_limit',{'point_limit':'64'}),
            ('point_limit_below_minimum',{'point_limit':0}),
            ('point_limit_above_maximum',{'point_limit':257}),
            ('empty_slot_identifier',{'slot_identifier':''}),
            ('slot_identifier_above_maximum',{'slot_identifier':'x'*257}),
            ('nonstring_slot_identifier',{'slot_identifier':1}),
        )
        curve_invalid_calls.extend((label,{**calls[curve_method],**changed})
            for label,changed in curve_malformed)
        for label,arguments in curve_invalid_calls:
            response=await client.call_tool(curve_method,arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and not any('TOOLSET_DISABLED' in text for text in texts), (curve_method,label,response)
            curve_invalid_checks.append({'tool':curve_method,'case':label,
                'input_error_verified':True,'disabled_dispatch_not_reached':True})
        assert len(curve_invalid_checks) == 23
        camera_focus_invalid_checks=[]
        camera_focus_malformed=(
            ('boolean_focus_distance',True),
            ('string_focus_distance','5.0'),
            ('focus_distance_below_minimum',-1.0),
            ('focus_distance_above_maximum',1000000001.0),
            ('list_focus_distance',[5.0]),
            ('object_focus_distance',{'distance':5.0}),
        )
        for label,value in camera_focus_malformed:
            arguments={**calls[camera_method],'focus_distance':value}
            response=await client.call_tool(camera_method,arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and not any('TOOLSET_DISABLED' in text for text in texts), (camera_method,label,response)
            camera_focus_invalid_checks.append({'tool':camera_method,'case':label,
                'input_error_verified':True,'disabled_dispatch_not_reached':True})
        assert len(camera_focus_invalid_checks) == 6
        sample_invalid_checks=[]
        sample_invalid_calls=[('missing_'+field,{key:value for key,value in calls[sample_method].items() if key!=field})
            for field in ('object_name','data_path','frames')]
        sample_malformed=(
            ('empty_object_name',{'object_name':''}),('long_object_name',{'object_name':'x'*257}),
            ('numeric_object_name',{'object_name':1}),('empty_data_path',{'data_path':''}),
            ('long_data_path',{'data_path':'x'*513}),('numeric_data_path',{'data_path':1}),
            ('boolean_index',{'index':True}),('string_index',{'index':'0'}),
            ('negative_index',{'index':-1}),('large_index',{'index':16385}),
            ('numeric_slot',{'slot_identifier':1}),('empty_slot',{'slot_identifier':''}),
            ('long_slot',{'slot_identifier':'x'*257}),
            ('empty_frames',{'frames':[]}),('too_many_frames',{'frames':[1.0]*129}),
            ('null_frames',{'frames':None}),('scalar_frames',{'frames':1.0}),
            ('string_frames',{'frames':'1'}),('object_frames',{'frames':{'frame':1.0}}),
            ('boolean_frame',{'frames':[True]}),('string_frame',{'frames':['1.0']}),
            ('null_frame',{'frames':[None]}),('array_frame',{'frames':[[1.0]]}),
            ('object_frame',{'frames':[{'frame':1.0}]}),
            ('low_frame',{'frames':[-1000000.01]}),('high_frame',{'frames':[1000000.01]}),
        )
        sample_invalid_calls.extend((label,{**calls[sample_method],**changed}) for label,changed in sample_malformed)
        for label,arguments in sample_invalid_calls:
            response=await client.call_tool(sample_method,arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and not any('TOOLSET_DISABLED' in item for item in texts),(sample_method,label,response)
            sample_invalid_checks.append({'tool':sample_method,'case':label,
                'input_error_verified':True,'disabled_dispatch_not_reached':True})
        assert len(sample_invalid_checks)==29
        mask_invalid_checks=[]
        mask_invalid_calls=[('missing_'+field,field,
            {key:value for key,value in calls[mask_method].items() if key!=field})
            for field in ('object_name','uv_layer','vertex_indices','image_name','corner_reduction')]
        mask_name_malformed=(('empty',''),('blank',' '),('control','bad\nname'),
            ('ascii_over_budget','x'*64),('utf8_over_budget','é'*32),('numeric',1))
        for field in ('object_name','uv_layer','image_name'):
            mask_invalid_calls.extend((field+'_'+label,field,{**calls[mask_method],field:value})
                for label,value in mask_name_malformed)
        mask_index_malformed=(('empty',[]),('over_count',list(range(1025))),('duplicate',[0,0]),
            ('boolean_item',[True]),('float_item',[1.0]),('string_item',['1']),('negative',[-1]),
            ('over_maximum',[100000]),('null_item',[None]),('null',None),('scalar',1),
            ('string','1'),('object',{'index':1}),('nested',[[1]]))
        mask_invalid_calls.extend(('vertex_indices_'+label,'vertex_indices',
            {**calls[mask_method],'vertex_indices':value}) for label,value in mask_index_malformed)
        for field,malformed in (
            ('channel',(('lowercase','r'),('unknown','RGB'),('null',None),('numeric',1))),
            ('invert',(('numeric',1),('string','false'),('null',None),('array',[]))),
            ('corner_reduction',(('lowercase','min'),('unknown','SUM'),('null',None),('numeric',1),('array',[]))),
        ):
            mask_invalid_calls.extend((field+'_'+label,field,{**calls[mask_method],field:value})
                for label,value in malformed)
        assert len(mask_invalid_calls)==50 and len({row[0] for row in mask_invalid_calls})==50
        for label,field,arguments in mask_invalid_calls:
            assert json.loads(json.dumps(arguments,allow_nan=False))==arguments
            response=await client.call_tool(mask_method,arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and not any('TOOLSET_DISABLED' in item for item in texts),(mask_method,label,response)
            assert any('validation error' in item.lower() and field in item for item in texts),(mask_method,label,response)
            mask_invalid_checks.append({'tool':mask_method,'case':label,'field':field,
                'input_error_verified':True,'disabled_dispatch_not_reached':True,
                'standard_json_roundtrip_verified':True,'validation_error_texts':texts})
        assert len(mask_invalid_checks)==50
        target_valid={'step_id':'revise','receipt_id':'step_receipt_'+'a1'*16,'expected_revision':3}
        target_invalid_calls=[('missing_'+field,field,
            {key:value for key,value in target_valid.items() if key!=field}) for field in target_valid]
        target_malformed=(
            ('step_id',(('empty',''),('over_length','x'*65),('blank',' '),('newline','revise\n'),
                ('unicode','révise'),('numeric',1),('boolean',True),('null',None),('array',['revise']),('object',{}))),
            ('receipt_id',(('empty',''),('short_prefix','step_receipt_'),('short_hex','step_receipt_'+'a'*31),
                ('long_hex','step_receipt_'+'a'*33),('uppercase','step_receipt_'+'A'*32),
                ('invalid_hex','step_receipt_'+'g'*32),('wrong_prefix','else_receipt_'+'a'*32),
                ('newline',target_valid['receipt_id']+'\n'),('numeric',1),('boolean',False),
                ('null',None),('array',[target_valid['receipt_id']]),('object',{}))),
            ('expected_revision',(('zero',0),('negative',-1),('over_maximum',1_000_000_001),
                ('true',True),('false',False),('integer_float',3.),('fraction',1.5),('string','3'),
                ('null',None),('array',[3]),('object',{}))),
        )
        for field,malformed in target_malformed:
            target_invalid_calls.extend((field+'_'+label,field,{**target_valid,field:value})
                for label,value in malformed)
        assert len(target_invalid_calls)==37 and len({row[0] for row in target_invalid_calls})==37
        target_invalid_checks=[]
        for label,field,arguments in target_invalid_calls:
            assert json.loads(json.dumps(arguments,allow_nan=False))==arguments
            response=await client.call_tool(target_method,arguments)
            texts=[item.text for item in response.content if hasattr(item,'text')]
            assert response.is_error and not any('TOOLSET_DISABLED' in item for item in texts),(target_method,label,response)
            assert any('validation error' in item.lower() and field in item for item in texts),(target_method,label,response)
            target_invalid_checks.append({'tool':target_method,'case':label,'field':field,
                'input_error_verified':True,'standard_json_roundtrip_verified':True,
                'validation_before_core_forwarding_verified':True,'validation_error_texts':texts})
        assert len(target_invalid_checks)==37
        again=await client.call_tool('toolsets.list',{})
        assert again.structured_content['enabled'] == ['core']
        client.receipts.close()
    for name,loaded in sys.modules.items():
        if name == 'mcp_server' or name.startswith('mcp_server.'):
            assert Path(loaded.__file__).resolve().is_relative_to(module.parent), name
    report={
        'commit':distribution['commit'],'source_tree':distribution['source_tree'],
        'source_sha256':distribution['source_sha256'],
        'wheel_sha256':sha(wheel.read_bytes()),
        'distribution_manifest_sha256':sha((output/'distribution-manifest.json').read_bytes()),
        'installed_module':str(module),'installed_version':importlib.metadata.version('blender-codex-bridge'),
        'mcp_sdk':importlib.metadata.version('mcp'),'python':sys.version,'python_executable':sys.executable,
        'tools_discovered':len(names),'default_enabled':['core'],'stdio_verified':True,
        'exact_documented_tool_names_verified':True,'disabled_domain_errors':disabled_checks,
        'disabled_domain_error_verified':True,'cwd':str(Path.cwd()),'isolated_python':True,
        'disabled_domain_check_count':len(disabled_checks),
        'installed_source_files':installed_files,
        'accepted_module_count':accepted_module_count,'installed_module_count':len(installed_files),
        'installed_source_sha256':sha(json.dumps(installed_files,sort_keys=True).encode()),
        'installed_source_matches_wheel':True,'checkout_imports_used':False,
        'installed_source_matches_accepted_git_hash_list':True,
        'expected_tools_sha256':expected_tools_digest,
        'rigid_evaluation_schemas':rigid_schemas,'rigid_evaluation_schema_verified':True,
        'rigid_evaluation_invalid_input_checks':rigid_invalid_checks,
        'rigid_evaluation_invalid_input_count':len(rigid_invalid_checks),
        'animation_curve_inspection_schema':curve_schema_evidence,
        'animation_curve_inspection_schema_verified':True,
        'animation_curve_invalid_input_checks':curve_invalid_checks,
        'animation_curve_invalid_input_count':len(curve_invalid_checks),
        'camera_focus_distance_schema':camera_schema,'camera_focus_distance_schema_verified':True,
        'camera_focus_invalid_input_checks':camera_focus_invalid_checks,
        'camera_focus_invalid_input_count':len(camera_focus_invalid_checks),
        'animation_curve_sampling_schema':sample_schema,'animation_curve_sampling_schema_verified':True,
        'animation_curve_sampling_invalid_input_checks':sample_invalid_checks,
        'animation_curve_sampling_invalid_input_count':len(sample_invalid_checks),
        'sculpt_mask_sample_schema':mask_schema,'sculpt_mask_sample_schema_verified':True,
        'sculpt_mask_sample_installed_metadata':mask_metadata,
        'sculpt_mask_sample_installed_metadata_verified':True,
        'sculpt_mask_sample_invalid_input_checks':mask_invalid_checks,
        'sculpt_mask_sample_invalid_input_count':len(mask_invalid_checks),
        'artist_target_verify_schema':target_schema,'artist_target_verify_schema_verified':True,
        'artist_target_verify_installed_metadata':target_metadata,
        'artist_target_verify_installed_metadata_verified':True,
        'artist_target_verify_invalid_input_checks':target_invalid_checks,
        'artist_target_verify_invalid_input_count':len(target_invalid_checks),
        'artist_target_verify_core_enabled':True,'artist_target_verify_valid_call_performed':False,
        'artist_target_verify_scope':'Actual installed registration/schema/read-only metadata and strict malformed standard-JSON validation before core forwarding. No valid RPC, Blender target verification, native permission or completion acceptance.',
        'quaternion_schemas':quaternion_schemas,'quaternion_schemas_verified':True,
        'quaternion_invalid_input_checks':quaternion_invalid,'quaternion_invalid_input_count':len(quaternion_invalid),
        'quaternion_installed_annotation_rejections':annotation_checks,'quaternion_installed_annotation_rejection_count':len(annotation_checks),
        'quaternion_direct_stub_wrapper_calls':stub_calls,'quaternion_direct_stub_wrapper_call_count':len(stub_calls),
        'quaternion_stub_signed_zero_bits_preserved':True,'quaternion_stub_optional_none_omitted':True,
        'quaternion_stub_euler_mode_conflicts_forwarded_unchanged_for_Blender_authority':True,
        'quaternion_sdk_compatibility_probes':quaternion_compatibility,'quaternion_sdk_compatibility_probe_count':len(quaternion_compatibility),
        'quaternion_nonfinite_wire_JSON_sent':False,'quaternion_valid_core_RPC_performed':False,
        'quaternion_scope':'Actual installed stdio schema/default-disabled legal assignment and32 malformed standard-JSON cases; SDK null/unknown-extra/array-string compatibility measured separately. Nonfinite/tuple rejection and signed-zero/None/conflict forwarding use direct installed annotations/wrappers with a local stub, never Blender RPC. No native quaternion or ownership acceptance.',
        'all_json_invalid_input_count':len(rigid_invalid_checks)+len(curve_invalid_checks)+len(camera_focus_invalid_checks)+len(sample_invalid_checks)+len(mask_invalid_checks)+len(target_invalid_checks)+len(quaternion_invalid),
        'sculpt_mask_sample_nonfinite_json_tested':False,
        'sculpt_mask_sample_scope':'Installed registration, schema, read-only hints/permission metadata and strict standard-JSON validation before disabled dispatch; no image/UV sampling or authoritative Blender permission acceptance.',
        'animation_curve_sampling_nonfinite_stdio_tested':False,
        'animation_curve_sampling_scope':'Schema and disabled-dispatch checks; native values/context/permission relationship proven separately.',
        'camera_focus_nonfinite_stdio_tested':False,
        'camera_focus_object_relationship_scope':'Blender-authoritative; not established by JSON Schema or disabled-dispatch checks.',
        'outer_python_bytecode_disabled':bool(sys.flags.dont_write_bytecode),
        'child_server_python_arguments':server_python_arguments,
        'child_server_bytecode_disabled_by_flag':'-B' in server_python_arguments,
        'bytecode_scope':'The outer interpreter flag is observed and the child is launched with -B; preexisting bytecode cache absence is not asserted.',
        'optional_frame_object_boolean_default_false':True, 'optional_preview_step_id_schema':True,
        'release_readiness':'NOT_ASSESSED','native_blender_or_windows_acceptance':False,
        'distribution':'0.4.0 pre-release candidate; no stable release acceptance or historical asset replacement',
        'sdk_response_receipts':'rpc-receipts.jsonl; SDK text/structured results, not raw wire frames',
        'actual_full_tool_name_and_schema_listing':'observed-tools.json',
    }
    assert report['installed_version'] == '0.4.0' and report['mcp_sdk'] == '2.2.0'
    with (output/'installed-wheel-evidence.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key != 'installed_source_files'},indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--authority',required=True,type=Path)
    args=parser.parse_args()
    asyncio.run(check(args.output.resolve(strict=True), args.authority))
