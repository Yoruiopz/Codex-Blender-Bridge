from __future__ import annotations
import hashlib,json,os,pathlib,subprocess,time
ROOT=pathlib.Path('/workspace/Codex-Blender-Bridge-uv-edit-guard-20261024')
OUT=pathlib.Path(__file__).resolve().parent
PY='/workspace/Codex-Blender-Bridge/.venv/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
def inventory():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
 return {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sorted(set(names)) if name}
before=inventory()
commands=[('full-tests',[PY,'-B','-m','pytest','-q','-p','no:cacheprovider','-o','tmp_path_retention_count=1','-o','tmp_path_retention_policy=failed','--basetemp',str(OUT/'pytest-tmp'),'--junitxml',str(OUT/'python-tests.xml')]),('ruff',[PY,'-B','-m','ruff','check','--no-cache','.']),('mypy',[PY,'-B','-m','mypy','--cache-dir=/dev/null','mcp_server']),('inventory',[PY,'-B','scripts/readme_tools.py','--check']),('whitespace',['git','diff','--check']),('compile',[PY,'-B','-c','from pathlib import Path; paths=sorted(p for base in ("addon/blender_codex_bridge","mcp_server","scripts") for p in Path(base).rglob("*.py")); [compile(p.read_bytes(),str(p),"exec") for p in paths]; print(f"Compiled {len(paths)} Python sources in memory")'])]
results=[]
for label,command in commands:
 start=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as log:result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 row={'label':label,'command':command,'exit_code':result.returncode,'duration_seconds':time.monotonic()-start,'log_sha256':hashlib.sha256((OUT/(label+'.log')).read_bytes()).hexdigest()}
 results.append(row);(OUT/'validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
after=inventory();assert before==after,'Source changed during final validation'
manifest={'source':str(ROOT),'source_files':len(before),'all_files_unchanged':True,'source_map':before,'source_map_sha256':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'results':results,'windows_tested':False,'release_acceptance':False}
(OUT/'source-validation-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
