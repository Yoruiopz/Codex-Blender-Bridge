# 0.4.0 prerelease CI and package audit preparation

**Prepared, awaiting root inputs; this folder is not sealed.** The seven helpers
have only been read and parsed as Python syntax. None has been imported or run.
No network request, CI job, download, build, installation, stdio session, native
Blender process, commit, tag or publication was performed by this preparation.

These helpers adapt the root-reviewed exact-head audits in
`build/uv-edit-storage-ci-20261024`. `adapted-helper-provenance.json` records those
exact source bytes. Old helpers, metadata, downloads, installations and evidence
remain unchanged. The new folder contains no historical acceptance outputs.

## Required root pins

Do not run a helper using the pending template. After accepting the final exact
source, root must create a separate `audit-identity.json`, retaining the pending
template unchanged, with:

- `status="ROOT_ACCEPTED_PUBLIC_HEAD"` and `component_version="0.4.0"`;
- the canonical source repository path, actual 40-hex commit/tree and positive
  Python/source/add-on/MCP/plugin/wheel member counts;
- the immutable source Python inventory SHA256: SHA256 of the default
  `json.dumps(mapping, sort_keys=True).encode()` representation, where the mapping
  covers tracked `.py` files under `addon`, `mcp_server` and `scripts`, with each
  value its raw-file SHA256;
- the actual positive CI push-run ID, draft PR number and full-suite passed count;
  the three explicitly named Windows-only skips remain expected;
- the downloaded package artifact's API SHA256 digest without its `sha256:`
  prefix, verified against the actual retained ZIP bytes;
- `accepted_native_local_source` containing the actual root-accepted local commit
  and tree. Its tree must equal the public tree; historical native reports cannot
  supply an invented candidate-native source identity.

Every future acceptance field remains null in
`audit-identity.pending-template.json`. No old commit, test count, artifact digest
or module count is inherited as candidate evidence. Root must retain separate
acceptance evidence for the native-local pin; these package scripts do not
produce native acceptance.

## Dependencies and execution order

Root owns all later execution. Use an existing Python **3.12** environment with
`packaging` available; do not install anything to run these auditors. `tomllib`
and the other auditor dependencies are standard library. `collect-metadata.py`
additionally needs an already-authorized `gh` command and performs read-only API
requests only. Package/source comparisons require the pinned commit's local Git
objects. No Blender or MCP feature package is imported.

Use `PYTHONDONTWRITEBYTECODE=1` and Python `-B`. Do not use `-O`, because the
reviewed helpers deliberately use assertions to fail closed. Retain commands and
stdout/stderr in a separate root-owned execution folder so an active log cannot
enter a future seal of this folder.

1. Retain connector-normalized `jobs-plugin.json`, `artifacts-plugin.json` and
   `pr-info-plugin.json`, plus each exact job's raw connector response in
   `job-logs/<job_id>.json`. The existing accepted connector log shape is
   `structuredContent.content`. Keep all actual IDs; do not rewrite metadata or
   preserve credentials, signed download URLs or temporary file references.
2. Root may collect full REST metadata using the accepted head and run ID:

   ```text
   python -B build/prerelease-0.4-ci-20261024/collect-metadata.py --head <accepted-40-hex-head> --run-id <accepted-push-run-id> --label final --final
   ```

   The collector requires the unique exact-head **push** CI run, verifies the
   explicit root run ID and creates new metadata files exclusively. A PR merge
   run is not equivalent to the accepted branch commit. Preserve earlier failed
   or incomplete retrieval attempts under distinct labels; never overwrite them.
3. Download the seven exact artifacts through the connected GitHub capabilities.
   Store the package artifact as `artifacts/development-packages.zip` and each
   JUnit artifact as `artifacts/<exact_artifact_name>.zip`. Retain actual artifact
   IDs, API sizes/digests and download provenance. Downloads are outside this
   preparation; no downloader has been copied or executed here.
4. Execute, in order, from the primary repository:

   ```text
   python -B build/prerelease-0.4-ci-20261024/compare-metadata.py
   python -B build/prerelease-0.4-ci-20261024/verify_ci.py
   python -B build/prerelease-0.4-ci-20261024/package-verification/audit_packages.py
   python -B build/prerelease-0.4-ci-20261024/package-verification/audit-wheel.py
   python -B build/prerelease-0.4-ci-20261024/finish-packages.py
   python -B build/prerelease-0.4-ci-20261024/combine-audit.py
   ```

   Any failure blocks the next step. `finish-packages.py` exclusively creates the
   new `package-assets` directory only after the two static audits pass. No
   package is installed, imported or executed by these steps.

## Checks retained

- Seven successful jobs and exact checkout commits; all six Python
  3.10/3.11/3.12 × MCP SDK 2.0.0/2.2.0 cells, matching complete test identities,
  actual expected pass count and the three exact named Windows-only skips.
- Connector/full REST agreement, exact run/job/artifact IDs and head identities,
  artifact API byte sizes/digests, JUnit ZIP member/type/layout/CRC and contents.
- Safe unique regular-file archive layouts; exactly the three numeric **0.4.0**
  packages plus `SHA256SUMS.txt`; every named package checksum verified.
- Immutable Git source tree, complete source count and Python fingerprint;
  exact add-on/plugin source names and bytes; matching six-component identity.
- Complete MCP wheel/source members, each RECORD SHA256 and size, unsigned
  RECORD self-row, metadata/dependencies/classifiers, README/license bytes,
  console entry point and pure-Python wheel tag.

The adaptation changes numeric version expectations, requires the explicit
collector run ID, adds a fixed 0.4.0 identity gate and complete tracked-source
count check, and removes old session-reuse claims. It does not weaken the
previous CI/package checks.

## A new installed session is separate and mandatory

`combined-audit.json` retains the usual `status="passed"`, `source_commit`,
`source_tree`, `source_repository`, `packages.assets` file/size/hash facts and
`evidence_receipts` hash bindings for the new installed-package harness. That
harness must bind this actual file's SHA256 and install the exact audited 0.4.0
wheel into a new isolated environment, then perform a real MCP stdio session.

CI's installed `--help` check is not that session. No `prepare-baseline.py`,
`audit_reuse.py` or old reuse finalizer is copied here. Historical 0.3.0 sessions
and byte-equal payload claims cannot be relabeled as a new 0.4.0 session. The
static receipts explicitly report `new_candidate_install_and_stdio_required`
and `old_stdio_session_reused=false`.

The combined static receipt closes no 1.0 gate, qualifies no installed/native
workflow or Windows support, and publishes nothing. Windows compatibility and
testing remain deferred. Root seals the completed evidence only after the final
pins, actual CI/package audits and separate new-session acceptance are retained.

## Root capacity adaptation before execution

The matrix auditor retains each original CI artifact ZIP and verifies/parses its
complete `python-tests.xml` member directly. It records member bytes, SHA256 and
archive/member paths instead of writing a redundant standalone XML copy. Every
CRC, API hash, test identity/count and skip assertion is unchanged. The initial
prepared helper remains in `verify_ci-pre-root-capacity.txt`; root records the
exact four-line retention change separately. No old evidence was removed.
