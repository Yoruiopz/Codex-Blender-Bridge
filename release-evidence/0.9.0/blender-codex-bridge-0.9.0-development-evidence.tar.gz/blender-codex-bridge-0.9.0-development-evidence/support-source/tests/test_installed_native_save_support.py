"""Portable admission/origin tests; these never import or launch native Blender."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def support(monkeypatch):
    monkeypatch.setitem(sys.modules, "bpy", SimpleNamespace())
    spec = importlib.util.spec_from_file_location("installed_support_test", ROOT / "scripts/blender_installed_native_save_smoke.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def runner():
    spec = importlib.util.spec_from_file_location("installed_runner_test", ROOT / "scripts/run_blender_checks.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_candidate_admission_is_fail_closed_until_final_reviewed_pin(support, monkeypatch):
    monkeypatch.setattr(support, "ACCEPTED_COMMIT", "PENDING")
    with pytest.raises(AssertionError, match="not frozen"):
        support.accepted_candidate_pin()


@pytest.mark.parametrize("drift", ["runtime", "provider", "executor", "jobs"])
def test_installed_origin_refuses_replaced_services_and_provider(support, drift):
    fixture = support.InstalledNative.__new__(support.InstalledNative)
    runtime = SimpleNamespace(executor=SimpleNamespace(), permissions=SimpleNamespace(_source=object()),
        checkpoints=object(), registry=object(), jobs=object(), command_queue=object())
    runtime.executor.permissions = runtime.permissions
    fixture.runtime = runtime
    fixture.permission_source = runtime.permissions._source
    fixture.permission_origin = (runtime, runtime.executor, runtime.permissions, runtime.checkpoints,
        runtime.registry, runtime.jobs, runtime.command_queue)
    fixture.installed, fixture.members = ROOT, {}
    fixture.helpers = SimpleNamespace(package=SimpleNamespace(_installed_bytes=lambda *a: None))
    fixture.origin()
    if drift == "provider":
        runtime.permissions._source = object()
    elif drift == "runtime":
        fixture.runtime = SimpleNamespace(**vars(runtime))
    else:
        setattr(runtime, drift, object())
    with pytest.raises(AssertionError):
        fixture.origin()


def test_current_clean4k_oracle_is_reused_without_sequence_or_runtime_shortcuts():
    tree = ast.parse((ROOT / "scripts/blender_installed_native_save_smoke.py").read_text())
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "InstalledNative")
    method = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "start_large")
    attributes = [node.attr for node in ast.walk(method) if isinstance(node, ast.Attribute)]
    assert "LargeSaveController" in attributes and "large_save_worker" in attributes
    assert not {"clear_owned_empty_sequence_editors", "sequence_editor_clear", "dispatch", "_drain_timer", "tick"}.intersection(attributes)
    assert "native_save" not in {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}


@pytest.fixture
def receipt_model(runner, monkeypatch, tmp_path):
    pin = {"source_commit": "a" * 40, "source_tree": "b" * 40, "sha256": "c" * 64,
        "version": "0.9.0", "expected_tools": 270}
    monkeypatch.setattr(runner, "_installed_candidate_pin", lambda: pin)
    monkeypatch.setattr(runner, "ROOT", tmp_path)
    helpers = {}
    for filename in ("blender_installed_addon_probe_smoke.py", "blender_native_save_smoke.py",
            "blender_weight_edit_guard_smoke.py", "blender_animation_intent_smoke.py",
            "blender_isolated_asset_preview_probe_smoke.py", "installed_fixture_transport.py"):
        name = "scripts/" + filename
        path = tmp_path / name
        path.parent.mkdir(exist_ok=True)
        path.write_text("# fixture oracle\n")
        helpers[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    fixture_path = tmp_path / "scripts/blender_installed_native_save_smoke.py"
    fixture_path.write_text("# reviewed support fixture\n")
    monkeypatch.setattr(runner, "git_value", lambda *args: "1" * 40)
    candidate = {**pin, "members_sha256": {"blender_codex_bridge/__init__.py": "d" * 64}}
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"schema_version": 1, "candidate": candidate, "previous": None}))
    monkeypatch.setenv("BRIDGE_TEST_PACKAGE_PROBE_CONFIG", str(config))
    payload = {"accepted_candidate_commit": pin["source_commit"], "accepted_candidate_tree": pin["source_tree"],
        "accepted_candidate_zip_sha256": pin["sha256"], "phase": "weights", "process_instance": "e" * 32,
        "installed_queued_profile_qualified": True, "full_artist_workflow_qualified": False,
        "process_id": 13, "blender_version": "5.2.2 LTS"}
    full = {k: v for k, v in payload.items() if k != "full_artist_workflow_qualified"}
    full.update(support_script_sha256=hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
        supporting_commit="1" * 40, completed=True, runtime_or_provider_replaced=False, queue_or_job_timers_manually_driven=False,
        installed_module_origins_verified=True, genuine_runtime_services_preserved=True,
        configuration_sha256=hashlib.sha256(config.read_bytes()).hexdigest(), installed_members_sha256=candidate["members_sha256"],
        support_helper_sources=helpers, artist_cases=[{"complete_prediction_and_history_verified": True}])
    def write():
        path = tmp_path / "installed-native-full-receipt.json"
        path.write_text(json.dumps(full))
        payload["receipt"] = {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    write()
    return payload, full, write, tmp_path


@pytest.mark.parametrize("fault", [None, "commit", "provider", "manual_ticks", "member", "helper", "receipt", "native_validator", "bad_native_type", "bad_artist_type", "fixture", "support_commit", "helper_alias"])
def test_full_installed_receipt_binds_candidate_origins_and_native_validator(runner, receipt_model, monkeypatch, fault):
    payload, full, write, temporary = receipt_model
    if fault == "commit":
        full["accepted_candidate_commit"] = "f" * 40
    elif fault == "provider":
        full["runtime_or_provider_replaced"] = True
    elif fault == "manual_ticks":
        full["queue_or_job_timers_manually_driven"] = True
    elif fault == "member":
        full["installed_members_sha256"] = {}
    elif fault == "helper":
        (temporary / "scripts/blender_native_save_smoke.py").write_text("changed")
    elif fault == "fixture":
        (temporary / "scripts/blender_installed_native_save_smoke.py").write_text("changed")
    elif fault == "support_commit":
        full["supporting_commit"] = "2" * 40
    elif fault == "helper_alias":
        full["support_helper_sources"]["scripts/wrong.py"] = full["support_helper_sources"].pop("scripts/installed_fixture_transport.py")
    elif fault == "bad_artist_type":
        full["artist_cases"] = [True]
    elif fault == "bad_native_type":
        payload.update(phase="native_save", native_large_evidence=[])
        full.update(phase="native_save", native_large_evidence=[], native_clean_packed_4k_qualified=True)
    elif fault == "native_validator":
        payload.update(phase="native_save", native_large_evidence={"process_id": payload["process_id"], "blender_version": payload["blender_version"]})
        full.update(phase="native_save", native_large_evidence=payload["native_large_evidence"], native_clean_packed_4k_qualified=True)
        calls = []
        monkeypatch.setattr(runner, "_native_save_large_receipt_matches", lambda *args: calls.append(args) or False)
    write()
    if fault == "receipt":
        (temporary / "installed-native-full-receipt.json").write_bytes(b"{}")
    result = runner._installed_native_receipt_matches(payload, temporary, "e" * 32, payload["phase"], {}, {})
    assert result is (fault is None)
    if fault == "native_validator":
        assert len(calls) == 1
