PRIVATE PUBLIC-EVIDENCE CANDIDATE, NOT A PUBLICATION RECORD

Root must review this candidate and package only the explicit public file whitelist.
No evidence archive was created here, no release was published, and publisher
arming/notes/evidence checksum pins remain pending Root action.

These files are sanitized numerical projections of known synthetic fixture data,
not unchanged copies of private complete receipts. Public MANIFEST.json records
both original input SHA256 identities and the distinct exported file hashes.
Absolute paths, IPC/authentication tokens, display/auth/config data, authority,
environment/preferences, argv, free-form errors/responses and image/project bytes
are omitted. Only safe process_instance IDs remain; nonprocess job/operation IDs
are hashed. Source-file SHA maps remain public identities, including modules
whose names contain preferences/authority. All false and zero facts are retained
unless their enclosing field is explicitly omitted for privacy. Source numerical
values, Float32 bits, full pixel/packed/projection hashes, resources, native
intervals, reader metrics, role/ID and assertion evidence are preserved where
exported. JUnit properties/output/error/path attributes are omitted; path-bearing
test identity attributes are represented by SHA256 identifiers.

ci/                    Exact d756 CI package/source audit, public API metadata,
                       six sanitized complete JUnit inventories (10798 each,
                       10795passed and3Windows skips).
source-core14/         Actual exact-d756 source-checkout replay:28 selected rows,
                       fourteen per official Linux build. Not installed/global
                       native inventory or appearance/artist acceptance.
installed-native/      Actual accepted ZIP in6fresh parent processes at separate
                       support98783d; native_save/weights/curve on both builds.
                       Native clean4K uses product-spawned fresh reader workers;
                       it is not a runner writer/reader pair.
upgrade03/,upgrade07/  Both builds, each with fresh-candidate/previous/upgrade/
                       rollback observations, path-space and listener restart/
                       reconnect checks in the SAME OS Blender process. 0.3
                       retains known-name discovery and legacy in-place limits.
sdk/                   Separate actual fresh wheel SDK2.2 and2.0 sessions:
                       307responses each,270tools,277malformed JSON denials,
                       zero unexpected forwarding; no valid native-save RPC,
                       native Blender/Windows or combined artist acceptance.
historical/            Distinct failed installed01 memory-floor attempt and
                       SDK2.0 harness02 compatibility failure. Successful
                       replays do not rewrite these failures. Raw logs omitted.
support-source/        Exact9support source blobs at98783d, separate from the
                       d756 product tree. No runtime payloads or user data.
source/                Root-created public-source-only bundle and receipt,
                       copied unchanged after privacy review. One HEAD d756,
                      133already-public reachable commits; no other refs/WIP.

Installed4.5 pressure qualification=False/0bytes (safe cap/headroom reason).
Installed5.2 includes the bounded1.875GiB pressure ADMISSION REFUSAL ONLY: observed
available memory fell below the unchanged8GiBfloor, yielding NOT_IMPLEMENTED /
LARGE_IMAGE_MEMORY_BUDGET before execution/native entry/bridge writes. It does
not qualify successful saving under pressure, full memory recovery or4.5pressure.
The raw10assertions4.5/11assertions5.2 and actual peaks are retained. Older source
pressure-false results remain historical and are not substituted for these facts.

No .blend/.blend1/image/recovery/preferences/auth-cookie/authority/env/private
archive/venv/dependency payloads, raw logs or reviewed appearance evidence are
included. Root's private preservation archive is outside this candidate.
All29implementation items/all14stable gates remain OPEN; Windows is deferred
and unverified. Dirty/generated/edited CURRENT_PIXELS, paired4K, full artist1.0,
OS-process restart/preferences migration and installed A-F remain unqualified.
The release notes are a DRAFT and keep the exact finite blocker plan/target.
